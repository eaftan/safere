// This file is part of a Java port of RE2 (https://github.com/google/re2).
// Original RE2 code is Copyright (c) 2009 The RE2 Authors.
// Modifications and Java port Copyright (c) 2026 Eddie Aftandilian.
// Licensed under the BSD 3-Clause License (see LICENSE file).

package org.safere;

import java.util.Objects;

/**
 * Opaque process-local pattern identity paired with its static analysis.
 *
 * <p>The identity has the scope and lifetime described by {@link Pattern#patternId()}.
 */
public record PatternDescriptor(long patternId, PatternAnalysis analysis) {
  /** Creates a descriptor. */
  public PatternDescriptor {
    if (patternId <= 0) {
      throw new IllegalArgumentException("patternId must be positive");
    }
    Objects.requireNonNull(analysis, "analysis");
  }
}
