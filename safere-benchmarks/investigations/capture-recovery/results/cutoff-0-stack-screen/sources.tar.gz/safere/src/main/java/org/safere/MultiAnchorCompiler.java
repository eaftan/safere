// This file is part of a Java port of RE2 (https://github.com/google/re2).
// Original RE2 code is Copyright (c) 2009 The RE2 Authors.
// Modifications and Java port Copyright (c) 2026 Eddie Aftandilian.
// Licensed under the BSD 3-Clause License (see LICENSE file).

package org.safere;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import org.safere.MultiAnchorDescriptor.RejectPlan;
import org.safere.MultiAnchorDescriptor.StartPlan;

/**
 * Compiles AST representations of regular expressions into {@link MultiAnchorDescriptor}, {@link
 * StartDescriptor}, and {@link RejectDescriptor} instances in a single bottom-up traversal.
 */
final class MultiAnchorCompiler {

  // Full case closures in the supported JDK casing data and SafeRE fold table have at most four
  // code points. A larger closure in future JDK casing data would only lose folded-prefix
  // acceleration; matching stays correct. MultiAnchorCompilerTest checks every closure and its
  // eligible folded prefix, catching growth beyond this bound.
  private static final int MAX_UNICODE_FOLD_CLASS_RUNES = 4;

  // The most code points a leading class may exclude and still drive a leading expansion when it
  // has more than MAX_LEADING_CLASS_RUNES members. Non-DOTALL `.` excludes five line terminators.
  private static final int MAX_LEADING_CLASS_COMPLEMENT = 8;

  // The shortest skip, in input units, for which a leading expansion over a wide class finds its
  // start candidate. Its backward walk covers the rest of the line, so on shorter skips the
  // literal scan and the walk cost more than letting the engine scan from the search start.
  static final int MIN_WIDE_LEADING_SKIP = 256;

  private static final int MAX_LEADING_CLASS_RUNES = 150_000;

  record PrefixResult(String prefix, boolean foldCase) {
    static final PrefixResult NO_PREFIX = new PrefixResult(null, false);
  }

  @SuppressWarnings("ArrayRecordComponent")
  record FixedOffsetLiteral(String literal, int minOffset, int maxOffset, int[] discreteOffsets) {}

  private static final class AsciiWidthRange {
    static final AsciiWidthRange INVALID = new AsciiWidthRange(-1, -1, null);
    static final AsciiWidthRange ZERO = new AsciiWidthRange(0, 0, new int[] {0});
    static final AsciiWidthRange ONE = new AsciiWidthRange(1, 1, new int[] {1});
    static final AsciiWidthRange NON_DISCRETE_ONE = new AsciiWidthRange(1, 1, null);

    final int minWidth;
    final int maxWidth;
    // Sorted and duplicate-free when present.
    final int[] discreteWidths;

    AsciiWidthRange(int minWidth, int maxWidth, int[] discreteWidths) {
      this.minWidth = minWidth;
      this.maxWidth = maxWidth;
      this.discreteWidths = discreteWidths;
    }

    static AsciiWidthRange exact(int width) {
      return new AsciiWidthRange(width, width, new int[] {width});
    }

    boolean isValid() {
      return minWidth >= 0;
    }

    boolean isExact() {
      return minWidth >= 0 && minWidth == maxWidth;
    }

    boolean isExactAscii() {
      // Non-discrete widths can count Unicode code points rather than ASCII input units.
      return isExact() && discreteWidths != null;
    }
  }

  @SuppressWarnings("ArrayRecordComponent")
  record StartFacets(
      PrefixResult prefix,
      CharClassScanInfo charClassPrefix,
      FixedOffsetLiteral fixedOffsetLiteral,
      Pattern.StartAcceleration startAcceleration,
      PrefixResult anchoredPrefix,
      CharClassScanInfo anchoredCharClassPrefix,
      String[] literalAlternation) {

    static final StartFacets EMPTY =
        new StartFacets(
            PrefixResult.NO_PREFIX, null, null, null, PrefixResult.NO_PREFIX, null, null);
  }

  @SuppressWarnings("ArrayRecordComponent")
  record RejectFacets(
      String bestRequiredLiteral,
      int bestRequiredLiteralScore,
      CharClass bestRequiredClass,
      String[] disjointRequiredLiterals,
      Pattern.SuffixInfo endAnchoredSuffix,
      Pattern.EndAnchoredCharClassInfo endAnchoredCharClass) {

    static final RejectFacets EMPTY = new RejectFacets(null, 0, null, null, null, null);
  }

  record ClassAnchor(CharClassScanInfo scanInfo, int offset) {}

  record NodeAnalysis(
      AsciiWidthRange width,
      StartFacets start,
      RejectFacets reject,
      CharClass atomicRequiredClass,
      ClassAnchor classAnchor) {

    NodeAnalysis(
        AsciiWidthRange width,
        StartFacets start,
        RejectFacets reject,
        CharClass atomicRequiredClass) {
      this(width, start, reject, atomicRequiredClass, null);
    }

    static final NodeAnalysis EMPTY =
        new NodeAnalysis(AsciiWidthRange.ZERO, StartFacets.EMPTY, RejectFacets.EMPTY, null);
    // Cached widths must remain conservative, just as in the standalone width walker.
    static final NodeAnalysis UNKNOWN =
        new NodeAnalysis(AsciiWidthRange.INVALID, StartFacets.EMPTY, RejectFacets.EMPTY, null);
  }

  private MultiAnchorCompiler() {}

  static NodeAnalysis analyze(Regexp re) {
    return analyze(re, 0).root();
  }

  // The walker owns these child results; they are used only during this compilation and are
  // never modified after the root's postVisit. Captures retain the unwrapped root's children.
  private record Analysis(NodeAnalysis root, List<NodeAnalysis> children) {}

  private static Analysis analyze(Regexp re, int flags) {
    if (re == null) {
      return new Analysis(NodeAnalysis.EMPTY, List.of());
    }
    MultiAnchorWalker walker = new MultiAnchorWalker(re, flags);
    NodeAnalysis root = walker.walk(re, NodeAnalysis.EMPTY);
    return new Analysis(root, walker.rootChildren);
  }

  static MultiAnchorDescriptor compile(Regexp re, int flags) {
    if (re == null) {
      return null;
    }
    Regexp factored = factorAlternations(re);
    Regexp node = unwrapCaptures(factored);
    if (node == null) {
      return null;
    }

    boolean anchorStart =
        node.op == RegexpOp.CONCAT
            && node.subs != null
            && !node.subs.isEmpty()
            && node.subs.get(0).op == RegexpOp.BEGIN_TEXT;

    Analysis analysis = analyze(factored, flags);
    MultiAnchorDescriptor.StartPlan startPlan = extractStartPlan(factored, true, analysis.root());
    MultiAnchorDescriptor.RejectPlan rejectPlan =
        extractRejectPlan(factored, startPlan, anchorStart, analysis);

    PrefixResult anchoredPrefix = analysis.root().start().anchoredPrefix();
    String anchoredLiteral = anchoredPrefix.foldCase() ? null : anchoredPrefix.prefix();

    return new MultiAnchorDescriptor(
        anchorStart,
        startPlan,
        rejectPlan,
        anchoredLiteral,
        analysis.root().start().anchoredCharClassPrefix());
  }

  static MultiAnchorDescriptor.StartPlan extractStartPlan(Regexp metadataAst) {
    return extractStartPlan(metadataAst, true);
  }

  static MultiAnchorDescriptor.StartPlan extractStartPlan(
      Regexp metadataAst, boolean allowLeadingExpansion) {
    if (metadataAst == null) {
      return MultiAnchorDescriptor.StartPlan.None.INSTANCE;
    }
    return extractStartPlan(metadataAst, allowLeadingExpansion, analyze(metadataAst));
  }

  private static MultiAnchorDescriptor.StartPlan extractStartPlan(
      Regexp metadataAst, boolean allowLeadingExpansion, NodeAnalysis analysis) {
    StartFacets start = analysis.start();

    if (start.startAcceleration() != null) {
      return new MultiAnchorDescriptor.StartPlan.LineAnchor(start.startAcceleration());
    }

    String prefix = start.prefix().prefix();
    boolean prefixFoldCase = start.prefix().foldCase();
    FixedOffsetLiteral fol = start.fixedOffsetLiteral();

    boolean prefixPoisonous =
        prefix != null && RarityOracle.isPoisonousAnchor(prefix, prefixFoldCase);
    boolean folPoisonous = fol != null && RarityOracle.isPoisonousAnchor(fol.literal(), false);

    // When a fixed-offset literal is available and not poisonous:
    //  (a) If the leading prefix is poisonous (e.g. single space or high-frequency letter),
    //      suppress it and prioritize the non-poisonous fixed-offset literal.
    //  (b) Otherwise prefer whichever of the two is more selective. Ties go to the leading
    //      prefix, which needs no offset arithmetic to verify.
    //
    // There is deliberately no length gate and no margin here. Both were tried and both cost
    // more than they saved: requiring `prefix.length() <= 2` meant the two candidates were
    // never even compared unless the leading prefix was a single character or a pair, which
    // is the minority case, and a 2x margin then suppressed most of what survived. Together
    // they pinned `error:\[[A-Z]\] code:500` to the leading `error:[` -- a literal that occurs
    // on every line of a log -- in preference to the far rarer `] code:500`.
    if (fol != null && !folPoisonous) {
      if (prefix == null || prefixPoisonous) {
        return new MultiAnchorDescriptor.StartPlan.FixedOffset(
            new Pattern.FixedOffsetLiteral(
                fol.literal(), fol.minOffset(), fol.maxOffset(), fol.discreteOffsets()),
            start.charClassPrefix());
      }
      int prefixScore = RarityOracle.literalSelectivityScore(prefix, prefixFoldCase);
      int folScore = RarityOracle.literalSelectivityScore(fol.literal());
      if (folScore > prefixScore) {
        return new MultiAnchorDescriptor.StartPlan.FixedOffset(
            new Pattern.FixedOffsetLiteral(
                fol.literal(), fol.minOffset(), fol.maxOffset(), fol.discreteOffsets()),
            start.charClassPrefix());
      }
    }

    if (prefix != null && !prefixPoisonous) {
      return new MultiAnchorDescriptor.StartPlan.Literal(prefix, prefixFoldCase);
    }

    ClassAnchor classAnchor = analysis.classAnchor();
    CharClassScanInfo leadingClass = start.charClassPrefix();
    if (classAnchor != null
        && classAnchor.offset() > 0
        && leadingClass != null
        && leadingClass.isAscii()
        && !leadingClass.isSelective()) {
      return new StartPlan.FixedOffsetClass(
          classAnchor.scanInfo(), classAnchor.offset(), leadingClass);
    }

    String[] altLiterals = start.literalAlternation();
    if (altLiterals != null && altLiterals.length >= 2) {
      return new MultiAnchorDescriptor.StartPlan.MultiLiteral(altLiterals, start.charClassPrefix());
    }

    if (allowLeadingExpansion) {
      MultiAnchorDescriptor.StartPlan.LeadingExpansion leadingExpansion =
          extractStartLeadingExpansion(metadataAst);
      if (leadingExpansion != null) {
        return leadingExpansion;
      }
    }

    if (start.charClassPrefix() != null && !(prefixPoisonous && prefixFoldCase)) {
      return new MultiAnchorDescriptor.StartPlan.CharClass(start.charClassPrefix());
    }

    return MultiAnchorDescriptor.StartPlan.None.INSTANCE;
  }

  static RejectPlan extractRejectPlan(
      Regexp metadataAst, int flags, StartPlan startPlan, boolean anchorStart) {
    if (metadataAst == null) {
      return RejectPlan.None.INSTANCE;
    }
    return extractRejectPlan(metadataAst, startPlan, anchorStart, analyze(metadataAst, flags));
  }

  private static RejectPlan extractRejectPlan(
      Regexp metadataAst, StartPlan startPlan, boolean anchorStart, Analysis analysis) {
    RejectFacets reject = analysis.root().reject();

    List<RejectPlan> plans = new ArrayList<>();

    Pattern.SuffixInfo endAnchoredSuffix = reject.endAnchoredSuffix();
    if (endAnchoredSuffix != null) {
      plans.add(new RejectPlan.EndAnchoredSuffix(endAnchoredSuffix));
    }

    Pattern.EndAnchoredCharClassInfo endAnchoredCharClass =
        endAnchoredSuffix == null ? reject.endAnchoredCharClass() : null;
    if (endAnchoredCharClass != null) {
      plans.add(new RejectPlan.EndAnchoredCharClass(endAnchoredCharClass));
    }

    Set<String> excludeStartLiterals = new LinkedHashSet<>();
    String drivingLiteral = drivingLiteral(startPlan);
    if (drivingLiteral != null) {
      excludeStartLiterals.add(drivingLiteral);
      if (hasFixedOffset(startPlan)) {
        excludeStartLiterals.addAll(extractFixedPrefixLiterals(metadataAst, analysis.children()));
      }
    }
    CharClassScanInfo ccPrefix = drivingCharClass(startPlan);
    boolean skipRequiredCharClass = subsumesRequiredCharClass(startPlan);

    String suffixStr = endAnchoredSuffix != null ? endAnchoredSuffix.suffix() : null;

    String requiredLiteral =
        !anchorStart ? extractRequiredLiteral(metadataAst, excludeStartLiterals, suffixStr) : null;
    if (requiredLiteral != null) {
      plans.add(new RejectPlan.RequiredLiteral(requiredLiteral));
    }

    CharClassScanInfo requiredMatchClass = null;
    if (!anchorStart && !skipRequiredCharClass && endAnchoredCharClass == null) {
      CharClass reqClass = reject.bestRequiredClass();
      if (reqClass != null) {
        if (ccPrefix == null) {
          requiredMatchClass = CharClassScanInfo.fromCharClass(reqClass);
        } else {
          CharClassScanInfo candidate = CharClassScanInfo.fromCharClass(reqClass);
          if (candidate != null
              && candidate.ranges() != null
              && moreSelective(
                  RarityOracle.charClassFrequencyScore(reqClass),
                  reqClass.numRunes(),
                  RarityOracle.charClassFrequencyScore(ccPrefix),
                  runeCount(ccPrefix.ranges()))) {
            requiredMatchClass = candidate;
          }
        }
      }
    }
    if (requiredMatchClass != null) {
      plans.add(new RejectPlan.RequiredCharClass(requiredMatchClass));
    }

    String[] disjointLiterals =
        (!anchorStart && !skipRequiredCharClass && requiredLiteral == null)
            ? reject.disjointRequiredLiterals()
            : null;
    if (disjointLiterals != null && disjointLiterals.length > 1) {
      plans.add(new RejectPlan.DisjointLiterals(disjointLiterals));
    }

    if (plans.isEmpty()) {
      return RejectPlan.None.INSTANCE;
    }
    if (plans.size() == 1) {
      return plans.get(0);
    }
    return new RejectPlan.Composite(plans.toArray(RejectPlan[]::new));
  }

  /**
   * Returns whether a class with the given frequency score and rune count is a better reject
   * candidate than the incumbent: rarer by {@link RarityOracle#charClassFrequencyScore} when both
   * classes can be scored, or with fewer runes when the scores tie or either class scores {@code 0}
   * (no ASCII members, or too many non-ASCII members to ignore). An empty class also scores {@code
   * 0} and has no runes, so it wins, which is harmless: it rejects every input, as it should.
   */
  private static boolean moreSelective(
      long candidateScore, int candidateRunes, long incumbentScore, int incumbentRunes) {
    if (candidateScore == 0 || incumbentScore == 0) {
      return candidateRunes < incumbentRunes;
    }
    return candidateScore < incumbentScore
        || (candidateScore == incumbentScore && candidateRunes < incumbentRunes);
  }

  private static boolean moreSelective(CharClass candidate, CharClass incumbent) {
    return moreSelective(
        RarityOracle.charClassFrequencyScore(candidate),
        candidate.numRunes(),
        RarityOracle.charClassFrequencyScore(incumbent),
        incumbent.numRunes());
  }

  private static int runeCount(int[] ranges) {
    int runes = 0;
    for (int i = 0; i < ranges.length; i += 2) {
      runes += ranges[i + 1] - ranges[i] + 1;
    }
    return runes;
  }

  /**
   * Returns the literal the start accelerator will scan for, unwrapping a leading expansion, or
   * {@code null} if the start plan is not literal-driven.
   */
  private static String drivingLiteral(StartPlan plan) {
    if (plan == null) {
      return null;
    }
    return switch (plan) {
      case StartPlan.Literal lit -> lit.prefix();
      case StartPlan.FixedOffset fo -> fo.fol().literal();
      case StartPlan.FixedOffsetClass unusedFc -> null;
      case StartPlan.LeadingExpansion le ->
          isWideLeadingClass(le.leadingClass()) ? null : drivingLiteral(le.innerPlan());
      case StartPlan.CharClass unusedCc -> null;
      case StartPlan.MultiLiteral unusedMl -> null;
      case StartPlan.LineAnchor unusedLa -> null;
      case StartPlan.None unusedNone -> null;
    };
  }

  /**
   * Returns the character class the start accelerator will scan for, or {@code null} if the start
   * plan is not class-driven. A required class from reject analysis is only worth scanning for
   * separately if it is narrower than this one. See {@link #leadingExpansionDrivingClass} for
   * leading expansions.
   */
  private static CharClassScanInfo drivingCharClass(StartPlan plan) {
    if (plan == null) {
      return null;
    }
    return switch (plan) {
      case StartPlan.CharClass cc -> cc.scanInfo();
      case StartPlan.FixedOffset fo -> fo.leadingClass();
      case StartPlan.FixedOffsetClass fc -> fc.scanInfo();
      case StartPlan.MultiLiteral ml -> ml.fallbackClass();
      case StartPlan.LeadingExpansion le -> leadingExpansionDrivingClass(le);
      case StartPlan.Literal unusedLit -> null;
      case StartPlan.LineAnchor unusedLa -> null;
      case StartPlan.None unusedNone -> null;
    };
  }

  /**
   * Returns the driving class of a leading expansion for reject-plan selection.
   *
   * <p>Usually {@code null}, so the expansion's required class is kept as a reject prefilter even
   * when it is the class the inner accelerator scans for. The prefilter fails the whole call on
   * input without the class before any per-call setup, including once up front in {@code
   * replaceAll}, whereas the leading-expansion accelerator only gets there through its own
   * candidate loop. On {@code UnicodePrefixBenchmark.cjk.absent}, {@code [\u4E00-\u9FFF]+\d+}
   * measured 2.8x faster with the {@code [0-9]} prefilter than without it.
   *
   * <p>The exception is an ASCII leading class in front of a non-selective inner class, such as
   * {@code \d} in {@code [A-Za-z]+\d+}. Such a class occurs in almost any input, so the prefilter
   * rarely rejects, and the accelerator already scans for it with an ASCII kernel; keeping the
   * prefilter made {@code MatcherApiBenchmark.resetAndFind@safere-utf8} 1.09x slower on aarch64.
   * Returning the inner class lets {@code extractRejectPlan} drop a required class that is no
   * narrower. A non-ASCII leading class keeps the prefilter, because there the prefilter's ASCII
   * scan is what makes non-matching input cheap.
   */
  private static CharClassScanInfo leadingExpansionDrivingClass(StartPlan.LeadingExpansion le) {
    if (le.leadingClass().isAscii()
        && le.innerPlan() instanceof StartPlan.CharClass inner
        && !inner.scanInfo().isSelective()) {
      return inner.scanInfo();
    }
    return null;
  }

  /**
   * Returns whether a leading class has more members than a backward walk could usually afford to
   * cross. Such a class drives a leading expansion only when it excludes very few code points; see
   * {@link #extractStartLeadingExpansion}.
   */
  private static boolean isWideLeadingClass(long numRunes) {
    return numRunes > MAX_LEADING_CLASS_RUNES;
  }

  static boolean isWideLeadingClass(CharClassScanInfo leadingClass) {
    return isWideLeadingClass(runeCount(leadingClass.ranges()));
  }

  /**
   * Returns the code points a wide leading class excludes, in increasing order, or null when the
   * class is not wide or excludes more than {@link #MAX_LEADING_CLASS_COMPLEMENT} code points.
   */
  static int[] excludedCodePoints(CharClassScanInfo leadingClass) {
    if (!isWideLeadingClass(leadingClass)) {
      return null;
    }
    int[] ranges = leadingClass.ranges();
    int[] excluded = new int[MAX_LEADING_CLASS_COMPLEMENT];
    int count = 0;
    int next = 0;
    for (int i = 0; i <= ranges.length; i += 2) {
      int lo = i < ranges.length ? ranges[i] : Utils.MAX_RUNE + 1;
      for (int cp = next; cp < lo; cp++) {
        if (count == excluded.length) {
          return null;
        }
        excluded[count++] = cp;
      }
      if (i < ranges.length) {
        next = ranges[i + 1] + 1;
      }
    }
    return Arrays.copyOf(excluded, count);
  }

  /** Returns whether the start plan scans for a literal at the match start. */
  private static boolean hasFixedOffset(StartPlan plan) {
    if (plan == null) {
      return false;
    }
    return switch (plan) {
      case StartPlan.FixedOffset unusedFo -> true;
      case StartPlan.FixedOffsetClass unusedFc -> false;
      case StartPlan.LeadingExpansion le -> hasFixedOffset(le.innerPlan());
      case StartPlan.Literal unusedLit -> false;
      case StartPlan.CharClass unusedCc -> false;
      case StartPlan.MultiLiteral unusedMl -> false;
      case StartPlan.LineAnchor unusedLa -> false;
      case StartPlan.None unusedNone -> false;
    };
  }

  /**
   * Returns whether the start accelerator makes a required character class reject scan redundant.
   *
   * <p>This deliberately does not unwrap {@link StartPlan.LeadingExpansion}, even though its inner
   * plan may be literal-driven. The reject prefilter runs before the match machinery is set up, so
   * it can pay for itself even when the accelerator would go on to search for the same literal.
   * Extending this to leading expansions regressed the UTF-8 arm of rebar's {@code 04-ruff-noqa} by
   * 1.70x.
   */
  private static boolean subsumesRequiredCharClass(StartPlan plan) {
    if (plan == null) {
      return false;
    }
    return switch (plan) {
      case StartPlan.Literal unusedLit -> true;
      case StartPlan.FixedOffset unusedFo -> true;
      case StartPlan.FixedOffsetClass unusedFc -> true;
      case StartPlan.LeadingExpansion unusedLe -> false;
      case StartPlan.CharClass unusedCc -> false;
      case StartPlan.MultiLiteral unusedMl -> false;
      case StartPlan.LineAnchor unusedLa -> false;
      case StartPlan.None unusedNone -> false;
    };
  }

  // --- Bottom-up MultiAnchorWalker ---

  private static final class MultiAnchorWalker extends Walker<NodeAnalysis> {

    private final int flags;
    private final Regexp fullAnalysisRoot;
    // These results align with unwrapCaptures(root).subs; fixed-offset extraction indexes them
    // only when that unwrapped root is a CONCAT.
    private List<NodeAnalysis> rootChildren = List.of();

    MultiAnchorWalker(Regexp root, int flags) {
      this.flags = flags;
      fullAnalysisRoot = unwrapCaptures(root);
    }

    @Override
    protected NodeAnalysis postVisit(
        Regexp node, NodeAnalysis parentArg, NodeAnalysis preArg, List<NodeAnalysis> childArgs) {
      if (WorkCounterConfig.ENABLED) {
        WorkCounter.record();
      }
      NodeAnalysis analysis =
          switch (node.op) {
            case CAPTURE, NON_CAPTURE ->
                childArgs.isEmpty() ? NodeAnalysis.UNKNOWN : childArgs.getFirst();
            case EMPTY_MATCH, WORD_BOUNDARY, NO_WORD_BOUNDARY, BEGIN_TEXT, END_TEXT, END_LINE ->
                NodeAnalysis.EMPTY;
            case BEGIN_LINE ->
                new NodeAnalysis(
                    AsciiWidthRange.ZERO,
                    new StartFacets(
                        PrefixResult.NO_PREFIX,
                        null,
                        null,
                        new Pattern.StartAcceleration(true, false, null),
                        PrefixResult.NO_PREFIX,
                        null,
                        null),
                    RejectFacets.EMPTY,
                    null);
            case LITERAL -> visitLiteral(node);
            case LITERAL_STRING -> visitLiteralString(node);
            case CHAR_CLASS -> visitCharClass(node);
            case CONCAT -> visitConcat(node, childArgs, node == fullAnalysisRoot);
            case ALTERNATE -> visitAlternate(node, childArgs);
            case QUEST -> visitQuest(childArgs);
            case STAR -> visitStar();
            case PLUS -> visitPlus(childArgs);
            case REPEAT -> visitRepeat(node, childArgs);
            // Only the explicit zero-width cases above can prove an empty ASCII prefix.
            default -> NodeAnalysis.UNKNOWN;
          };
      if (node == fullAnalysisRoot) {
        rootChildren = childArgs;
        // Concat already extracts the complete prefix, and atomic nodes build their own scanner.
        if (node.op != RegexpOp.CONCAT
            && node.op != RegexpOp.LITERAL
            && node.op != RegexpOp.LITERAL_STRING
            && node.op != RegexpOp.CHAR_CLASS) {
          analysis = withRootCharClassPrefix(node, analysis);
        }
      }
      return new NodeAnalysis(
          analysis.width(),
          analysis.start(),
          analysis.reject(),
          analysis.atomicRequiredClass(),
          classAnchor(node, analysis, childArgs));
    }

    /**
     * Carries one required class at an exact ASCII offset through the existing bottom-up walk.
     * Variable widths stop offset propagation; optional operands never contribute an anchor.
     */
    private static ClassAnchor classAnchor(
        Regexp node, NodeAnalysis analysis, List<NodeAnalysis> children) {
      return switch (node.op) {
        case LITERAL, LITERAL_STRING, CHAR_CLASS -> {
          CharClassScanInfo scanInfo = analysis.start().charClassPrefix();
          yield usefulClassAnchor(scanInfo) ? new ClassAnchor(scanInfo, 0) : null;
        }
        case CAPTURE, NON_CAPTURE, PLUS ->
            children.isEmpty() ? null : children.getFirst().classAnchor();
        case REPEAT ->
            node.min > 0 && !children.isEmpty() ? children.getFirst().classAnchor() : null;
        case CONCAT -> {
          ClassAnchor best = null;
          int offset = 0;
          for (NodeAnalysis child : children) {
            ClassAnchor candidate = child.classAnchor();
            if (candidate != null) {
              int combinedOffset = addWidth(offset, candidate.offset());
              if (combinedOffset >= 0
                  && (best == null
                      || classSize(candidate.scanInfo()) < classSize(best.scanInfo()))) {
                best = new ClassAnchor(candidate.scanInfo(), combinedOffset);
              }
            }
            if (!child.width().isExactAscii()) {
              break;
            }
            offset = addWidth(offset, child.width().minWidth);
            if (offset < 0) {
              break;
            }
          }
          yield best;
        }
        default -> null;
      };
    }

    private static int classSize(CharClassScanInfo scanInfo) {
      return Long.bitCount(scanInfo.bitmap0()) + Long.bitCount(scanInfo.bitmap1());
    }

    private static boolean usefulClassAnchor(CharClassScanInfo scanInfo) {
      if (scanInfo == null
          || !scanInfo.isAscii()
          || classSize(scanInfo) == 0
          || classSize(scanInfo) > 16) {
        return false;
      }
      // Keep the filter small and exclude classes containing the most common anchor characters.
      // Unlike the leading-class policy, this also admits compact ranges such as ASCII digits.
      int[] ranges = scanInfo.ranges();
      for (int i = 0; i < ranges.length; i += 2) {
        for (int ch = ranges[i]; ch <= ranges[i + 1]; ch++) {
          if (RarityOracle.byteRarity(ch) <= RarityOracle.POISONOUS_ANCHOR_MAX_RARITY) {
            return false;
          }
        }
      }
      return true;
    }

    @Override
    protected NodeAnalysis shortVisit(Regexp re, NodeAnalysis parentArg) {
      return NodeAnalysis.UNKNOWN;
    }

    private static NodeAnalysis visitLiteral(Regexp node) {
      boolean foldCase = (node.flags & ParseFlags.FOLD_CASE) != 0;
      boolean validRune = Utils.isValidRune(node.rune);
      String lit = validRune ? Character.toString(node.rune) : null;
      AsciiWidthRange width =
          node.rune >= 0 && node.rune < 128 && !foldCase
              ? AsciiWidthRange.ONE
              : AsciiWidthRange.INVALID;
      PrefixResult prefix =
          !validRune
              ? PrefixResult.NO_PREFIX
              : foldCase
                  ? new PrefixResult(lit.toLowerCase(Locale.ROOT), true)
                  : new PrefixResult(lit, false);
      CharClass reqClass = literalCharClass(node.rune, node.flags);
      CharClassScanInfo ccPrefix = CharClassScanInfo.fromCharClass(reqClass);
      String reqLit = validRune && !foldCase ? lit : null;
      return new NodeAnalysis(
          width,
          new StartFacets(prefix, ccPrefix, null, null, prefix, ccPrefix, null),
          new RejectFacets(
              reqLit,
              reqLit != null ? RarityOracle.literalSelectivityScore(reqLit) : 0,
              reqClass,
              null,
              null,
              null),
          reqClass);
    }

    private static NodeAnalysis visitLiteralString(Regexp node) {
      boolean foldCase = (node.flags & ParseFlags.FOLD_CASE) != 0;
      boolean validRunes = areAllValidRunes(node.runes);
      String lit = validRunes ? new String(node.runes, 0, node.runes.length) : null;
      AsciiWidthRange width = AsciiWidthRangeWalker.literalStringWidth(node);
      PrefixResult prefix =
          !validRunes
              ? PrefixResult.NO_PREFIX
              : foldCase
                  ? new PrefixResult(lit.toLowerCase(Locale.ROOT), true)
                  : new PrefixResult(lit, false);
      // bestRequiredLiteral only feeds DisjointLiterals. A lone surrogate is safe on String inputs
      // because any String match contains the same UTF-16 code unit, while DisjointLiterals.create
      // omits branches with unpaired surrogates from its UTF-8 table (UTF-8 inputs never decode
      // surrogate code points). Adjacent high/low surrogate runes are still excluded here because a
      // String literal would coalesce them into a supplementary code point.
      String reqLit =
          !foldCase && canRepresentAsCodePointString(node.runes) && node.runes.length >= 1
              ? (lit != null ? lit : new String(node.runes, 0, node.runes.length))
              : null;
      CharClass reqClass =
          (node.runes != null && node.runes.length > 0)
              ? literalCharClass(node.runes[0], node.flags)
              : null;
      CharClassScanInfo ccPrefix =
          reqClass != null ? CharClassScanInfo.fromCharClass(reqClass) : null;
      return new NodeAnalysis(
          width,
          new StartFacets(prefix, ccPrefix, null, null, prefix, ccPrefix, null),
          new RejectFacets(
              reqLit,
              reqLit != null ? RarityOracle.literalSelectivityScore(reqLit) : 0,
              reqClass,
              null,
              null,
              null),
          reqClass);
    }

    private static NodeAnalysis visitCharClass(Regexp node) {
      AsciiWidthRange width = AsciiWidthRangeWalker.characterClassWidth(node);
      CharClass cc = node.charClass;
      CharClassScanInfo ccPrefix =
          (cc != null && !cc.isEmpty() && cc.numRunes() <= 0x80000)
              ? CharClassScanInfo.fromCharClass(cc)
              : null;
      int rep = simpleFoldClassRepresentative(cc);
      PrefixResult prefix =
          rep >= 0
              ? new PrefixResult(Character.toString(rep).toLowerCase(Locale.ROOT), true)
              : PrefixResult.NO_PREFIX;
      return new NodeAnalysis(
          width,
          new StartFacets(prefix, ccPrefix, null, null, prefix, ccPrefix, null),
          new RejectFacets(null, 0, (cc != null && !cc.isEmpty()) ? cc : null, null, null, null),
          cc != null && !cc.isEmpty() ? cc : null);
    }

    private NodeAnalysis visitConcat(
        Regexp node, List<NodeAnalysis> children, boolean fullAnalysis) {
      if (children.isEmpty()) {
        return NodeAnalysis.EMPTY;
      }
      AsciiWidthRange width = AsciiWidthRange.ZERO;
      for (NodeAnalysis c : children) {
        width = concatenateWidths(width, c.width());
        if (!width.isValid()) {
          break;
        }
      }

      if (!fullAnalysis) {
        return visitNestedConcat(node, children, width);
      }

      // Prefix
      PrefixResult prefix = extractPrefix(node);

      // Fixed-offset literal
      FixedOffsetLiteral fol = extractFixedOffsetLiteral(node, children);

      // Best required literal across concat
      String exactLit = extractExactAsciiLiteral(node);
      String bestReqLit = exactLit != null && exactLit.length() >= 2 ? exactLit : null;
      int bestReqScore = bestReqLit != null ? RarityOracle.literalSelectivityScore(bestReqLit) : 0;
      for (NodeAnalysis c : children) {
        String childReq = c.reject().bestRequiredLiteral();
        if (childReq != null && childReq.length() >= 2) {
          int score = c.reject().bestRequiredLiteralScore();
          if (bestReqLit == null || score > bestReqScore) {
            bestReqLit = childReq;
            bestReqScore = score;
          }
        }
      }

      // Best required class
      CharClass bestReqClass = null;
      for (NodeAnalysis c : children) {
        CharClass childReqClass = c.reject().bestRequiredClass();
        if (childReqClass != null) {
          if (bestReqClass == null || moreSelective(childReqClass, bestReqClass)) {
            bestReqClass = childReqClass;
          }
        }
      }

      // Disjoint required literals
      String[] disjoint = null;
      if (node.subs != null && !node.subs.isEmpty()) {
        Regexp first = unwrapCaptures(node.subs.get(0));
        if (first == null || (first.op != RegexpOp.BEGIN_TEXT && first.op != RegexpOp.BEGIN_LINE)) {
          for (NodeAnalysis c : children) {
            if (c.reject().disjointRequiredLiterals() != null) {
              disjoint = c.reject().disjointRequiredLiterals();
              break;
            }
          }
        }
      }

      // End-anchored suffix & char class
      Pattern.SuffixInfo endSuffix = extractEndAnchoredSuffix(node, flags);
      Pattern.EndAnchoredCharClassInfo endClass = extractEndAnchoredCharClass(node, flags);

      // Start acceleration
      Pattern.StartAcceleration startAcc = extractStartAcceleration(node);

      // Anchored prefix
      Regexp anchoredCandidate = firstPrefixCandidateAfterTextAnchor(node);
      PrefixResult anchoredPrefix =
          anchoredCandidate != null
              ? extractPrefixFromCandidate(anchoredCandidate)
              : PrefixResult.NO_PREFIX;
      CharClassScanInfo anchoredCc =
          anchoredCandidate != null ? extractCharClassPrefix(anchoredCandidate) : null;

      CharClassScanInfo ccPrefix = extractCharClassPrefix(node);
      StartFacets start =
          new StartFacets(prefix, ccPrefix, fol, startAcc, anchoredPrefix, anchoredCc, null);
      RejectFacets reject =
          new RejectFacets(bestReqLit, bestReqScore, bestReqClass, disjoint, endSuffix, endClass);

      return new NodeAnalysis(width, start, reject, null);
    }

    private static NodeAnalysis visitNestedConcat(
        Regexp node, List<NodeAnalysis> children, AsciiWidthRange width) {
      StartFacets leading = StartFacets.EMPTY;
      for (int index = 0; index < children.size(); index++) {
        if (isLeadingZeroWidth(node.subs.get(index))) {
          continue;
        }
        leading = children.get(index).start();
        break;
      }

      String bestRequiredLiteral = null;
      int bestRequiredScore = 0;
      CharClass bestRequiredClass = null;
      String[] disjointRequiredLiterals = null;
      for (NodeAnalysis child : children) {
        String candidateLiteral = child.reject().bestRequiredLiteral();
        if (candidateLiteral != null && candidateLiteral.length() >= 2) {
          int candidateScore = child.reject().bestRequiredLiteralScore();
          if (bestRequiredLiteral == null || candidateScore > bestRequiredScore) {
            bestRequiredLiteral = candidateLiteral;
            bestRequiredScore = candidateScore;
          }
        }
        CharClass candidateClass = child.reject().bestRequiredClass();
        if (candidateClass != null
            && (bestRequiredClass == null || moreSelective(candidateClass, bestRequiredClass))) {
          bestRequiredClass = candidateClass;
        }
        if (disjointRequiredLiterals == null && child.reject().disjointRequiredLiterals() != null) {
          disjointRequiredLiterals = child.reject().disjointRequiredLiterals();
        }
      }

      StartFacets start =
          new StartFacets(
              leading.prefix(),
              leading.charClassPrefix(),
              null,
              leading.startAcceleration(),
              leading.anchoredPrefix(),
              leading.anchoredCharClassPrefix(),
              null);
      RejectFacets reject =
          new RejectFacets(
              bestRequiredLiteral,
              bestRequiredScore,
              bestRequiredClass,
              disjointRequiredLiterals,
              null,
              null);
      return new NodeAnalysis(width, start, reject, null);
    }

    private static NodeAnalysis visitAlternate(Regexp node, List<NodeAnalysis> children) {
      if (children.isEmpty()) {
        return NodeAnalysis.UNKNOWN;
      }
      List<AsciiWidthRange> widths = new ArrayList<>(children.size());
      for (NodeAnalysis c : children) {
        widths.add(c.width());
      }
      AsciiWidthRange width = AsciiWidthRangeWalker.alternateWidth(widths);

      // Literal alternation
      String[] litAlt = extractLiteralAlternation(node);

      // Required match class across branches
      CharClass reqClass = unionRequiredCharClasses(children);

      // Disjoint required literals from branches
      String[] disjoint = combineDisjointRequiredLiterals(children);

      StartFacets start =
          new StartFacets(
              PrefixResult.NO_PREFIX, null, null, null, PrefixResult.NO_PREFIX, null, litAlt);
      RejectFacets reject = new RejectFacets(null, 0, reqClass, disjoint, null, null);

      return new NodeAnalysis(width, start, reject, null);
    }

    private static NodeAnalysis withRootCharClassPrefix(Regexp node, NodeAnalysis analysis) {
      StartFacets start = analysis.start();
      StartFacets completed =
          new StartFacets(
              start.prefix(),
              extractCharClassPrefix(node),
              start.fixedOffsetLiteral(),
              start.startAcceleration(),
              start.anchoredPrefix(),
              start.anchoredCharClassPrefix(),
              start.literalAlternation());
      return new NodeAnalysis(
          analysis.width(), completed, analysis.reject(), analysis.atomicRequiredClass());
    }

    private static CharClass unionRequiredCharClasses(List<NodeAnalysis> children) {
      CharClassBuilder union = new CharClassBuilder();
      for (NodeAnalysis child : children) {
        CharClass required = child.atomicRequiredClass();
        if (required == null) {
          return null;
        }
        union.addCharClass(required);
      }
      CharClass result = union.build();
      return result.isEmpty() ? null : result;
    }

    private static NodeAnalysis visitQuest(List<NodeAnalysis> children) {
      if (children.isEmpty()) {
        return NodeAnalysis.UNKNOWN;
      }
      AsciiWidthRange width = AsciiWidthRangeWalker.optionalWidth(children.getFirst().width());
      return new NodeAnalysis(width, StartFacets.EMPTY, RejectFacets.EMPTY, null);
    }

    private static NodeAnalysis visitStar() {
      return new NodeAnalysis(AsciiWidthRange.INVALID, StartFacets.EMPTY, RejectFacets.EMPTY, null);
    }

    private static NodeAnalysis visitPlus(List<NodeAnalysis> children) {
      if (children.isEmpty()) {
        return NodeAnalysis.UNKNOWN;
      }
      NodeAnalysis child = children.getFirst();
      AsciiWidthRange width = AsciiWidthRange.INVALID;
      StartFacets start =
          new StartFacets(
              child.start().prefix(),
              child.start().charClassPrefix(),
              null,
              null,
              child.start().anchoredPrefix(),
              child.start().anchoredCharClassPrefix(),
              null);
      RejectFacets reject =
          new RejectFacets(
              child.reject().bestRequiredLiteral(),
              child.reject().bestRequiredLiteralScore(),
              child.reject().bestRequiredClass(),
              null,
              null,
              null);
      return new NodeAnalysis(width, start, reject, child.atomicRequiredClass());
    }

    private static NodeAnalysis visitRepeat(Regexp node, List<NodeAnalysis> children) {
      if (children.isEmpty()) {
        return NodeAnalysis.UNKNOWN;
      }
      NodeAnalysis child = children.getFirst();
      AsciiWidthRange width = AsciiWidthRangeWalker.repeatWidth(node, child.width());
      StartFacets start =
          node.min > 0
              ? new StartFacets(
                  child.start().prefix(),
                  child.start().charClassPrefix(),
                  null,
                  null,
                  child.start().anchoredPrefix(),
                  child.start().anchoredCharClassPrefix(),
                  null)
              : StartFacets.EMPTY;
      RejectFacets reject =
          node.min > 0
              ? new RejectFacets(
                  child.reject().bestRequiredLiteral(),
                  child.reject().bestRequiredLiteralScore(),
                  child.reject().bestRequiredClass(),
                  null,
                  null,
                  null)
              : RejectFacets.EMPTY;
      return new NodeAnalysis(
          width, start, reject, node.min > 0 ? child.atomicRequiredClass() : null);
    }
  }

  // --- Helper methods for chain, gap, and anchor extraction ---

  static Regexp factorAlternations(Regexp re) {
    // These are whole-tree properties. Factoring introduces only literals and structural nodes,
    // so descendants and newly factored nodes cannot acquire captures or assertions.
    if (re == null || hasFactoringBarrier(re)) {
      return re;
    }
    return factorAlternations(re, 0);
  }

  private static final int MAX_FACTOR_DEPTH = 16;

  private static Regexp factorAlternations(Regexp re, int depth) {
    if (re == null || depth > MAX_FACTOR_DEPTH) {
      return re;
    }
    if (re.subs != null && !re.subs.isEmpty()) {
      List<Regexp> newSubs = new ArrayList<>(re.subs.size());
      boolean changed = false;
      for (Regexp sub : re.subs) {
        Regexp factored = factorAlternations(sub, depth + 1);
        if (re.op == RegexpOp.CONCAT
            && factored.op == RegexpOp.CONCAT
            && factored != sub
            && sub.op == RegexpOp.ALTERNATE
            && factored.subs != null) {
          for (Regexp child : factored.subs) {
            appendAndCoalesce(newSubs, child);
          }
          changed = true;
        } else if (re.op == RegexpOp.CONCAT) {
          appendAndCoalesce(newSubs, factored);
          if (factored != sub || newSubs.size() != re.subs.size()) {
            changed = true;
          }
        } else {
          newSubs.add(factored);
          if (factored != sub) {
            changed = true;
          }
        }
      }
      if (changed) {
        re = copyWithSubs(re, newSubs);
      }
    }
    if (re.op == RegexpOp.ALTERNATE && re.subs != null && re.subs.size() >= 2) {
      return factorAlternate(re);
    }
    return re;
  }

  private static void appendAndCoalesce(List<Regexp> subs, Regexp node) {
    if (node == null) {
      return;
    }
    if (!subs.isEmpty()) {
      Regexp prev = subs.get(subs.size() - 1);
      int[] prevRunes = extractRunes(prev);
      int[] currRunes = extractRunes(node);
      if (prevRunes != null
          && currRunes != null
          && (prev.flags & ParseFlags.FOLD_CASE) == (node.flags & ParseFlags.FOLD_CASE)) {
        int[] merged = new int[prevRunes.length + currRunes.length];
        System.arraycopy(prevRunes, 0, merged, 0, prevRunes.length);
        System.arraycopy(currRunes, 0, merged, prevRunes.length, currRunes.length);
        subs.set(subs.size() - 1, Regexp.literalString(merged, prev.flags));
        return;
      }
    }
    subs.add(node);
  }

  private static int[] extractRunes(Regexp re) {
    if (re == null) {
      return null;
    }
    if (re.op == RegexpOp.LITERAL) {
      return new int[] {re.rune};
    }
    if (re.op == RegexpOp.LITERAL_STRING && re.runes != null) {
      return re.runes;
    }
    return null;
  }

  private static Regexp copyWithSubs(Regexp re, List<Regexp> newSubs) {
    Regexp copy = new Regexp(re.op, re.flags);
    copy.rune = re.rune;
    copy.runes = re.runes;
    copy.min = re.min;
    copy.max = re.max;
    copy.cap = re.cap;
    copy.name = re.name;
    copy.charClass = re.charClass;
    copy.subs = List.copyOf(newSubs);
    return copy;
  }

  private static Regexp factorAlternate(Regexp re) {
    if (re == null || re.op != RegexpOp.ALTERNATE || re.subs == null || re.subs.size() < 2) {
      return re;
    }

    // 1. Common literal prefix factoring
    List<int[]> leadingRunesList = new ArrayList<>(re.subs.size());
    boolean allHaveLeading = true;
    for (Regexp sub : re.subs) {
      int[] r = extractLeadingRunes(sub);
      if (r == null || r.length == 0) {
        allHaveLeading = false;
        break;
      }
      leadingRunesList.add(r);
    }

    if (allHaveLeading) {
      int lcp = commonPrefixLength(leadingRunesList);
      if (lcp >= 2) {
        Integer prefixFlags = commonLeadingLiteralFlags(re.subs, lcp);
        if (prefixFlags == null) {
          return re;
        }
        int[] prefixRunes = Arrays.copyOf(leadingRunesList.get(0), lcp);
        List<Regexp> remainders = new ArrayList<>(re.subs.size());
        for (Regexp sub : re.subs) {
          remainders.add(stripLeadingRunes(sub, lcp));
        }
        Regexp prefixNode =
            prefixRunes.length == 1
                ? Regexp.literal(prefixRunes[0], prefixFlags)
                : Regexp.literalString(prefixRunes, prefixFlags);
        Regexp alternateNode = Regexp.alternate(remainders, re.flags);
        return Regexp.concat(List.of(prefixNode, alternateNode), re.flags);
      }
    }

    return re;
  }

  private static Integer commonLeadingLiteralFlags(List<Regexp> alternatives, int runeCount) {
    Integer commonFlags = null;
    for (Regexp alternative : alternatives) {
      Integer flags = homogeneousLeadingLiteralFlags(alternative, runeCount);
      if (flags == null) {
        return null;
      }
      if (commonFlags == null) {
        commonFlags = flags;
      } else if (((commonFlags ^ flags) & ParseFlags.FOLD_CASE) != 0) {
        return null;
      }
    }
    return commonFlags;
  }

  private static Integer homogeneousLeadingLiteralFlags(Regexp re, int runeCount) {
    List<Regexp> leading = re.op == RegexpOp.CONCAT && re.subs != null ? re.subs : List.of(re);
    Integer commonFlags = null;
    int remaining = runeCount;
    for (Regexp node : leading) {
      int nodeLength = literalRunesLength(node);
      if (nodeLength == 0) {
        break;
      }
      if (commonFlags == null) {
        commonFlags = node.flags;
      } else if (((commonFlags ^ node.flags) & ParseFlags.FOLD_CASE) != 0) {
        return null;
      }
      remaining -= Math.min(remaining, nodeLength);
      if (remaining == 0) {
        return commonFlags;
      }
    }
    return null;
  }

  private static boolean hasFactoringBarrier(Regexp re) {
    if (re == null) {
      return false;
    }
    Deque<Regexp> pending = new ArrayDeque<>();
    pending.addLast(re);
    while (!pending.isEmpty()) {
      Regexp current = pending.removeLast();
      if (current.op == RegexpOp.CAPTURE || current.cap != 0) {
        return true;
      }
      switch (current.op) {
        case BEGIN_LINE, END_LINE, BEGIN_TEXT, END_TEXT, WORD_BOUNDARY, NO_WORD_BOUNDARY -> {
          return true;
        }
        default -> {
          if (current.subs != null) {
            for (Regexp sub : current.subs) {
              if (sub != null) {
                pending.addLast(sub);
              }
            }
          }
        }
      }
    }
    return false;
  }

  private static int[] extractLeadingRunes(Regexp sub) {
    if (sub == null) {
      return null;
    }
    if (sub.op == RegexpOp.LITERAL) {
      return new int[] {sub.rune};
    }
    if (sub.op == RegexpOp.LITERAL_STRING && sub.runes != null) {
      return sub.runes;
    }
    if (sub.op == RegexpOp.CONCAT && sub.subs != null && !sub.subs.isEmpty()) {
      List<Integer> collected = new ArrayList<>();
      for (Regexp c : sub.subs) {
        if (c == null) {
          break;
        }
        if (c.op == RegexpOp.LITERAL) {
          collected.add(c.rune);
        } else if (c.op == RegexpOp.LITERAL_STRING && c.runes != null) {
          for (int r : c.runes) {
            collected.add(r);
          }
        } else {
          break;
        }
      }
      if (!collected.isEmpty()) {
        int[] res = new int[collected.size()];
        for (int i = 0; i < res.length; i++) {
          res[i] = collected.get(i);
        }
        return res;
      }
    }
    return null;
  }

  private static int commonPrefixLength(List<int[]> list) {
    if (list.isEmpty()) {
      return 0;
    }
    int[] first = list.get(0);
    int minLen = first.length;
    for (int i = 1; i < list.size(); i++) {
      minLen = Math.min(minLen, list.get(i).length);
    }
    int len = 0;
    for (int col = 0; col < minLen; col++) {
      int r = first[col];
      for (int i = 1; i < list.size(); i++) {
        if (list.get(i)[col] != r) {
          return len;
        }
      }
      len++;
    }
    return len;
  }

  private static int literalRunesLength(Regexp sub) {
    if (sub == null) {
      return 0;
    }
    if (sub.op == RegexpOp.LITERAL) {
      return 1;
    }
    if (sub.op == RegexpOp.LITERAL_STRING && sub.runes != null) {
      return sub.runes.length;
    }
    return 0;
  }

  private static Regexp stripLeadingRunes(Regexp re, int count) {
    if (count <= 0) {
      return re;
    }
    if (re.op == RegexpOp.LITERAL) {
      return Regexp.emptyMatch(re.flags);
    }
    if (re.op == RegexpOp.LITERAL_STRING && re.runes != null) {
      if (count >= re.runes.length) {
        return Regexp.emptyMatch(re.flags);
      }
      int[] remainder = Arrays.copyOfRange(re.runes, count, re.runes.length);
      return remainder.length == 1
          ? Regexp.literal(remainder[0], re.flags)
          : Regexp.literalString(remainder, re.flags);
    }
    if (re.op == RegexpOp.CONCAT && re.subs != null) {
      List<Regexp> newSubs = new ArrayList<>();
      int remainingToStrip = count;
      for (Regexp sub : re.subs) {
        if (remainingToStrip <= 0) {
          newSubs.add(sub);
          continue;
        }
        int subLen = literalRunesLength(sub);
        if (subLen > 0 && subLen <= remainingToStrip) {
          remainingToStrip -= subLen;
        } else if (subLen > remainingToStrip) {
          Regexp strippedSub = stripLeadingRunes(sub, remainingToStrip);
          if (strippedSub != null && strippedSub.op != RegexpOp.EMPTY_MATCH) {
            newSubs.add(strippedSub);
          }
          remainingToStrip = 0;
        } else {
          newSubs.add(sub);
        }
      }
      if (newSubs.isEmpty()) {
        return Regexp.emptyMatch(re.flags);
      }
      if (newSubs.size() == 1) {
        return newSubs.get(0);
      }
      return Regexp.concat(newSubs, re.flags);
    }
    return re;
  }

  private static MultiAnchorDescriptor.StartPlan.LeadingExpansion extractStartLeadingExpansion(
      Regexp re) {
    if (re == null) {
      return null;
    }
    re = unwrapCaptures(re);
    if (re == null || re.op != RegexpOp.CONCAT || re.nsub() < 2) {
      return null;
    }

    int idx = 0;
    while (idx < re.nsub() && isLeadingZeroWidth(re.subs.get(idx))) {
      idx++;
    }
    if (idx >= re.nsub() - 1) {
      return null;
    }

    Regexp first = unwrapCaptures(re.subs.get(idx));
    if (first == null) {
      return null;
    }

    int minRepetition;
    int maxRepetition;
    Regexp repeated;
    switch (first.op) {
      case STAR -> {
        minRepetition = 0;
        maxRepetition = Integer.MAX_VALUE;
        repeated = unwrapCaptures(first.sub());
      }
      case PLUS -> {
        minRepetition = 1;
        maxRepetition = Integer.MAX_VALUE;
        repeated = unwrapCaptures(first.sub());
      }
      case REPEAT -> {
        minRepetition = first.min;
        maxRepetition = first.max == -1 ? Integer.MAX_VALUE : first.max;
        repeated = unwrapCaptures(first.sub());
      }
      case QUEST -> {
        minRepetition = 0;
        maxRepetition = 1;
        repeated = unwrapCaptures(first.sub());
      }
      default -> {
        return null;
      }
    }

    if (repeated == null || repeated.op == RegexpOp.ANY_CHAR || repeated.op == RegexpOp.ANY_BYTE) {
      return null;
    }

    CharClassScanInfo leadingClass;
    if (repeated.op == RegexpOp.CHAR_CLASS
        && repeated.charClass != null
        && !repeated.charClass.isEmpty()) {
      leadingClass = CharClassScanInfo.fromCharClass(repeated.charClass);
    } else if (repeated.op == RegexpOp.LITERAL) {
      leadingClass =
          CharClassScanInfo.fromCharClass(literalCharClass(repeated.rune, repeated.flags));
    } else {
      return null;
    }

    if (leadingClass == null) {
      return null;
    }

    int numRunes = 0;
    int[] ranges = leadingClass.ranges();
    if (ranges != null) {
      for (int i = 0; i < ranges.length; i += 2) {
        numRunes += (ranges[i + 1] - ranges[i] + 1);
      }
    }
    // A large class usually means the backward walk would cross most of the input. The exception
    // is a class that excludes only a few code points, such as non-DOTALL `.` (the line
    // terminators) or `[^;]`: there the walk stops at the nearest excluded code point, so for
    // `.*error` the candidate is the start of the line holding the inner hit. Such a class has few
    // ranges, so the walk's membership test stays cheap. DOTALL `.` (ANY_CHAR) is still excluded
    // above: its walk never stops before the search start.
    boolean wideLeadingClass = isWideLeadingClass(numRunes);
    if (wideLeadingClass && Utils.MAX_RUNE + 1 - numRunes > MAX_LEADING_CLASS_COMPLEMENT) {
      return null;
    }

    List<Regexp> tailSubs = re.subs.subList(idx + 1, re.nsub());
    Regexp tail = tailSubs.size() == 1 ? tailSubs.getFirst() : Regexp.concat(tailSubs, 0);

    MultiAnchorDescriptor.StartPlan inner = extractStartPlan(tail, false);
    if (inner == null
        || inner instanceof MultiAnchorDescriptor.StartPlan.None
        // Keep class offsets scoped to their exact ASCII prefix, without a backward-expansion
        // wrapper that can revisit variable-width leading context.
        || inner instanceof MultiAnchorDescriptor.StartPlan.FixedOffsetClass
        || inner instanceof MultiAnchorDescriptor.StartPlan.LeadingExpansion) {
      return null;
    }
    // Before a wide class, only an exact literal search finds inner candidates sparse enough to
    // pay for walking back to the line start. Class and multi-literal scans may report every
    // position, or decline and report the search start.
    if (wideLeadingClass
        && !(inner instanceof MultiAnchorDescriptor.StartPlan.Literal
            || inner instanceof MultiAnchorDescriptor.StartPlan.FixedOffset)) {
      return null;
    }
    // An optional leading character in front of a class too common to scan for, such as `-?\d+`,
    // gets no start accelerator, and the expansion would only make extractRejectPlan drop the
    // inner class's reject prefilter. Leave such patterns with no start plan, as before `?` was
    // supported, so they keep the reject.
    if (first.op == RegexpOp.QUEST
        && inner instanceof MultiAnchorDescriptor.StartPlan.CharClass cc
        && !cc.scanInfo().isSelective()) {
      return null;
    }

    return new MultiAnchorDescriptor.StartPlan.LeadingExpansion(
        leadingClass, minRepetition, maxRepetition, idx > 0, inner);
  }

  static PrefixResult extractPrefix(Regexp re) {
    PrefixResult direct = extractPrefixFromCandidate(firstPrefixCandidate(re));
    return direct.prefix() != null ? direct : extractUnicodeFoldedPrefix(re);
  }

  static PrefixResult extractUnicodeFoldedPrefix(Regexp re) {
    Deque<Regexp> work = new ArrayDeque<>();
    work.add(re);
    StringBuilder prefix = new StringBuilder();
    boolean sawFoldClass = false;

    while (!work.isEmpty()) {
      Regexp node = unwrapCaptures(work.removeFirst());
      if (node == null) {
        continue;
      }
      if (node.op == RegexpOp.CONCAT) {
        for (int i = node.subs.size() - 1; i >= 0; i--) {
          work.addFirst(node.subs.get(i));
        }
        continue;
      }
      if (isLeadingZeroWidth(node)) {
        continue;
      }

      if (node.op == RegexpOp.CHAR_CLASS) {
        int representative = simpleFoldClassRepresentative(node.charClass);
        if (representative < 0) {
          break;
        }
        prefix.appendCodePoint(representative);
        sawFoldClass = true;
        continue;
      }

      if (node.op == RegexpOp.LITERAL) {
        if (!appendFoldCompatibleLiteral(prefix, node.rune, node.flags)) {
          break;
        }
        continue;
      }
      if (node.op == RegexpOp.LITERAL_STRING && node.runes != null) {
        boolean compatible = true;
        for (int rune : node.runes) {
          if (!appendFoldCompatibleLiteral(prefix, rune, node.flags)) {
            compatible = false;
            break;
          }
        }
        if (compatible) {
          continue;
        }
      }
      break;
    }

    return sawFoldClass && !prefix.isEmpty()
        ? new PrefixResult(prefix.toString().toLowerCase(Locale.ROOT), true)
        : new PrefixResult(null, false);
  }

  private static boolean appendFoldCompatibleLiteral(StringBuilder prefix, int rune, int flags) {
    if (!Utils.isValidRune(rune)) {
      return false;
    }
    if ((flags & ParseFlags.FOLD_CASE) == 0 && Inst.simpleFold(rune) != rune) {
      return false;
    }
    prefix.appendCodePoint(rune);
    return true;
  }

  private static int simpleFoldClassRepresentative(CharClass charClass) {
    if (charClass == null
        || charClass.isEmpty()
        || charClass.numRunes() > MAX_UNICODE_FOLD_CLASS_RUNES) {
      return -1;
    }
    int representative = charClass.lo(0);
    int utf8Width = utf8Width(representative);
    int folded = Inst.simpleFold(representative);
    if (folded == representative) {
      return -1;
    }
    // A folded class must contain the whole simple-fold cycle. Reject ordinary classes before
    // asking for the full Unicode closure, whose index is expensive to initialize.
    int cycleLength = 1;
    while (folded != representative) {
      if (!charClass.contains(folded) || utf8Width(folded) != utf8Width) {
        return -1;
      }
      cycleLength++;
      folded = Inst.simpleFold(folded);
    }
    // Callers match the representative with simple-fold literal search, so the class must be
    // exactly the cycle. The Unicode closure of I and i also contains U+0130 and U+0131, which the
    // simple-fold cycle does not visit.
    if (charClass.numRunes() != cycleLength) {
      return -1;
    }
    CharClass expected =
        literalCharClass(representative, ParseFlags.FOLD_CASE | ParseFlags.UNICODE_CASE);
    if (expected.numRanges() != charClass.numRanges()) {
      return -1;
    }
    for (int i = 0; i < expected.numRanges(); i++) {
      if (expected.lo(i) != charClass.lo(i) || expected.hi(i) != charClass.hi(i)) {
        return -1;
      }
    }
    return representative;
  }

  private static int utf8Width(int codePoint) {
    if (codePoint <= 0x7F) {
      return 1;
    }
    if (codePoint <= 0x7FF) {
      return 2;
    }
    return codePoint <= 0xFFFF ? 3 : 4;
  }

  private static PrefixResult extractPrefixFromCandidate(Regexp node) {
    if (node == null) {
      return new PrefixResult(null, false);
    }

    boolean foldCase = (node.flags & ParseFlags.FOLD_CASE) != 0;
    StringBuilder sb = new StringBuilder();
    if (node.op == RegexpOp.LITERAL) {
      if (!Utils.isValidRune(node.rune)) {
        return new PrefixResult(null, false);
      }
      sb.appendCodePoint(node.rune);
    } else if (node.op == RegexpOp.LITERAL_STRING && areAllValidRunes(node.runes)) {
      for (int r : node.runes) {
        sb.appendCodePoint(r);
      }
    } else {
      return new PrefixResult(null, false);
    }

    if (sb.isEmpty()) {
      return new PrefixResult(null, false);
    }

    String prefix = foldCase ? sb.toString().toLowerCase(Locale.ROOT) : sb.toString();
    return new PrefixResult(prefix, foldCase);
  }

  static Regexp firstPrefixCandidate(Regexp re) {
    Deque<Regexp> stack = new ArrayDeque<>();
    stack.push(re);
    while (!stack.isEmpty()) {
      Regexp node = unwrapCaptures(stack.pop());
      if (node == null || isLeadingZeroWidth(node)) {
        continue;
      }
      if (node.op == RegexpOp.CONCAT) {
        for (int i = node.subs.size() - 1; i >= 0; i--) {
          stack.push(node.subs.get(i));
        }
      } else {
        return node;
      }
    }
    return null;
  }

  static Regexp firstPrefixCandidateAfterTextAnchor(Regexp re) {
    Deque<Regexp> stack = new ArrayDeque<>();
    stack.push(re);
    boolean sawTextAnchor = false;
    while (!stack.isEmpty()) {
      Regexp node = unwrapCaptures(stack.pop());
      if (node == null) {
        continue;
      }
      if (node.op == RegexpOp.CONCAT && node.subs != null) {
        for (int i = node.subs.size() - 1; i >= 0; i--) {
          stack.push(node.subs.get(i));
        }
        continue;
      }
      if (!sawTextAnchor) {
        if (node.op == RegexpOp.BEGIN_TEXT) {
          sawTextAnchor = true;
          continue;
        }
        if (isLeadingZeroWidth(node)) {
          continue;
        }
        return null;
      }
      if (!isLeadingZeroWidth(node)) {
        return node;
      }
    }
    return null;
  }

  static String extractExactAsciiLiteral(Regexp re) {
    if (re == null) {
      return null;
    }
    StringBuilder literal = new StringBuilder();
    Deque<Regexp> pending = new ArrayDeque<>();
    pending.push(re);
    while (!pending.isEmpty()) {
      Regexp node = unwrapCaptures(pending.pop());
      if (node == null || (node.flags & ParseFlags.FOLD_CASE) != 0) {
        return null;
      }
      if (node.op == RegexpOp.LITERAL && node.rune >= 0 && node.rune < 128) {
        literal.append((char) node.rune);
        continue;
      }
      if (node.op == RegexpOp.LITERAL_STRING && node.runes != null && node.runes.length > 0) {
        for (int rune : node.runes) {
          if (rune < 0 || rune >= 128) {
            return null;
          }
          literal.append((char) rune);
        }
        continue;
      }
      if (node.op == RegexpOp.CONCAT && node.subs != null) {
        for (int index = node.subs.size() - 1; index >= 0; index--) {
          pending.push(node.subs.get(index));
        }
        continue;
      }
      return null;
    }
    return literal.isEmpty() ? null : literal.toString();
  }

  static String extractExactAsciiLiteralIgnoringCase(Regexp re) {
    if (re == null) {
      return null;
    }
    StringBuilder literal = new StringBuilder();
    Deque<Regexp> pending = new ArrayDeque<>();
    pending.push(re);
    while (!pending.isEmpty()) {
      Regexp node = unwrapCaptures(pending.pop());
      if (node == null) {
        return null;
      }
      if (node.op == RegexpOp.LITERAL && node.rune >= 0 && node.rune < 128) {
        literal.append((char) node.rune);
        continue;
      }
      if (node.op == RegexpOp.LITERAL_STRING && node.runes != null && node.runes.length > 0) {
        for (int rune : node.runes) {
          if (rune < 0 || rune >= 128) {
            return null;
          }
          literal.append((char) rune);
        }
        continue;
      }
      if (node.op == RegexpOp.CONCAT && node.subs != null) {
        for (int index = node.subs.size() - 1; index >= 0; index--) {
          pending.push(node.subs.get(index));
        }
        continue;
      }
      return null;
    }
    return literal.isEmpty() ? null : literal.toString();
  }

  static CharClassScanInfo extractCharClassPrefix(Regexp re) {
    CharClassBuilder builder = new CharClassBuilder();
    Deque<Regexp> work = new ArrayDeque<>();
    work.add(re);

    while (!work.isEmpty()) {
      Regexp node = work.removeLast();

      for (; ; ) {
        node = unwrapCaptures(node);
        if (node == null) {
          return null;
        }
        if (node.op == RegexpOp.CONCAT && node.nsub() > 0) {
          int i = 0;
          while (i < node.nsub() && isLeadingZeroWidth(node.subs.get(i))) {
            i++;
          }
          if (i < node.nsub()) {
            node = node.subs.get(i);
            continue;
          }
          return null;
        }
        if (node.op == RegexpOp.PLUS || (node.op == RegexpOp.REPEAT && node.min >= 1)) {
          node = node.sub();
          continue;
        }
        break;
      }

      switch (node.op) {
        case LITERAL -> {
          builder.addCharClass(literalCharClass(node.rune, node.flags));
        }
        case LITERAL_STRING -> {
          if (node.runes == null || node.runes.length == 0) {
            return null;
          }
          builder.addCharClass(literalCharClass(node.runes[0], node.flags));
        }
        case CHAR_CLASS -> {
          if (node.charClass == null || node.charClass.isEmpty()) {
            return null;
          }
          builder.addCharClass(node.charClass);
        }
        case ALTERNATE -> {
          if (node.nsub() == 0) {
            return null;
          }
          for (Regexp sub : node.subs) {
            work.add(sub);
          }
        }
        default -> {
          return null;
        }
      }
    }

    CharClass cc = builder.build();
    if (cc.isEmpty()) {
      return null;
    }
    if (cc.numRunes() > 0x80000) {
      return null;
    }
    return CharClassScanInfo.fromCharClass(cc);
  }

  static FixedOffsetLiteral extractFixedOffsetLiteral(Regexp re) {
    return extractFixedOffsetLiteral(re, null);
  }

  private static FixedOffsetLiteral extractFixedOffsetLiteral(
      Regexp re, List<NodeAnalysis> children) {
    Regexp node = unwrapCaptures(re);
    if (node == null || node.op != RegexpOp.CONCAT || node.subs == null) {
      return null;
    }
    FixedOffsetLiteral best = null;
    int bestScore = 0;
    AsciiWidthRange prefixWidth = AsciiWidthRange.ZERO;

    for (int index = 0; index < node.subs.size(); ) {
      String literalPart = extractExactAsciiLiteral(node.subs.get(index));
      if (literalPart != null) {
        StringBuilder literal = new StringBuilder(literalPart);
        int next = index + 1;
        while (next < node.subs.size()) {
          String nextPart = extractExactAsciiLiteral(node.subs.get(next));
          if (nextPart == null) {
            break;
          }
          literal.append(nextPart);
          next++;
        }
        if (index > 0 && (prefixWidth.minWidth > 0 || prefixWidth.maxWidth > 0)) {
          int minimumLiteralLength = prefixWidth.discreteWidths != null ? 1 : 2;
          if (literal.length() >= minimumLiteralLength) {
            int candidateScore = RarityOracle.literalSelectivityScore(literal);
            if (best == null || candidateScore > bestScore) {
              best =
                  new FixedOffsetLiteral(
                      literal.toString(),
                      prefixWidth.minWidth,
                      prefixWidth.maxWidth,
                      prefixWidth.discreteWidths);
              bestScore = candidateScore;
            }
          }
        }
        prefixWidth = concatenateWidths(prefixWidth, AsciiWidthRange.exact(literal.length()));
        if (!prefixWidth.isValid()) {
          break;
        }
        index = next;
        continue;
      }

      AsciiWidthRange childWidth =
          children != null
              ? children.get(index).width()
              : computeAsciiWidthRange(node.subs.get(index));
      prefixWidth = concatenateWidths(prefixWidth, childWidth);
      if (!prefixWidth.isValid()) {
        break;
      }
      index++;
    }
    return best;
  }

  static AsciiWidthRange computeAsciiWidthRange(Regexp re) {
    return new AsciiWidthRangeWalker().walk(re, AsciiWidthRange.INVALID);
  }

  private static final class AsciiWidthRangeWalker extends Walker<AsciiWidthRange> {
    @Override
    protected AsciiWidthRange postVisit(
        Regexp node,
        AsciiWidthRange parentArg,
        AsciiWidthRange preArg,
        List<AsciiWidthRange> childArgs) {
      return switch (node.op) {
        case CAPTURE, NON_CAPTURE ->
            childArgs.isEmpty() ? AsciiWidthRange.INVALID : childArgs.getFirst();
        case EMPTY_MATCH,
            BEGIN_LINE,
            END_LINE,
            BEGIN_TEXT,
            END_TEXT,
            WORD_BOUNDARY,
            NO_WORD_BOUNDARY ->
            AsciiWidthRange.ZERO;
        case LITERAL ->
            node.rune >= 0 && node.rune < 128 && (node.flags & ParseFlags.FOLD_CASE) == 0
                ? AsciiWidthRange.ONE
                : AsciiWidthRange.INVALID;
        case LITERAL_STRING -> literalStringWidth(node);
        case CHAR_CLASS -> characterClassWidth(node);
        case REPEAT ->
            childArgs.isEmpty() ? AsciiWidthRange.INVALID : repeatWidth(node, childArgs.getFirst());
        case QUEST ->
            childArgs.isEmpty() ? AsciiWidthRange.INVALID : optionalWidth(childArgs.getFirst());
        case ALTERNATE -> alternateWidth(childArgs);
        case CONCAT -> concatenateWidths(childArgs);
        default -> AsciiWidthRange.INVALID;
      };
    }

    @Override
    protected AsciiWidthRange shortVisit(Regexp re, AsciiWidthRange parentArg) {
      return AsciiWidthRange.INVALID;
    }

    private static AsciiWidthRange literalStringWidth(Regexp node) {
      if ((node.flags & ParseFlags.FOLD_CASE) != 0 || node.runes == null) {
        return AsciiWidthRange.INVALID;
      }
      for (int rune : node.runes) {
        if (rune < 0 || rune >= 128) {
          return AsciiWidthRange.INVALID;
        }
      }
      return AsciiWidthRange.exact(node.runes.length);
    }

    private static AsciiWidthRange characterClassWidth(Regexp node) {
      if (node.charClass == null || node.charClass.isEmpty()) {
        return AsciiWidthRange.INVALID;
      }
      return node.charClass.hi(node.charClass.numRanges() - 1) < 128
          ? AsciiWidthRange.ONE
          : AsciiWidthRange.NON_DISCRETE_ONE;
    }

    private static AsciiWidthRange repeatWidth(Regexp node, AsciiWidthRange child) {
      if (node.min < 0 || node.max < 0) {
        return AsciiWidthRange.INVALID;
      }
      if (!child.isValid()) {
        return AsciiWidthRange.INVALID;
      }
      int minWidth = multiplyWidth(child.minWidth, node.min);
      int maxWidth = multiplyWidth(child.maxWidth, node.max);
      if (minWidth < 0 || maxWidth < 0) {
        return AsciiWidthRange.INVALID;
      }
      if (child.discreteWidths != null && child.isExact() && node.max - node.min <= 8) {
        if (child.minWidth == 0) {
          return AsciiWidthRange.ZERO;
        }
        int[] discrete = new int[node.max - node.min + 1];
        for (int index = 0; index < discrete.length; index++) {
          int width = multiplyWidth(child.minWidth, node.min + index);
          if (width < 0) {
            return AsciiWidthRange.INVALID;
          }
          discrete[index] = width;
        }
        return new AsciiWidthRange(minWidth, maxWidth, discrete);
      }
      return new AsciiWidthRange(minWidth, maxWidth, null);
    }

    private static AsciiWidthRange optionalWidth(AsciiWidthRange child) {
      if (!child.isValid()) {
        return AsciiWidthRange.INVALID;
      }
      if (child.discreteWidths == null) {
        return new AsciiWidthRange(0, child.maxWidth, null);
      }
      int[] discrete = new int[child.discreteWidths.length + 1];
      int size = 1;
      for (int width : child.discreteWidths) {
        size = insertWidth(discrete, size, width);
      }
      return new AsciiWidthRange(
          0, child.maxWidth, size <= 16 ? Arrays.copyOf(discrete, size) : null);
    }

    private static AsciiWidthRange alternateWidth(List<AsciiWidthRange> childArgs) {
      if (childArgs.isEmpty()) {
        return AsciiWidthRange.INVALID;
      }
      int minWidth = Integer.MAX_VALUE;
      int maxWidth = Integer.MIN_VALUE;
      int[] discrete = new int[8];
      int size = 0;
      boolean allDiscrete = true;
      for (AsciiWidthRange child : childArgs) {
        if (!child.isValid()) {
          return AsciiWidthRange.INVALID;
        }
        minWidth = Math.min(minWidth, child.minWidth);
        maxWidth = Math.max(maxWidth, child.maxWidth);
        if (allDiscrete && child.discreteWidths != null) {
          for (int width : child.discreteWidths) {
            size = insertWidth(discrete, size, width);
            if (size > discrete.length) {
              allDiscrete = false;
              break;
            }
          }
        } else {
          allDiscrete = false;
        }
      }
      return new AsciiWidthRange(
          minWidth, maxWidth, allDiscrete ? Arrays.copyOf(discrete, size) : null);
    }
  }

  private static AsciiWidthRange concatenateWidths(List<AsciiWidthRange> widths) {
    AsciiWidthRange result = AsciiWidthRange.ZERO;
    for (AsciiWidthRange width : widths) {
      result = concatenateWidths(result, width);
      if (!result.isValid()) {
        return result;
      }
    }
    return result;
  }

  private static AsciiWidthRange concatenateWidths(AsciiWidthRange left, AsciiWidthRange right) {
    if (!left.isValid() || !right.isValid()) {
      return AsciiWidthRange.INVALID;
    }
    if (left == AsciiWidthRange.ZERO) {
      return right;
    }
    if (right == AsciiWidthRange.ZERO) {
      return left;
    }
    int minWidth = addWidth(left.minWidth, right.minWidth);
    int maxWidth = addWidth(left.maxWidth, right.maxWidth);
    if (minWidth < 0 || maxWidth < 0) {
      return AsciiWidthRange.INVALID;
    }
    int[] discrete = null;
    if (left.discreteWidths != null
        && right.discreteWidths != null
        && left.discreteWidths.length * right.discreteWidths.length <= 16) {
      int[] combined = new int[left.discreteWidths.length * right.discreteWidths.length];
      int size = 0;
      for (int leftWidth : left.discreteWidths) {
        for (int rightWidth : right.discreteWidths) {
          int width = addWidth(leftWidth, rightWidth);
          if (width < 0) {
            return AsciiWidthRange.INVALID;
          }
          size = insertWidth(combined, size, width);
        }
      }
      discrete = size == combined.length ? combined : Arrays.copyOf(combined, size);
    }
    return new AsciiWidthRange(minWidth, maxWidth, discrete);
  }

  // Width sets have at most sixteen entries. Keep them sorted without boxing or tree nodes;
  // a return value beyond capacity means the caller must discard the discrete approximation.
  private static int insertWidth(int[] widths, int size, int width) {
    int index = Arrays.binarySearch(widths, 0, size, width);
    if (index >= 0) {
      return size;
    }
    if (size == widths.length) {
      return size + 1;
    }
    index = -index - 1;
    System.arraycopy(widths, index, widths, index + 1, size - index);
    widths[index] = width;
    return size + 1;
  }

  private static int addWidth(int left, int right) {
    return left > Integer.MAX_VALUE - right ? -1 : left + right;
  }

  private static int multiplyWidth(int width, int count) {
    return width != 0 && count > Integer.MAX_VALUE / width ? -1 : width * count;
  }

  private static boolean isLeadingZeroWidth(Regexp re) {
    return switch (re.op) {
      case EMPTY_MATCH, WORD_BOUNDARY, NO_WORD_BOUNDARY, BEGIN_LINE, BEGIN_TEXT -> true;
      default -> false;
    };
  }

  private static String[] extractLiteralAlternation(Regexp re) {
    if (re == null) {
      return null;
    }
    re = unwrapCaptures(re);
    if (re == null || re.op != RegexpOp.ALTERNATE || re.nsub() < 2) {
      return null;
    }
    String[] literals = new String[re.nsub()];
    for (int i = 0; i < re.nsub(); i++) {
      String lit = extractExactAsciiLiteral(re.subs.get(i));
      if (lit == null || lit.isEmpty()) {
        return null;
      }
      literals[i] = lit;
    }
    return literals;
  }

  private static Pattern.StartAcceleration extractStartAcceleration(Regexp re) {
    Regexp node = unwrapCaptures(re);
    if (node == null) {
      return null;
    }

    if (node.op == RegexpOp.CONCAT && node.nsub() > 0) {
      Regexp first = unwrapCaptures(node.subs.get(0));
      if (first != null && first.op == RegexpOp.BEGIN_LINE) {
        AsciiBitmap requiredStart = null;
        if (node.nsub() > 1) {
          requiredStart = requiredFirstAscii(node.subs.get(1));
        }
        return new Pattern.StartAcceleration(true, false, requiredStart);
      }
      return null;
    }

    if (node.op == RegexpOp.BEGIN_LINE) {
      return new Pattern.StartAcceleration(true, false, null);
    }
    return null;
  }

  private static AsciiBitmap requiredFirstAscii(Regexp re) {
    Regexp node = unwrapCaptures(re);
    if (node == null) {
      return null;
    }
    if (node.op == RegexpOp.CONCAT && node.nsub() > 0) {
      node = unwrapCaptures(node.subs.get(0));
    }
    if (node == null) {
      return null;
    }
    if (node.op == RegexpOp.PLUS || (node.op == RegexpOp.REPEAT && node.min >= 1)) {
      node = unwrapCaptures(node.sub());
    }
    if (node == null) {
      return null;
    }

    if (node.op == RegexpOp.LITERAL) {
      if ((node.flags & ParseFlags.FOLD_CASE) != 0 || node.rune >= 128) {
        return null;
      }
      return AsciiBitmap.of(node.rune);
    }
    if (node.op == RegexpOp.LITERAL_STRING && node.runes != null && node.runes.length > 0) {
      if ((node.flags & ParseFlags.FOLD_CASE) != 0 || node.runes[0] >= 128) {
        return null;
      }
      return AsciiBitmap.of(node.runes[0]);
    }
    if (node.op == RegexpOp.CHAR_CLASS && node.charClass != null) {
      CharClass cc = node.charClass;
      if (cc.isEmpty()) {
        return null;
      }
      for (int i = 0; i < cc.numRanges(); i++) {
        if (cc.hi(i) >= 128) {
          return null;
        }
      }
      AsciiBitmap.Builder builder = new AsciiBitmap.Builder();
      for (int i = 0; i < cc.numRanges(); i++) {
        builder.addRange(cc.lo(i), cc.hi(i));
      }
      return builder.build();
    }
    return null;
  }

  private static boolean addAsciiCharClass(CharClass cc, AsciiBitmap.Builder builder) {
    if (cc == null || cc.isEmpty()) {
      return false;
    }
    for (int i = 0; i < cc.numRanges(); i++) {
      if (cc.hi(i) >= 128) {
        return false;
      }
    }
    for (int i = 0; i < cc.numRanges(); i++) {
      builder.addRange(cc.lo(i), cc.hi(i));
    }
    return true;
  }

  private static Pattern.SuffixInfo extractEndAnchoredSuffix(Regexp metadataAst, int flags) {
    Regexp node = unwrapCaptures(metadataAst);
    if (node == null || node.op != RegexpOp.CONCAT || node.nsub() < 2) {
      return null;
    }
    List<Regexp> subs = node.subs;
    Regexp last = unwrapCaptures(subs.get(subs.size() - 1));
    if (last == null || last.op != RegexpOp.END_TEXT) {
      return null;
    }
    if ((flags & Pattern.MULTILINE) != 0 && (last.flags & ParseFlags.WAS_DOLLAR) != 0) {
      return null;
    }
    boolean wasDollar = (last.flags & ParseFlags.WAS_DOLLAR) != 0;
    boolean foldCase = false;

    Deque<String> suffixParts = new ArrayDeque<>();
    int suffixLength = 0;
    for (int i = subs.size() - 2; i >= 0; i--) {
      Regexp sub = unwrapCaptures(subs.get(i));
      if (sub == null) {
        break;
      }
      boolean subFold = (sub.flags & ParseFlags.FOLD_CASE) != 0;
      if (sub.op == RegexpOp.LITERAL) {
        if (!Utils.isValidRune(sub.rune) || (subFold && sub.rune > 0x7F)) {
          break;
        }
        String part = Character.toString(sub.rune);
        suffixParts.addFirst(part);
        suffixLength += part.length();
        foldCase |= subFold;
      } else if (sub.op == RegexpOp.LITERAL_STRING && areAllValidRunes(sub.runes)) {
        if (subFold && !isAllAscii(sub.runes)) {
          break;
        }
        String part = new String(sub.runes, 0, sub.runes.length);
        suffixParts.addFirst(part);
        suffixLength += part.length();
        foldCase |= subFold;
      } else {
        break;
      }
    }
    if (suffixParts.isEmpty()) {
      return null;
    }
    StringBuilder suffix = new StringBuilder(suffixLength);
    suffixParts.forEach(suffix::append);
    return new Pattern.SuffixInfo(
        suffix.toString(), wasDollar, (last.flags & ParseFlags.UNIX_LINES) != 0, foldCase);
  }

  private static boolean areAllValidRunes(int[] runes) {
    if (runes == null) {
      return false;
    }
    for (int r : runes) {
      if (!Utils.isValidRune(r)) {
        return false;
      }
    }
    return true;
  }

  private static boolean canRepresentAsCodePointString(int[] runes) {
    if (runes == null) {
      return false;
    }
    for (int i = 0; i < runes.length; i++) {
      int r = runes[i];
      if (r < Utils.MIN_RUNE || r > Utils.MAX_RUNE) {
        return false;
      }
      if (r >= Character.MIN_HIGH_SURROGATE
          && r <= Character.MAX_HIGH_SURROGATE
          && i + 1 < runes.length
          && runes[i + 1] >= Character.MIN_LOW_SURROGATE
          && runes[i + 1] <= Character.MAX_LOW_SURROGATE) {
        return false;
      }
    }
    return true;
  }

  private static boolean isAllAscii(int[] runes) {
    for (int r : runes) {
      if (r > 0x7F) {
        return false;
      }
    }
    return true;
  }

  private static Pattern.EndAnchoredCharClassInfo extractEndAnchoredCharClass(
      Regexp metadataAst, int flags) {
    Regexp node = unwrapCaptures(metadataAst);
    if (node == null || node.op != RegexpOp.CONCAT || node.nsub() < 2) {
      return null;
    }
    List<Regexp> subs = node.subs;
    Regexp last = unwrapCaptures(subs.get(subs.size() - 1));
    if (last == null || last.op != RegexpOp.END_TEXT) {
      return null;
    }
    if ((flags & Pattern.MULTILINE) != 0 && (last.flags & ParseFlags.WAS_DOLLAR) != 0) {
      return null;
    }
    boolean wasDollar = (last.flags & ParseFlags.WAS_DOLLAR) != 0;

    Regexp sub = unwrapCaptures(subs.get(subs.size() - 2));
    if (sub == null) {
      return null;
    }
    while (sub.op == RegexpOp.PLUS || (sub.op == RegexpOp.REPEAT && sub.min >= 1)) {
      sub = unwrapCaptures(sub.sub());
      if (sub == null) {
        return null;
      }
    }
    AsciiBitmap.Builder builder = new AsciiBitmap.Builder();
    if (sub.op == RegexpOp.CHAR_CLASS && addAsciiCharClass(sub.charClass, builder)) {
      boolean unixLines = (last.flags & ParseFlags.UNIX_LINES) != 0;
      return new Pattern.EndAnchoredCharClassInfo(builder.build(), wasDollar, unixLines);
    }
    return null;
  }

  private static Set<String> extractFixedPrefixLiterals(Regexp re, List<NodeAnalysis> children) {
    Regexp node = unwrapCaptures(re);
    if (node == null || node.op != RegexpOp.CONCAT || node.subs == null) {
      return Set.of();
    }
    Set<String> literals = new LinkedHashSet<>();
    AsciiWidthRange prefixWidth = AsciiWidthRange.ZERO;
    for (int index = 0; index < node.subs.size(); index++) {
      Regexp sub = node.subs.get(index);
      prefixWidth = concatenateWidths(prefixWidth, children.get(index).width());
      if (!prefixWidth.isValid()) {
        break;
      }
      collectAsciiLiterals(sub, literals);
    }
    return literals;
  }

  private static void collectAsciiLiterals(Regexp re, Set<String> literals) {
    String exact = extractExactAsciiLiteral(re);
    if (exact != null && exact.length() >= 2) {
      literals.add(exact);
    }

    Deque<Regexp> pending = new ArrayDeque<>();
    pending.addLast(re);
    while (!pending.isEmpty()) {
      Regexp node = unwrapCaptures(pending.removeLast());
      if (node == null) {
        continue;
      }
      if ((node.op == RegexpOp.LITERAL_STRING || node.op == RegexpOp.LITERAL)
          && (node.flags & ParseFlags.FOLD_CASE) == 0
          && areAllValidRunes(node.runes)
          && node.runes.length >= 2) {
        literals.add(new String(node.runes, 0, node.runes.length));
      }
      if (node.subs != null) {
        for (Regexp child : node.subs) {
          pending.addLast(child);
        }
      }
    }
  }

  private static String extractRequiredLiteral(
      Regexp re, Set<String> excludePrefixes, String excludeSuffix) {
    String best = null;
    int bestScore = 0;
    Deque<Regexp> pending = new ArrayDeque<>();
    pending.addLast(re);
    while (!pending.isEmpty()) {
      Regexp node = pending.removeLast();
      switch (node.op) {
        case CAPTURE, NON_CAPTURE, PLUS -> pending.addLast(node.sub());
        case REPEAT -> {
          if (node.min > 0) {
            pending.addLast(node.sub());
          }
        }
        case CONCAT -> {
          if (node.subs != null) {
            String exactAscii = extractExactAsciiLiteral(node);
            if (exactAscii != null && exactAscii.length() >= 2) {
              if (!isLiteralSubsumed(exactAscii, excludePrefixes, excludeSuffix)) {
                int score = RarityOracle.literalSelectivityScore(exactAscii);
                if (best == null || score > bestScore) {
                  best = exactAscii;
                  bestScore = score;
                }
              }
            }
            for (Regexp sub : node.subs) {
              pending.addLast(sub);
            }
          }
        }
        case LITERAL_STRING -> {
          if ((node.flags & ParseFlags.FOLD_CASE) == 0
              && areAllValidRunes(node.runes)
              && node.runes.length >= 2) {
            String candidate = new String(node.runes, 0, node.runes.length);
            if (!isLiteralSubsumed(candidate, excludePrefixes, excludeSuffix)) {
              int candidateScore = RarityOracle.literalSelectivityScore(candidate);
              if (best == null || candidateScore > bestScore) {
                best = candidate;
                bestScore = candidateScore;
              }
            }
          }
        }
        default -> {}
      }
    }
    return best;
  }

  private static boolean isLiteralSubsumed(
      String candidate, Set<String> excludedPrefixes, String excludedSuffix) {
    if (candidate == null) {
      return false;
    }
    if (excludedSuffix != null
        && (candidate.equals(excludedSuffix) || excludedSuffix.contains(candidate))) {
      return true;
    }
    if (excludedPrefixes != null) {
      for (String excluded : excludedPrefixes) {
        if (candidate.equals(excluded) || excluded.contains(candidate)) {
          return true;
        }
      }
    }
    return false;
  }

  private static String[] combineDisjointRequiredLiterals(List<NodeAnalysis> children) {
    if (children == null || children.size() < 2) {
      return null;
    }
    Set<String> literalSet = new LinkedHashSet<>();
    for (NodeAnalysis branch : children) {
      String req = branch.reject().bestRequiredLiteral();
      if (req == null || req.length() < 2) {
        return null;
      }
      literalSet.add(req);
      if (literalSet.size() > 4) {
        return null;
      }
    }
    List<String> rawList = new ArrayList<>(literalSet);
    List<int[]> rawCodePoints = new ArrayList<>(rawList.size());
    List<int[]> rawFailures = new ArrayList<>(rawList.size());
    for (String literal : rawList) {
      int[] codePoints = literal.codePoints().toArray();
      rawCodePoints.add(codePoints);
      rawFailures.add(literalFailure(codePoints));
    }
    Set<String> pruned = new LinkedHashSet<>();
    for (int i = 0; i < rawList.size(); i++) {
      String s1 = rawList.get(i);
      boolean subsumed = false;
      for (int j = 0; j < rawList.size(); j++) {
        if (i != j) {
          String s2 = rawList.get(j);
          if (containsCodePointSequence(
                  rawCodePoints.get(i), rawCodePoints.get(j), rawFailures.get(j))
              && (s1.length() > s2.length() || (s1.length() == s2.length() && j < i))) {
            subsumed = true;
            break;
          }
        }
      }
      if (!subsumed) {
        pruned.add(s1);
      }
    }
    if (pruned.size() < 2) {
      return null;
    }
    return pruned.toArray(new String[0]);
  }

  private static int[] literalFailure(int[] literal) {
    int[] failure = new int[literal.length];
    int matched = 0;
    for (int index = 1; index < literal.length; index++) {
      while (matched > 0 && literal[index] != literal[matched]) {
        matched = failure[matched - 1];
      }
      if (literal[index] == literal[matched]) {
        matched++;
      }
      failure[index] = matched;
    }
    return failure;
  }

  private static boolean containsCodePointSequence(int[] value, int[] candidate, int[] failure) {
    int matched = 0;
    for (int codePoint : value) {
      while (matched > 0 && codePoint != candidate[matched]) {
        matched = failure[matched - 1];
      }
      if (codePoint == candidate[matched]) {
        matched++;
        if (matched == candidate.length) {
          return true;
        }
      }
    }
    return false;
  }

  private static CharClass literalCharClass(int cp, int flags) {
    CharClassBuilder ccb = new CharClassBuilder();
    if ((flags & ParseFlags.FOLD_CASE) == 0) {
      ccb.addRange(cp, cp);
    } else if ((flags & ParseFlags.UNICODE_CASE) == 0) {
      UnicodeCaseFolding.addAsciiFoldedRange(ccb, cp, cp);
    } else {
      UnicodeCaseFolding.addUnicodeFoldedRange(ccb, cp, cp);
    }
    return ccb.build();
  }

  private static Regexp unwrapCaptures(Regexp re) {
    Regexp node = re;
    while (node != null && (node.op == RegexpOp.CAPTURE || node.op == RegexpOp.NON_CAPTURE)) {
      node = node.sub();
    }
    return node;
  }
}
