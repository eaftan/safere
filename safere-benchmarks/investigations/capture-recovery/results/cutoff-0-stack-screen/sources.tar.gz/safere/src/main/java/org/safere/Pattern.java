// This file is part of a Java port of RE2 (https://github.com/google/re2).
// Original RE2 code is Copyright (c) 2009 The RE2 Authors.
// Portions derived from RE2/J (https://github.com/google/re2j),
// Copyright (c) 2009 The Go Authors.
// Modifications and Java port Copyright (c) 2026 Eddie Aftandilian.
// Licensed under the BSD 3-Clause License (see LICENSE file).

package org.safere;

import java.io.Serializable;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.ref.SoftReference;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;
import java.util.EnumSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Spliterator;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Predicate;
import java.util.regex.PatternSyntaxException;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * A compiled regular expression backed by a linear-time NFA engine. This class provides a drop-in
 * replacement for {@link java.util.regex.Pattern}.
 *
 * <p>Unlike {@code java.util.regex.Pattern}, this implementation guarantees linear-time matching
 * regardless of the pattern or input. Features that require exponential time (backreferences,
 * lookahead, lookbehind) are not supported and will be rejected at compile time.
 *
 * <p>Usage:
 *
 * <pre>
 *   Pattern p = Pattern.compile("(\\w+)@(\\w+)");
 *   Matcher m = p.matcher("user@host");
 *   if (m.matches()) {
 *     String user = m.group(1);
 *   }
 * </pre>
 */
public final class Pattern implements Serializable {

  private static final long serialVersionUID = 1L;
  private static final int END_ANCHORED_SEARCH_FALLBACK = -2;
  static final int END_ANCHORED_SEARCH_DEFERRED = -3;
  private static final int MIN_END_ANCHORED_PROBE_UNITS = 64;
  // Short inputs retain the forward path to avoid reverse-search setup overhead.
  private static final int MIN_REVERSE_FIRST_LEN = 1024;
  // A competitive literal start accelerator runs before the find reject prefilter only on inputs
  // shorter than this, where the separate prefilter call dominates. Longer inputs keep the
  // single-pass reject prefilter first.
  static final int MAX_LITERAL_START_FIRST_LENGTH = 512;
  // After a short-input start scan, the reject prefilter re-runs from the start candidate only when
  // at least this many units remain. On a shorter tail the DFA's check costs less than the call.
  static final int MIN_REJECT_AFTER_START_REMAINING = 64;
  private static final AtomicLong NEXT_PATTERN_ID = new AtomicLong(1);
  private static final MethodType DIAGNOSTICS_TYPE =
      MethodType.methodType(SafeReMatchDiagnostics.class);
  private static final MutableCallSite DIAGNOSTICS_SITE = new MutableCallSite(DIAGNOSTICS_TYPE);
  private static final MethodHandle DIAGNOSTICS_INVOKER = DIAGNOSTICS_SITE.dynamicInvoker();

  static {
    setDiagnosticsTarget(SafeReMatchDiagnostics.NONE);
  }

  /**
   * Enables Unix lines mode. In this mode, only {@code '\n'} is recognized as a line terminator.
   */
  public static final int UNIX_LINES = java.util.regex.Pattern.UNIX_LINES; // 1

  /**
   * Enables case-insensitive matching. By default, case-insensitive matching assumes only US-ASCII
   * characters. Unicode-aware case folding can be enabled with {@link #UNICODE_CASE}.
   */
  public static final int CASE_INSENSITIVE = java.util.regex.Pattern.CASE_INSENSITIVE; // 2

  /**
   * Permits whitespace and comments in the pattern. Whitespace is ignored, and comments starting
   * with {@code #} run to end-of-line.
   */
  public static final int COMMENTS = java.util.regex.Pattern.COMMENTS; // 4

  /**
   * Enables multiline mode. In multiline mode, {@code ^} and {@code $} match at the start and end
   * of each line, not just the start and end of the entire input.
   */
  public static final int MULTILINE = java.util.regex.Pattern.MULTILINE; // 8

  /**
   * Enables literal parsing of the pattern. Metacharacters and escape sequences have no special
   * meaning.
   */
  public static final int LITERAL = java.util.regex.Pattern.LITERAL; // 16

  /**
   * Enables dotall mode. In dotall mode, {@code .} matches any character including line
   * terminators.
   */
  public static final int DOTALL = java.util.regex.Pattern.DOTALL; // 32

  /**
   * Enables Unicode-aware case folding. When used with {@link #CASE_INSENSITIVE}, matching is done
   * in a manner consistent with the Unicode Standard.
   */
  public static final int UNICODE_CASE = java.util.regex.Pattern.UNICODE_CASE; // 64

  /**
   * Enables Unicode-aware character classes. When enabled, predefined character classes such as
   * {@code \w}, {@code \d}, and {@code \s} match Unicode characters instead of only ASCII.
   */
  public static final int UNICODE_CHARACTER_CLASS =
      java.util.regex.Pattern.UNICODE_CHARACTER_CLASS; // 256

  private final String pattern;
  private final int flags;
  private final transient Prog prog;

  /**
   * Flattened copies of {@link #prog} for the DFA. Built in the constructor unless the default
   * {@code find()} runner never uses the forward DFA; then built on first use. Patterns with loop
   * registers always build them eagerly, since that requires a separate compilation.
   */
  private transient volatile Prog flatProg;

  private transient volatile Prog flatDfaProg;

  /** Whether the forward DFA supports {@link #flatDfaProg()}, known without building it. */
  private final transient boolean forwardDfaSupported;

  private final transient Regexp ast;
  private final transient AstAnalysis astAnalysis;
  private final transient String prefix;
  private final transient boolean prefixFoldCase;
  private final transient MatchDescriptor matchDescriptor;
  private final transient byte[] literalMatchUtf8;
  private final transient int[] literalMatchFailure;
  private final transient int[] literalMatchShifts;
  private final transient int literalMatchRareByteOffset;
  private final transient byte[] prefixUtf8;
  private final transient String anchoredPrefix;
  private final transient byte[] anchoredPrefixUtf8;
  private final transient boolean startsWithGraphemeClusterBoundary;
  private final transient boolean hasInternalGraphemeClusterBoundary;
  private final transient CharClassScanInfo charClassPrefix;
  private final transient CharClassScanInfo anchoredCharClassPrefix;
  private final transient Utf8StartAccelerator utf8StartAccelerator;
  private final transient StringStartAccelerator stringStartAccelerator;
  private final transient EnginePathOptions enginePathOptions;
  private final transient LiteralAlternation literalAlternation;
  private final transient InnerLiteralSearch innerLiteralSearch;
  // Not final: a lazy ShiftDfa runner replaces itself once its analysis resolves. Volatile because
  // that replacement happens on whichever thread first calls matches(). Every runner has only final
  // fields, so a racy read was already safe, but volatile makes the publication explicit.
  private transient volatile Matcher.PreparedMatchRunner defaultPreparedMatchRunner;
  private final transient Matcher.PreparedMatchRunner regionPreparedMatchRunner;
  private final long patternId;
  private transient volatile PatternAnalysis patternAnalysis;
  private transient volatile PatternDescriptor patternDescriptor;
  private final transient MultiAnchorDescriptor multiAnchor;

  /**
   * Whole-input rejection filter for Tier 0 acceleration. Non-null when matching can quickly reject
   * by verifying that mandatory literal content or character classes appear anywhere in the input
   * before running automata.
   */
  private final transient RejectPrefilter rejectPrefilter;

  private final transient RejectPrefilter utf8FindRejectPrefilter;

  private final boolean startPrecedesFindReject;
  private final boolean dfaStartAcceleration;
  private final boolean startSubsumesFindReject;

  /**
   * OnePass analysis results, computed during construction when eligible analysis can support
   * {@code find()} or capture extraction, otherwise on first request. Holds the OnePass automaton
   * and derived flags ({@code canOnePassFind}, {@code canOnePassSubmatch}).
   */
  private transient volatile OnePassAnalysis onePassAnalysis;

  /**
   * Whether a matcher has consumed inner captures, including already resolved captures and
   * successful snapshots. Shared for this Pattern's lifetime across matchers, inputs and threads;
   * independent of any matcher's current result. Exact fallback searches can reuse this hint to
   * collect captures in a required pass; small-input heuristics may also avoid a redundant DFA
   * pass. Internal resolution and group-zero-only access must not set it.
   */
  private transient volatile boolean innerCapturesObserved;

  /**
   * DFA equivalence-class setup for the forward program, shared across all Matcher instances. Built
   * during construction unless the default {@code find()} runner is a literal runner; then built on
   * first request.
   */
  private transient volatile Dfa.Setup forwardDfaSetup;

  /**
   * Reverse-compiled program for backward DFA matching. Computed on first use: only unanchored
   * {@code find()} operations whose forward DFA search finds a match, and end-anchored searches
   * over long inputs, need it.
   */
  private transient volatile Prog reverseProg;

  private transient volatile Prog flatReverseProg;
  private transient volatile Prog flatReverseDfaProg;

  /** DFA setup built once alongside the final {@link #flatReverseDfaProg}. */
  private transient volatile Dfa.Setup reverseDfaSetup;

  /**
   * Per-thread cached execution state. Shared across all Matchers created from this Pattern within
   * the same thread, so warm DFA state caches and BitState/Nfa scratch buffers persist across the
   * common {@code pattern.matcher(t).find()} idiom.
   *
   * <p>The cache is held via a {@link SoftReference} (a bootstrap-loaded JDK class) so that when
   * SafeRE is loaded in a child {@link ClassLoader} and patterns are held in {@code static final}
   * fields, the {@link ThreadLocal} entry value in long-lived threads does not strongly reference
   * SafeRE classes and pin the child {@code ClassLoader}.
   */
  static final class ThreadCache {
    // Use the ID rather than retaining the Thread and its other thread-local values.
    final long ownerThreadId = Thread.currentThread().threadId();
    BitState bitState;
    Nfa nfa;
    Dfa forwardFirstMatchDfa;
    Dfa forwardLongestMatchDfa;
    Dfa reverseDfa;
  }

  // Per-Pattern ThreadLocal is intentional: each Pattern caches its own DFA/BitState/Nfa state per
  // thread, so warm state caches persist across the common pattern.matcher(t).find() idiom.
  @SuppressWarnings("ThreadLocalUsage")
  private final transient ThreadLocal<SoftReference<ThreadCache>> threadCache = new ThreadLocal<>();

  /** Holder for OnePass analysis results. */
  private record OnePassAnalysis(
      OnePass onePass, boolean canPrimary, boolean canFind, boolean canSubmatch) {
    static final OnePassAnalysis DISABLED = new OnePassAnalysis(null, false, false, false);
  }

  /**
   * ShiftDfa analysis result, computed on first {@code matches()} request for eligible group-0
   * patterns.
   */
  private transient volatile ShiftDfaAnalysis shiftDfaAnalysis;

  /** Holder for ShiftDfa analysis results. */
  private record ShiftDfaAnalysis(ShiftDfa shiftDfa) {
    static final ShiftDfaAnalysis DISABLED = new ShiftDfaAnalysis(null);
  }

  private Pattern(
      String pattern,
      int flags,
      Prog prog,
      Compiler.Prepared prepared,
      Regexp ast,
      AstAnalysis astAnalysis,
      MatchDescriptor matchDescriptor,
      boolean startsWithGraphemeClusterBoundary,
      boolean hasInternalGraphemeClusterBoundary,
      MultiAnchorDescriptor multiAnchor,
      EnginePathOptions enginePathOptions) {
    this.patternId = nextPatternId();
    this.pattern = pattern;
    this.flags = flags;
    this.prog = prog;
    if (enginePathOptions.dfa() && prog.numLoopRegs() > 0) {
      this.flatProg = prog.flattenedCopy();
      Prog dfaProg = Compiler.compileForDfa(prepared, false);
      this.flatDfaProg = dfaProg != null ? dfaProg.flattenedCopy() : this.flatProg;
    }

    this.ast = ast;
    this.astAnalysis = astAnalysis;
    this.multiAnchor = multiAnchor != null ? multiAnchor : MultiAnchorDescriptor.NONE;
    this.prefix = this.multiAnchor.prefix();
    this.prefixFoldCase = this.multiAnchor.prefixFoldCase();
    this.prefixUtf8 =
        this.prefix == null || this.prefix.isEmpty()
            ? null
            : this.prefix.getBytes(StandardCharsets.UTF_8);
    this.anchoredPrefix = this.multiAnchor.anchoredPrefix();
    this.anchoredPrefixUtf8 =
        this.anchoredPrefix == null || this.anchoredPrefix.isEmpty()
            ? null
            : this.anchoredPrefix.getBytes(StandardCharsets.UTF_8);
    this.matchDescriptor = matchDescriptor != null ? matchDescriptor : MatchDescriptor.NONE;
    // Fold the option into prepared literal data so the search methods need no extra guard.
    // An extra guard there can perturb C2 compilation of their inlined byte-scanning loops.
    String literalMatch =
        enginePathOptions.literalFastPaths() ? this.matchDescriptor.literalMatch() : null;
    this.literalMatchUtf8 =
        literalMatch == null ? null : literalMatch.getBytes(StandardCharsets.UTF_8);
    this.literalMatchFailure = literalMatchUtf8 == null ? null : literalFailure(literalMatchUtf8);
    this.literalMatchShifts = literalMatchUtf8 == null ? null : literalShifts(literalMatchUtf8);
    this.literalMatchRareByteOffset =
        literalMatchUtf8 == null || this.matchDescriptor.literalFoldCase()
            ? -1
            : RarityOracle.rarestUtf8LiteralByteOffset(literalMatchUtf8);
    this.startsWithGraphemeClusterBoundary = startsWithGraphemeClusterBoundary;
    this.hasInternalGraphemeClusterBoundary = hasInternalGraphemeClusterBoundary;
    this.charClassPrefix = this.multiAnchor.charClassPrefix();
    this.anchoredCharClassPrefix = this.multiAnchor.anchoredCharClassPrefix();
    this.utf8StartAccelerator =
        Utf8StartAccelerator.create(this.multiAnchor, prog.hasWordBoundary());
    boolean wideLeadingExpansion =
        this.multiAnchor.startPlan() instanceof MultiAnchorDescriptor.StartPlan.LeadingExpansion le
            && MultiAnchorCompiler.isWideLeadingClass(le.leadingClass());
    // A String program containing \X may start at the low half of a surrogate pair. A scalar
    // backward walk can see the excluded pair and miss a valid start at its low surrogate.
    this.stringStartAccelerator =
        wideLeadingExpansion && prog.hasGraphemeClusterInstruction()
            ? null
            : StringStartAccelerator.create(this.multiAnchor, prog.hasWordBoundary());
    // The wide expansion can walk backward over an entire line. Keep it out of the DFA loop,
    // which could otherwise repeat that walk at each position before the same inner hit.
    this.dfaStartAcceleration = !wideLeadingExpansion;
    this.enginePathOptions = enginePathOptions;
    this.rejectPrefilter = RejectPrefilter.create(this.multiAnchor);
    // When find() runs a wide-class leading expansion, its inner literal search fails exactly when
    // the reject prefilter would reject, so the prefilter's scan would only repeat it.
    this.startSubsumesFindReject =
        enginePathOptions.startAcceleration()
            && !prog.anchorStart()
            && stringStartAccelerator != null
            && utf8StartAccelerator != null
            && this.multiAnchor.startSubsumesFindReject();
    this.innerLiteralSearch =
        enginePathOptions.startAcceleration()
                && enginePathOptions.literalFastPaths()
                && this.matchDescriptor.literalMatch() == null
                && !prog.anchorStart()
                && this.multiAnchor.startPlan()
                    instanceof MultiAnchorDescriptor.StartPlan.Literal lit
                && !lit.foldCase()
            ? InnerLiteralSearch.compile(ast, rejectPrefilter)
            : null;
    this.startPrecedesFindReject =
        enginePathOptions.startAcceleration()
            && !prog.anchorStart()
            && findRejectPrefilter() != null
            && stringStartAccelerator != null
            && utf8StartAccelerator != null
            && this.multiAnchor.startPrecedesFindReject();
    // The literal-alternation runner skips canReject on its initial String find().
    // The filter's type still selects its window policy; fallback operations retain the filter.
    this.literalAlternation =
        numGroups() == 0
                && this.matchDescriptor.literalMatch() == null
                && this.multiAnchor.startPlan()
                    instanceof MultiAnchorDescriptor.StartPlan.MultiLiteral
                && (rejectPrefilter == null
                    || rejectPrefilter instanceof RejectPrefilter.DisjointLiterals)
            ? LiteralAlternation.compile(
                ast,
                rejectPrefilter instanceof RejectPrefilter.DisjointLiterals,
                utf8StartAccelerator instanceof Utf8StartAccelerator.CharClass charClass
                    ? charClass
                    : null)
            : null;
    // Eagerly prepare the artifacts that find() and group() may need, to avoid latency spikes on
    // first use. Artifacts that only specific operations can use are built on first use instead.
    if (shouldEagerlyBuildOnePass()) {
      onePassAnalysis();
    }
    this.defaultPreparedMatchRunner = createPreparedRunner(false);
    this.regionPreparedMatchRunner = createPreparedRunner(true);
    // Literal runners answer String find() without the forward DFA, so its program and setup
    // are built on first use by another operation.
    if (!(defaultPreparedMatchRunner instanceof Matcher.LiteralPreparedRunner
        || defaultPreparedMatchRunner instanceof Matcher.LiteralAlternationPreparedRunner)) {
      forwardDfaSetup();
    }
    // Flattening removes unreachable instructions, so eager paths must inspect their actual
    // prepared program. Only literal runners defer this work; their source has no grapheme or
    // loop-register instructions, and therefore already establishes support.
    Prog forwardProgram = flatDfaProg != null ? flatDfaProg : flatProg != null ? flatProg : prog;
    this.forwardDfaSupported = enginePathOptions.dfa() && supportsForwardDfa(forwardProgram);
    RejectPrefilter baseFindReject =
        this.innerLiteralSearch == null || !this.forwardDfaSupported ? this.rejectPrefilter : null;
    this.utf8FindRejectPrefilter =
        baseFindReject != null
                && enginePathOptions.startAcceleration()
                && this.utf8StartAccelerator != null
                && !prog.anchorStart()
            ? RejectPrefilter.withoutDisjointLiterals(baseFindReject)
            : baseFindReject;

    SafeReMatchDiagnostics listener = diagnostics();
    if (SafeReMatchDiagnostics.isEnabled(listener)) {
      listener.onPatternCompiled(new PatternCompiledEvent(descriptor()));
    }
  }

  private static boolean canUseLiteralPreparedRunner(
      String literal, int numCaptures, EnginePathOptions enginePathOptions) {
    return enginePathOptions.literalFastPaths() && literal != null && numCaptures == 1;
  }

  private static MatchDescriptor extractMatchDescriptor(
      Regexp metadataAst, AstAnalysis astAnalysis, int flags) {
    LiteralResult literalMatchResult = extractLiteralMatch(metadataAst);
    String literalMatch = literalMatchResult.literal();
    boolean literalFoldCase = literalMatchResult.foldCase();
    boolean hasUserCaptures = astAnalysis.hasUserCaptures();
    CharClassScanInfo singleCharClass = extractSingleCharClass(metadataAst, hasUserCaptures);
    KeywordAlternation keywordAlternation = extractKeywordAlternation(metadataAst, flags);
    CharClassMatchInfo ccMatch = extractCharClassMatch(metadataAst, hasUserCaptures);
    int minMatchLength = astAnalysis.minMatchLength();
    if (literalMatch == null
        && singleCharClass == null
        && keywordAlternation == null
        && ccMatch == null
        && minMatchLength <= 0) {
      return MatchDescriptor.NONE;
    }
    return new MatchDescriptor(
        literalMatch,
        literalFoldCase,
        singleCharClass,
        keywordAlternation,
        ccMatch,
        minMatchLength);
  }

  private static long nextPatternId() {
    long id = NEXT_PATTERN_ID.getAndIncrement();
    if (id <= 0) {
      throw new IllegalStateException("pattern diagnostics identifier space exhausted");
    }
    return id;
  }

  /**
   * Installs the process-wide synchronous match diagnostics listener.
   *
   * <p>The listener is invoked on compiling and matching threads and remains installed until
   * replaced. Use {@link SafeReMatchDiagnostics#NONE} to disable diagnostics.
   *
   * @param listener the listener to install
   */
  public static void setDiagnostics(SafeReMatchDiagnostics listener) {
    setDiagnosticsTarget(Objects.requireNonNull(listener, "listener"));
    MutableCallSite.syncAll(new MutableCallSite[] {DIAGNOSTICS_SITE});
  }

  /**
   * Returns the currently installed process-wide match diagnostics listener.
   *
   * @return the installed listener
   */
  public static SafeReMatchDiagnostics diagnostics() {
    try {
      return (SafeReMatchDiagnostics) DIAGNOSTICS_INVOKER.invokeExact();
    } catch (Throwable impossible) {
      throw new AssertionError(impossible);
    }
  }

  private static void setDiagnosticsTarget(SafeReMatchDiagnostics listener) {
    DIAGNOSTICS_SITE.setTarget(MethodHandles.constant(SafeReMatchDiagnostics.class, listener));
  }

  /**
   * Compiles the given regular expression into a pattern with default flags.
   *
   * @param regex the expression to be compiled
   * @return the compiled pattern
   * @throws PatternSyntaxException if the expression's syntax is invalid
   */
  public static Pattern compile(String regex) {
    return compile(regex, 0);
  }

  /**
   * Compiles the given regular expression into a pattern with the given flags.
   *
   * @param regex the expression to be compiled
   * @param flags match flags, a bit mask of {@link #CASE_INSENSITIVE}, {@link #MULTILINE}, {@link
   *     #DOTALL}, {@link #UNICODE_CHARACTER_CLASS}, {@link #LITERAL}, {@link #COMMENTS}, {@link
   *     #UNIX_LINES}, and {@link #UNICODE_CASE}
   * @return the compiled pattern
   * @throws PatternSyntaxException if the expression's syntax is invalid
   * @throws IllegalArgumentException if the flags contain unsupported bits (e.g., {@code CANON_EQ})
   */
  public static Pattern compile(String regex, int flags) {
    return compile(regex, flags, EnginePathOptions.allEnabled());
  }

  static Pattern compile(String regex, int flags, EnginePathOptions enginePathOptions) {
    validateFlags(flags);
    Objects.requireNonNull(enginePathOptions, "enginePathOptions");
    int effectiveFlags = effectiveFlags(flags);
    int parseFlags = toParseFlags(effectiveFlags);
    Regexp re = Parser.parse(regex, parseFlags);
    Compiler.Prepared prepared = Compiler.prepare(re);
    Prog compiled = Compiler.compile(prepared, false);
    if (compiled == null) {
      throw new PatternSyntaxException("compiled program too large", regex, -1);
    }
    compiled.setUnixLines((effectiveFlags & UNIX_LINES) != 0);
    // Language-shape accelerators should see through source-only grouping. Correctness guards
    // below still inspect the source AST because source quantifiers carry matching semantics that
    // simplification deliberately lowers away.
    Regexp metadataAst = prepared.simplifiedSource();
    AstAnalysis astAnalysis = AstAnalysis.analyze(re);
    MultiAnchorDescriptor multiAnchor = MultiAnchorCompiler.compile(metadataAst, effectiveFlags);
    MatchDescriptor matchDescriptor = extractMatchDescriptor(metadataAst, astAnalysis, flags);
    boolean startsWithGcb =
        compiled.hasGraphemeSemantics() && startsWithGraphemeClusterBoundary(metadataAst);
    boolean hasInternalGcb =
        compiled.hasGraphemeSemantics() && hasInternalExplicitGraphemeBoundary(re);
    // The constructor eagerly prepares the applicable engine analysis and setup.
    return new Pattern(
        regex,
        effectiveFlags,
        compiled,
        prepared,
        re,
        astAnalysis,
        matchDescriptor,
        startsWithGcb,
        hasInternalGcb,
        multiAnchor,
        enginePathOptions);
  }

  /**
   * Compiles the given regular expression and attempts to match the given input against it. This is
   * equivalent to {@code Pattern.compile(regex).matcher(input).matches()}.
   *
   * @param regex the expression to be compiled
   * @param input the character sequence to be matched
   * @return {@code true} if the entire input matches the pattern
   * @throws PatternSyntaxException if the expression's syntax is invalid
   */
  public static boolean matches(String regex, CharSequence input) {
    return compile(regex).matcher(input).matches();
  }

  /**
   * Materializes a {@link CharSequence} by reading through {@code charAt()}, so custom
   * implementations that do not override {@code toString()} are handled correctly.
   */
  private static String charSequenceToString(CharSequence cs) {
    if (cs instanceof String s) {
      return s;
    }
    int len = cs.length();
    char[] chars = new char[len];
    for (int i = 0; i < len; i++) {
      chars[i] = cs.charAt(i);
    }
    return new String(chars);
  }

  /**
   * Returns a literal pattern string for the specified string. Metacharacters and escape sequences
   * in the returned string will have no special meaning.
   *
   * @param s the string to be literalized
   * @return a literal pattern string
   */
  public static String quote(String s) {
    // Use \Q...\E quoting. If the string contains \E, split around it.
    if (!s.contains("\\E")) {
      return "\\Q" + s + "\\E";
    }
    StringBuilder sb = new StringBuilder();
    sb.append("\\Q");
    int last = 0;
    int idx;
    while ((idx = s.indexOf("\\E", last)) != -1) {
      sb.append(s, last, idx);
      sb.append("\\E\\\\E\\Q");
      last = idx + 2;
    }
    sb.append(s, last, s.length());
    sb.append("\\E");
    return sb.toString();
  }

  /**
   * Creates a matcher that will match the given input against this pattern.
   *
   * @param input the character sequence to be matched
   * @return a new matcher for this pattern
   */
  public Matcher matcher(CharSequence input) {
    return new Matcher(this, input);
  }

  /**
   * Creates a matcher over UTF-8 input whose positions are relative byte offsets.
   *
   * @param input borrowed UTF-8 input retained for the lifetime of the matcher
   * @return a new, non-thread-safe UTF-8 matcher
   */
  public Utf8Matcher matcher(Utf8Input input) {
    return new Utf8Matcher(this, input);
  }

  /**
   * Returns whether this pattern occurs in the supplied UTF-8 input.
   *
   * @param input borrowed UTF-8 input retained only for this call
   * @return whether the pattern occurs
   */
  public boolean find(Utf8Input input) {
    ArrayUtf8Input arrayInput = (ArrayUtf8Input) Objects.requireNonNull(input, "input");
    if (!canFindWithoutMatcher()) {
      return new Utf8Matcher(this, arrayInput).find();
    }
    Utf8InputScanner scanner = arrayInput.scanner();
    SafeReMatchDiagnostics listener = diagnostics();
    if (SafeReMatchDiagnostics.isEnabled(listener)) {
      return findWithDiagnostics(scanner);
    }
    return literalAlternation != null
        ? findWithLiteralAlternation(scanner)
        : findWithoutDiagnostics(scanner);
  }

  /**
   * Answers {@link #find(Utf8Input)} with the literal-alternation search when it applies. Kept out
   * of {@link #findWithoutDiagnostics}, whose compiled code is sensitive to its bytecode size.
   */
  private boolean findWithLiteralAlternation(Utf8InputScanner scanner) {
    long match =
        enginePathOptions.literalFastPaths()
            ? literalAlternation.find(scanner, 0)
            : LiteralAlternation.FALLBACK;
    return match == LiteralAlternation.FALLBACK
        ? findWithoutDiagnostics(scanner)
        : match != LiteralAlternation.NO_MATCH;
  }

  /**
   * Returns whether the matcher-free existence searches ({@link #find(Utf8Input)} and {@link
   * #asPredicate()}) can answer for this pattern.
   *
   * <p>Those paths use cheap checks followed by the forward first-match DFA or an end-anchored
   * reverse search, with exact NFA verification and fallback. Patterns with grapheme semantics or
   * loop registers use a matcher instead, so they get its full strategy sequence.
   */
  private boolean canFindWithoutMatcher() {
    return enginePathOptions.dfa() && !prog.hasGraphemeSemantics() && prog.numLoopRegs() == 0;
  }

  boolean findWithDiagnostics(Utf8InputScanner scanner) {
    SafeReMatchDiagnostics listener = diagnostics();
    DiagnosticAccumulator accumulator = new DiagnosticAccumulator();
    boolean matched = findWithDiagnostics(scanner, accumulator);
    accumulator.matchCount(matched ? 1 : 0);
    MatchOutcome outcome = matched ? MatchOutcome.MATCH : MatchOutcome.NO_MATCH;
    OperationDiagnostics event =
        accumulator.toEvent(
            descriptor(), MatchOperation.FIND, outcome, CaptureMode.NONE, scanner.length());
    listener.onOperationCompleted(event);
    return matched;
  }

  private boolean findLiteralMatch(Utf8InputScanner scanner) {
    if (prog.anchorStart()) {
      return scanner.startsWith(literalMatchUtf8, 0);
    }
    return scanner.indexOf(
            literalMatchUtf8,
            literalMatchFailure,
            literalMatchShifts,
            0,
            literalMatchRareByteOffset)
        >= 0;
  }

  boolean findWithoutDiagnostics(Utf8InputScanner scanner) {
    int length = scanner.length();
    if (matchDescriptor.minMatchLength() > 0 && length < matchDescriptor.minMatchLength()) {
      return false;
    }
    if (literalMatchUtf8 != null && !literalFoldCase()) {
      return findLiteralMatch(scanner);
    }
    if (enginePathOptions.keywordAlternationFastPath()
        && matchDescriptor.keywordAlternation() != null) {
      return matchDescriptor.keywordAlternation().find(scanner, 0) >= 0;
    }
    if (prog.anchorStart()) {
      if (anchoredPrefixUtf8 != null) {
        if (!scanner.startsWith(anchoredPrefixUtf8, 0)) {
          return false;
        }
      } else if (anchoredCharClassPrefix != null) {
        if (scanner.length() == 0) {
          return false;
        }
        int cp = scanner.codePointAt(0);
        if (!anchoredCharClassPrefix.contains(cp)) {
          return false;
        }
      }
    }
    int endAnchoredStart = endAnchoredSearchStart(scanner, 0, false, null);
    if (endAnchoredStart == -1) {
      return false;
    }
    if (endAnchoredStart >= 0 && findAt(scanner, endAnchoredStart)) {
      return true;
    }
    RejectPrefilter findRejectPrefilter = utf8FindRejectPrefilter();
    boolean rejectAfterStart =
        findRejectPrefilter != null
            && startPrecedesFindReject
            && length < MAX_LITERAL_START_FIRST_LENGTH;
    if (findRejectPrefilter != null
        && !rejectAfterStart
        && !startSubsumesFindReject
        && findRejectPrefilter.canReject(null, scanner, 0, enginePathOptions)) {
      return false;
    }
    int searchStart = 0;
    boolean startPositionPreselected = false;
    if (enginePathOptions.startAcceleration()
        && utf8StartAccelerator != null
        && !prog.anchorStart()) {
      searchStart = findNextUtf8StartCandidate(scanner, null);
      if (searchStart < 0
          || (rejectAfterStart
              && length - searchStart >= MIN_REJECT_AFTER_START_REMAINING
              && findRejectPrefilter.canRejectTail(
                  null, scanner, searchStart, enginePathOptions))) {
        return false;
      }
      startPositionPreselected = true;
    }
    if (endAnchoredStart == END_ANCHORED_SEARCH_DEFERRED) {
      endAnchoredStart = endAnchoredSearchStart(scanner, searchStart, false, null, false);
      if (endAnchoredStart == -1) {
        return false;
      }
      if (endAnchoredStart >= 0 && findAt(scanner, endAnchoredStart)) {
        return true;
      }
    }
    // The forward DFA checks a stripped end anchor itself, as the matcher's DFA pass relies on, so
    // end-anchored programs that the reverse probe could not settle avoid the NFA here too.
    Dfa.SearchResult result =
        forwardFirstMatchDfa()
            .doSearch(scanner, searchStart, prog.anchorStart(), false, startPositionPreselected);
    if (result != null) {
      return result.matched();
    }
    return Nfa.search(
            prog,
            scanner,
            searchStart,
            length,
            length,
            0,
            Nfa.Anchor.UNANCHORED,
            Nfa.MatchKind.FIRST_MATCH,
            0,
            null)
        != null;
  }

  private boolean findWithDiagnostics(Utf8InputScanner scanner, DiagnosticAccumulator diagnostics) {
    int length = scanner.length();
    if (matchDescriptor.minMatchLength() > 0 && length < matchDescriptor.minMatchLength()) {
      diagnostics.boundary(MatchStrategy.LENGTH);
      return false;
    }
    if (literalMatchUtf8 != null && !literalFoldCase()) {
      boolean matched = findLiteralMatch(scanner);
      diagnostics.boundary(MatchStrategy.LITERAL);
      return matched;
    }
    if (enginePathOptions.keywordAlternationFastPath()
        && matchDescriptor.keywordAlternation() != null) {
      boolean matched = matchDescriptor.keywordAlternation().find(scanner, 0) >= 0;
      diagnostics.boundary(MatchStrategy.KEYWORD);
      return matched;
    }
    if (literalAlternation != null && enginePathOptions.literalFastPaths()) {
      long match = literalAlternation.find(scanner, 0);
      if (match != LiteralAlternation.FALLBACK) {
        diagnostics.boundary(MatchStrategy.LITERAL_ALTERNATION);
        return match != LiteralAlternation.NO_MATCH;
      }
    }
    if (prog.anchorStart()) {
      if (anchoredPrefixUtf8 != null) {
        if (!scanner.startsWith(anchoredPrefixUtf8, 0)) {
          diagnostics.participate(MatchStrategy.LITERAL, StrategyRole.REJECT_PREFILTER);
          diagnostics.boundary(MatchStrategy.LITERAL);
          return false;
        }
      } else if (anchoredCharClassPrefix != null) {
        if (scanner.length() == 0) {
          diagnostics.participate(MatchStrategy.CHARACTER_CLASS, StrategyRole.REJECT_PREFILTER);
          diagnostics.boundary(MatchStrategy.CHARACTER_CLASS);
          return false;
        }
        int cp = scanner.codePointAt(0);
        if (!anchoredCharClassPrefix.contains(cp)) {
          diagnostics.participate(MatchStrategy.CHARACTER_CLASS, StrategyRole.REJECT_PREFILTER);
          diagnostics.boundary(MatchStrategy.CHARACTER_CLASS);
          return false;
        }
      }
    }
    int endAnchoredStart = endAnchoredSearchStart(scanner, 0, false, diagnostics);
    if (endAnchoredStart == -1) {
      return false;
    }
    if (endAnchoredStart >= 0 && findAt(scanner, endAnchoredStart, diagnostics)) {
      return true;
    }
    RejectPrefilter findRejectPrefilter = utf8FindRejectPrefilter();
    boolean rejectAfterStart =
        findRejectPrefilter != null
            && startPrecedesFindReject
            && length < MAX_LITERAL_START_FIRST_LENGTH;
    if (findRejectPrefilter != null
        && !rejectAfterStart
        && !startSubsumesFindReject
        && rejectsWithDiagnostics(findRejectPrefilter, scanner, 0, diagnostics)) {
      return false;
    }
    int searchStart = 0;
    boolean startPositionPreselected = false;
    if (enginePathOptions.startAcceleration()
        && utf8StartAccelerator != null
        && !prog.anchorStart()) {
      searchStart = findNextUtf8StartCandidate(scanner, diagnostics);
      if (searchStart < 0
          || (rejectAfterStart
              && length - searchStart >= MIN_REJECT_AFTER_START_REMAINING
              && rejectsTailWithDiagnostics(
                  findRejectPrefilter, scanner, searchStart, diagnostics))) {
        return false;
      }
      startPositionPreselected = true;
    }
    if (endAnchoredStart == END_ANCHORED_SEARCH_DEFERRED) {
      endAnchoredStart = endAnchoredSearchStart(scanner, searchStart, false, diagnostics, false);
      if (endAnchoredStart == -1) {
        return false;
      }
      if (endAnchoredStart >= 0 && findAt(scanner, endAnchoredStart, diagnostics)) {
        return true;
      }
    }
    diagnostics.participate(MatchStrategy.DFA, StrategyRole.REJECT_PREFILTER);
    diagnostics.incrementForwardDfaSearchCount();
    Dfa.SearchResult result =
        forwardFirstMatchDfa()
            .doSearch(scanner, searchStart, prog.anchorStart(), false, startPositionPreselected);
    if (result != null) {
      diagnostics.boundary(MatchStrategy.DFA);
      return result.matched();
    }
    diagnostics.decision(
        MatchStrategy.DFA, StrategyDisposition.FALLBACK, StrategyReason.DFA_BUDGET_EXCEEDED);
    boolean matched =
        Nfa.search(
                prog,
                scanner,
                searchStart,
                length,
                length,
                0,
                Nfa.Anchor.UNANCHORED,
                Nfa.MatchKind.FIRST_MATCH,
                0,
                null)
            != null;
    diagnostics.boundary(MatchStrategy.NFA);
    return matched;
  }

  /** Shares candidate selection between the diagnostic and non-diagnostic matcher-free paths. */
  private int findNextUtf8StartCandidate(
      Utf8InputScanner scanner, DiagnosticAccumulator diagnostics) {
    MatchStrategy strategy = utf8StartAccelerator.policy().strategy();
    if (diagnostics != null && strategy != null) {
      diagnostics.participate(strategy, StrategyRole.START_ACCELERATION);
    }
    if (utf8StartAccelerator instanceof Utf8StartAccelerator.LeadingExpansion le
        && le.canVerifyAtInner()) {
      int innerMatch = le.findInnerCandidate(scanner, 0);
      if (innerMatch >= 0) {
        // With zero repetitions and no leading assertions, an unanchored rejection from the
        // inner candidate also rejects every expanded start. Do this before walking backward.
        if (diagnostics != null) {
          diagnostics.participate(MatchStrategy.DFA, StrategyRole.CANDIDATE_VERIFICATION);
          diagnostics.incrementForwardDfaSearchCount();
        }
        Dfa.SearchResult result =
            forwardFirstMatchDfa().doSearch(scanner, innerMatch, false, false, true);
        if (result != null && !result.matched()) {
          if (diagnostics != null) {
            diagnostics.boundary(MatchStrategy.DFA);
          }
          return -1;
        }
        if (result == null && diagnostics != null) {
          diagnostics.decision(
              MatchStrategy.DFA, StrategyDisposition.FALLBACK, StrategyReason.DFA_BUDGET_EXCEEDED);
        }
        return le.expandBackward(scanner, innerMatch, 0);
      }
    } else {
      int candidate = Utf8StartAccelerator.findNextCandidate(utf8StartAccelerator, scanner, 0);
      if (candidate >= 0) {
        return candidate;
      }
    }
    if (diagnostics != null && strategy != null) {
      diagnostics.boundary(strategy);
    }
    return -1;
  }

  /**
   * Proposes a start of an end-anchored search before any forward prefix scan. With {@code
   * leftmostStart}, scans for the leftmost start needed for spans; otherwise stops at the first
   * accepted candidate for existence-only matching. Returns {@code -1} for a proven rejection,
   * {@link #END_ANCHORED_SEARCH_DEFERRED} when the probe needs rejection and start acceleration
   * before one full retry, or {@link #END_ANCHORED_SEARCH_FALLBACK} when ordinary search is
   * required. A proposed start still requires exact matching; failure to verify it must fall back
   * to ordinary search.
   */
  int endAnchoredSearchStart(
      InputScanner scanner,
      int searchFrom,
      boolean leftmostStart,
      DiagnosticAccumulator diagnostics) {
    return endAnchoredSearchStart(scanner, searchFrom, leftmostStart, diagnostics, true);
  }

  /** A deferred probe may retry once after ordinary rejection and start acceleration. */
  int endAnchoredSearchStart(
      InputScanner scanner,
      int searchFrom,
      boolean leftmostStart,
      DiagnosticAccumulator diagnostics,
      boolean speculative) {
    if (!prog.anchorEnd()
        || scanner.length() < MIN_REVERSE_FIRST_LEN
        || !enginePathOptions.dfa()
        || !enginePathOptions.reverseDfa()
        || !canUseReverseDfa()) {
      return END_ANCHORED_SEARCH_FALLBACK;
    }
    if (terminalPrefilterRejects(scanner, searchFrom, diagnostics)) {
      return -1;
    }
    Prog reverseProgram = flatReverseDfaProg();
    if (reverseProgram == null
        || reverseProgram.hasGraphemeSemantics()
        || reverseProgram.numLoopRegs() != 0) {
      return END_ANCHORED_SEARCH_FALLBACK;
    }
    Dfa reverse = reverseDfa();
    if (reverse == null) {
      return END_ANCHORED_SEARCH_FALLBACK;
    }
    // A literal run needs at most four UTF-8 units per consuming instruction. Leave a small
    // minimum for short loops; exceeding the probe defers to ordinary start acceleration.
    int probeUnits =
        (int)
            Math.min(
                Integer.MAX_VALUE,
                Math.max(MIN_END_ANCHORED_PROBE_UNITS, 4L * reverseProgram.size()));
    return searchEndAnchoredStart(
        reverse,
        scanner,
        searchFrom,
        leftmostStart,
        diagnostics,
        speculative ? probeUnits : Integer.MAX_VALUE);
  }

  private int searchEndAnchoredStart(
      Dfa reverse,
      InputScanner scanner,
      int searchFrom,
      boolean leftmostStart,
      DiagnosticAccumulator diagnostics,
      int maxInputUnits) {
    if (diagnostics != null) {
      diagnostics.participate(MatchStrategy.DFA, StrategyRole.REJECT_PREFILTER);
      diagnostics.incrementReverseDfaSearchCount();
    }
    int length = scanner.length();
    Dfa.SearchResult result =
        reverse.doSearchReverse(scanner, length, searchFrom, true, leftmostStart, maxInputUnits);
    int start = -1;
    boolean ambiguous = false;
    boolean budgetExceeded = result == null;
    boolean windowExceeded = result != null && result.scanLimitReached();
    if (result != null && result.matched() && result.pos() >= searchFrom) {
      start = result.pos();
      ambiguous = result.ambiguous();
    }
    // Non-multiline $ also accepts the position before a final line terminator. Span searches
    // compare both endpoints for the leftmost start; exact matching decides the prioritized end.
    if (!budgetExceeded && prog.dollarAnchorEnd()) {
      int trailingStart = scanner.trailingLineTerminatorStart(prog.dollarAnchorUnixLines(), length);
      if (trailingStart >= searchFrom) {
        if (diagnostics != null) {
          diagnostics.incrementReverseDfaSearchCount();
        }
        Dfa.SearchResult alternative =
            reverse.doSearchReverse(
                scanner, trailingStart, searchFrom, true, leftmostStart, maxInputUnits);
        budgetExceeded = alternative == null;
        windowExceeded |= alternative != null && alternative.scanLimitReached();
        if (alternative != null
            && alternative.matched()
            && alternative.pos() >= searchFrom
            && (start < 0 || alternative.pos() < start)) {
          start = alternative.pos();
          ambiguous = alternative.ambiguous();
        }
      }
    }
    if (budgetExceeded || (leftmostStart && ambiguous)) {
      if (diagnostics != null) {
        diagnostics.decision(
            MatchStrategy.DFA,
            budgetExceeded ? StrategyDisposition.FALLBACK : StrategyDisposition.BYPASSED,
            budgetExceeded
                ? StrategyReason.DFA_BUDGET_EXCEEDED
                : StrategyReason.AUTHORITATIVE_BOUNDS_REQUIRED);
      }
      return END_ANCHORED_SEARCH_FALLBACK;
    }
    if (windowExceeded && (leftmostStart || start < 0)) {
      if (diagnostics != null) {
        diagnostics.decision(
            MatchStrategy.DFA, StrategyDisposition.FALLBACK, StrategyReason.WORK_BUDGET_EXCEEDED);
      }
      return END_ANCHORED_SEARCH_DEFERRED;
    }
    if (start < 0 && diagnostics != null) {
      diagnostics.boundary(MatchStrategy.DFA);
    }
    return start;
  }

  /**
   * Returns whether a match starts at {@code start}. Uses BitState when the remaining input fits
   * its bitmap, as {@code Matcher}'s end-anchored verification does, and the NFA otherwise or when
   * BitState exceeds its work budget.
   */
  private boolean findAt(InputScanner scanner, int start) {
    return findAt(scanner, start, null);
  }

  private boolean findAt(InputScanner scanner, int start, DiagnosticAccumulator diagnostics) {
    int length = scanner.length();
    int maxBitStateLen = BitState.maxTextSize(prog);
    if (enginePathOptions.bitState() && maxBitStateLen >= 0 && length - start <= maxBitStateLen) {
      if (diagnostics != null) {
        diagnostics.participate(MatchStrategy.BIT_STATE, StrategyRole.CANDIDATE_VERIFICATION);
      }
      ThreadCache cache = getOrCreateThreadCache();
      BitState bitState =
          BitState.getOrCreate(
              borrowBitState(cache), prog, scanner, start, length, 2, false, prog.anchorEnd());
      int[] result = bitState.doSearch(start, start, true);
      returnBitState(cache, bitState);
      if (!bitState.budgetExceeded()) {
        if (result != null && diagnostics != null) {
          diagnostics.boundary(MatchStrategy.BIT_STATE);
        }
        return result != null;
      }
      if (diagnostics != null) {
        diagnostics.decision(
            MatchStrategy.BIT_STATE,
            StrategyDisposition.FALLBACK,
            StrategyReason.WORK_BUDGET_EXCEEDED);
      }
    }
    if (diagnostics != null) {
      diagnostics.participate(MatchStrategy.NFA, StrategyRole.CANDIDATE_VERIFICATION);
    }
    boolean matched =
        Nfa.search(
                prog,
                scanner,
                start,
                scanner.length(),
                scanner.length(),
                0,
                Nfa.Anchor.ANCHORED,
                Nfa.MatchKind.FIRST_MATCH,
                0,
                null)
            != null;
    if (matched && diagnostics != null) {
      diagnostics.boundary(MatchStrategy.NFA);
    }
    return matched;
  }

  static int[] literalFailure(byte[] literal) {
    int[] failure = new int[literal.length];
    int matched = 0;
    for (int index = 1; index < literal.length; index++) {
      while (matched > 0 && literal[index] != literal[matched]) {
        matched = failure[matched - 1];
      }
      if (literal[index] == literal[matched]) {
        matched++;
      }
      failure[index] = matched;
    }
    return failure;
  }

  static int[] literalShifts(byte[] literal) {
    if (literal.length < 2) {
      return null;
    }
    int[] shifts = new int[256];
    Arrays.fill(shifts, literal.length);
    for (int index = 0; index < literal.length - 1; index++) {
      shifts[literal[index] & 0xFF] = literal.length - index - 1;
    }
    return shifts;
  }

  /**
   * Returns the match flags specified when this pattern was compiled.
   *
   * @return the match flags
   */
  public int flags() {
    return flags;
  }

  /**
   * Returns the regular expression from which this pattern was compiled.
   *
   * @return the source of this pattern
   */
  public String pattern() {
    return pattern;
  }

  /**
   * Splits the given input around matches of this pattern. Trailing empty strings are discarded.
   *
   * @param input the character sequence to be split
   * @return the array of strings computed by splitting the input around matches of this pattern
   */
  public String[] split(CharSequence input) {
    return split(input, 0);
  }

  /**
   * Splits the given input around matches of this pattern.
   *
   * <p>The {@code limit} parameter controls the number of times the pattern is applied:
   *
   * <ul>
   *   <li>If {@code limit > 0}, the pattern is applied at most {@code limit - 1} times, and the
   *       resulting array will have at most {@code limit} entries.
   *   <li>If {@code limit == 0}, the pattern is applied as many times as possible, and trailing
   *       empty strings are discarded.
   *   <li>If {@code limit < 0}, the pattern is applied as many times as possible, and trailing
   *       empty strings are retained.
   * </ul>
   *
   * @param input the character sequence to be split
   * @param limit the result threshold
   * @return the array of strings computed by splitting the input around matches of this pattern
   */
  public String[] split(CharSequence input, int limit) {
    String text = charSequenceToString(input);
    Matcher m = matcher(text);
    Matcher.SplitBuffer buffer = new Matcher.SplitBuffer();
    int matchesCount = m.findSplitPositions(limit, buffer);
    if (matchesCount == 0) {
      return new String[] {text};
    }
    int partsCount = (limit > 0) ? Math.min(limit, matchesCount + 1) : matchesCount + 1;
    String[] parts = new String[partsCount];
    int last = 0;
    int i = 0;
    while (i < partsCount - 1) {
      int start = buffer.array[2 * i];
      int end = buffer.array[2 * i + 1];
      parts[i] = text.substring(last, start);
      last = end;
      i++;
    }
    parts[i] = text.substring(last);

    if (limit == 0) {
      int end = partsCount;
      while (end > 0 && parts[end - 1].isEmpty()) {
        end--;
      }
      if (end < partsCount) {
        parts = Arrays.copyOf(parts, end);
      }
    }
    return parts;
  }

  /**
   * Splits the given input around matches of this pattern, returning both the substrings between
   * matches and the matching delimiters, interleaved. The resulting array alternates between
   * substrings and delimiters: {@code [substring, delimiter, substring, delimiter, ...,
   * substring]}.
   *
   * <p>This is equivalent to {@code splitWithDelimiters(input, 0)}.
   *
   * @param input the character sequence to be split
   * @return the array of strings computed by splitting the input around matches of this pattern,
   *     with the matching delimiters interleaved
   * @since 21
   */
  public String[] splitWithDelimiters(CharSequence input) {
    return splitWithDelimiters(input, 0);
  }

  /**
   * Splits the given input around matches of this pattern, returning both the substrings between
   * matches and the matching delimiters, interleaved.
   *
   * <p>The {@code limit} parameter controls the number of times the pattern is applied:
   *
   * <ul>
   *   <li>If {@code limit > 0}, the pattern is applied at most {@code limit - 1} times, and the
   *       resulting array will have at most {@code 2 * limit - 1} entries.
   *   <li>If {@code limit == 0}, the pattern is applied as many times as possible, and trailing
   *       empty strings are discarded.
   *   <li>If {@code limit < 0}, the pattern is applied as many times as possible, and trailing
   *       empty strings are retained.
   * </ul>
   *
   * @param input the character sequence to be split
   * @param limit the result threshold
   * @return the array of strings computed by splitting the input around matches of this pattern,
   *     with the matching delimiters interleaved
   * @since 21
   */
  public String[] splitWithDelimiters(CharSequence input, int limit) {
    String text = charSequenceToString(input);
    Matcher m = matcher(text);
    Matcher.SplitBuffer buffer = new Matcher.SplitBuffer();
    int matchesCount = m.findSplitPositions(limit, buffer);
    if (matchesCount == 0) {
      return new String[] {text};
    }
    int partsCount = 2 * matchesCount + 1;
    if (limit > 0) {
      partsCount = (int) Math.min(2L * limit - 1, partsCount);
    }
    String[] parts = new String[partsCount];
    int last = 0;
    int i = 0;
    int matchIdx = 0;
    while (i < partsCount - 1) {
      int start = buffer.array[2 * matchIdx];
      int end = buffer.array[2 * matchIdx + 1];
      parts[i++] = text.substring(last, start);
      parts[i++] = text.substring(start, end);
      last = end;
      matchIdx++;
    }
    parts[i] = text.substring(last);

    if (limit == 0) {
      int end = partsCount;
      while (end > 0 && parts[end - 1].isEmpty()) {
        end--;
      }
      if (end < partsCount) {
        parts = Arrays.copyOf(parts, end);
      }
    }
    return parts;
  }

  /**
   * Creates a stream of strings split from the given input sequence around matches of this pattern.
   * The stream contains the same strings that {@link #split(CharSequence)} would return, produced
   * lazily.
   *
   * @param input the character sequence to be split
   * @return a sequential stream of strings computed by splitting the input around matches of this
   *     pattern
   */
  public Stream<String> splitAsStream(CharSequence input) {
    return StreamSupport.stream(
        () -> Arrays.spliterator(split(input, 0)),
        Spliterator.ORDERED | Spliterator.NONNULL,
        false);
  }

  /**
   * Creates a predicate that tests if this pattern is found in a given input string. The predicate
   * behaves as if calling {@code matcher(input).find()}.
   *
   * @return a predicate for partial matching
   */
  public Predicate<String> asPredicate() {
    return this::findInString;
  }

  /**
   * Returns whether this pattern occurs in {@code input}, with the same result as {@code
   * matcher(input).find()} but without creating a matcher or computing match bounds. Follows the
   * same strategy sequence as {@link #findWithoutDiagnostics(Utf8InputScanner)}, with the String
   * literal, prefix and start-accelerator data. With diagnostics enabled, delegates to a matcher so
   * the reported operation is unchanged.
   */
  private boolean findInString(String input) {
    if (!canFindWithoutMatcher() || SafeReMatchDiagnostics.isEnabled(diagnostics())) {
      return matcher(input).find();
    }
    int length = input.length();
    if (matchDescriptor.minMatchLength() > 0 && length < matchDescriptor.minMatchLength()) {
      return false;
    }
    // literalMatchUtf8 is non-null only when literal fast paths are enabled.
    if (literalMatchUtf8 != null && !literalFoldCase()) {
      String literal = matchDescriptor.literalMatch();
      return prog.anchorStart() ? input.startsWith(literal) : input.indexOf(literal) >= 0;
    }
    StringInputScanner scanner = new StringInputScanner(input);
    if (enginePathOptions.keywordAlternationFastPath()
        && matchDescriptor.keywordAlternation() != null) {
      return matchDescriptor.keywordAlternation().find(scanner, 0) >= 0;
    }
    if (prog.anchorStart()) {
      if (anchoredPrefixUtf8 != null) {
        if (!input.startsWith(anchoredPrefix)) {
          return false;
        }
      } else if (anchoredCharClassPrefix != null) {
        if (length == 0 || !anchoredCharClassPrefix.contains(input.codePointAt(0))) {
          return false;
        }
      }
    }
    int endAnchoredStart = endAnchoredSearchStart(scanner, 0, false, null);
    if (endAnchoredStart == -1) {
      return false;
    }
    if (endAnchoredStart >= 0 && findAt(scanner, endAnchoredStart)) {
      return true;
    }
    RejectPrefilter findRejectPrefilter = findRejectPrefilter();
    boolean rejectAfterStart =
        findRejectPrefilter != null
            && startPrecedesFindReject
            && length < MAX_LITERAL_START_FIRST_LENGTH;
    if (findRejectPrefilter != null
        && !rejectAfterStart
        && !startSubsumesFindReject
        && findRejectPrefilter.canReject(input, null, 0, enginePathOptions)) {
      return false;
    }
    int searchStart = 0;
    boolean startPositionPreselected = false;
    if (enginePathOptions.startAcceleration()
        && stringStartAccelerator != null
        && !prog.anchorStart()) {
      searchStart = findNextStringStartCandidate(scanner, input);
      if (searchStart < 0
          || (rejectAfterStart
              && length - searchStart >= MIN_REJECT_AFTER_START_REMAINING
              && findRejectPrefilter.canRejectTail(input, null, searchStart, enginePathOptions))) {
        return false;
      }
      startPositionPreselected = true;
    }
    if (endAnchoredStart == END_ANCHORED_SEARCH_DEFERRED) {
      endAnchoredStart = endAnchoredSearchStart(scanner, searchStart, false, null, false);
      if (endAnchoredStart == -1) {
        return false;
      }
      if (endAnchoredStart >= 0 && findAt(scanner, endAnchoredStart)) {
        return true;
      }
    }
    // The forward DFA checks a stripped end anchor itself, as the matcher's DFA pass relies on, so
    // end-anchored programs that the reverse probe could not settle avoid the NFA here too.
    Dfa.SearchResult result =
        forwardFirstMatchDfa()
            .doSearch(scanner, searchStart, prog.anchorStart(), false, startPositionPreselected);
    if (result != null) {
      return result.matched();
    }
    return Nfa.search(
            prog,
            scanner,
            searchStart,
            length,
            length,
            0,
            Nfa.Anchor.UNANCHORED,
            Nfa.MatchKind.FIRST_MATCH,
            0,
            null)
        != null;
  }

  /**
   * Selects the first String start candidate for {@link #findInString}. Literal scans use UTF-16
   * indices, so candidates inside a surrogate pair are skipped, as in the matcher. A nullable
   * leading expansion is first verified at its inner candidate, as in {@link
   * #findNextUtf8StartCandidate}.
   */
  private int findNextStringStartCandidate(StringInputScanner scanner, String text) {
    boolean unixLines = prog.lineStartUnixLines();
    if (stringStartAccelerator instanceof StringStartAccelerator.LeadingExpansion le
        && le.canVerifyAtInner()) {
      int innerMatch = le.findInnerCandidate(text, 0, unixLines);
      while (innerMatch > 0 && !scanner.isCodePointBoundary(innerMatch)) {
        innerMatch = le.findInnerCandidate(text, innerMatch + 1, unixLines);
      }
      if (innerMatch < 0) {
        return -1;
      }
      // With zero repetitions and no leading assertions, an unanchored rejection from the inner
      // candidate also rejects every expanded start.
      Dfa.SearchResult result =
          forwardFirstMatchDfa().doSearch(scanner, innerMatch, false, false, true);
      if (result != null && !result.matched()) {
        return -1;
      }
      return le.expandBackward(text, innerMatch, 0);
    }
    int candidate =
        StringStartAccelerator.findNextCandidate(stringStartAccelerator, text, 0, unixLines);
    while (candidate > 0 && !scanner.isCodePointBoundary(candidate)) {
      candidate =
          StringStartAccelerator.findNextCandidate(
              stringStartAccelerator, text, candidate + 1, unixLines);
    }
    return candidate;
  }

  /**
   * Creates a predicate that tests if this pattern matches a given input string in its entirety.
   * The predicate behaves as if calling {@code matcher(input).matches()}.
   *
   * @return a predicate for full matching
   */
  public Predicate<String> asMatchPredicate() {
    return input -> matcher(input).matches();
  }

  @Override
  public String toString() {
    return pattern;
  }

  // ---------------------------------------------------------------------------
  // Package-private accessors for Matcher
  // ---------------------------------------------------------------------------

  /** Returns the compiled program. */
  Prog prog() {
    return prog;
  }

  EnginePathOptions enginePathOptions() {
    return enginePathOptions;
  }

  /**
   * Replaces the default prepared runner if it is still {@code lazy}, so later operations skip the
   * resolved lazy wrapper. Runners are immutable, so a racy publication is safe; a lazy runner
   * nested inside another runner keeps its own cached resolution instead.
   */
  void replacePreparedMatchRunner(
      Matcher.PreparedMatchRunner lazy, Matcher.PreparedMatchRunner resolved) {
    if (defaultPreparedMatchRunner == lazy) {
      defaultPreparedMatchRunner = resolved;
    }
  }

  Matcher.PreparedMatchRunner preparedMatchRunner(boolean regionActive) {
    return regionActive ? regionPreparedMatchRunner : defaultPreparedMatchRunner;
  }

  private Matcher.PreparedMatchRunner createPreparedRunner(boolean regionActive) {
    Matcher.PreparedMatchRunner fallback = createBasePreparedRunner(regionActive);
    if (literalAlternation != null && enginePathOptions.literalFastPaths()) {
      return new Matcher.LiteralAlternationPreparedRunner(literalAlternation, fallback);
    }
    return fallback;
  }

  private Matcher.PreparedMatchRunner createBasePreparedRunner(boolean regionActive) {
    String literal = matchDescriptor.literalMatch();
    if (canUseLiteralPreparedRunner(literal, prog.numCaptures(), enginePathOptions)) {
      return new Matcher.LiteralPreparedRunner(
          literal,
          matchDescriptor.literalFoldCase(),
          literalMatchUtf8,
          literalMatchFailure,
          literalMatchShifts,
          literalMatchRareByteOffset,
          prog.anchorStart(),
          matchDescriptor.literalFoldCase()
              ? createLiteralFallbackRunner(regionActive)
              : Matcher.FallbackPreparedRunner.INSTANCE,
          matchDescriptor.classHashChain());
    }

    return createLiteralFallbackRunner(regionActive);
  }

  private Matcher.PreparedMatchRunner createLiteralFallbackRunner(boolean regionActive) {
    CharClassScanInfo singleCharClass = matchDescriptor.singleCharClass();
    Pattern.CharClassMatchInfo charClassMatch = matchDescriptor.charClassMatch();
    if (enginePathOptions.charClassMatchFastPaths()
        && (singleCharClass != null || charClassMatch != null)) {
      return new Matcher.SingleCharClassPreparedRunner(
          singleCharClass, charClassMatch, prog.anchorStart(), !astAnalysis.hasLazy());
    }

    if (regionActive) {
      return Matcher.FallbackPreparedRunner.INSTANCE;
    }

    Pattern.KeywordAlternation keywordAlternation = matchDescriptor.keywordAlternation();
    if (enginePathOptions.keywordAlternationFastPath() && keywordAlternation != null) {
      return new Matcher.KeywordAlternationPreparedRunner(
          keywordAlternation, prog.numCaptures(), prog.anchorStart());
    }

    Matcher.PreparedMatchRunner fallback =
        mayOnePassPrimary()
            ? new Matcher.OnePassAnchoredPreparedRunner(prog.numCaptures())
            : Matcher.FallbackPreparedRunner.INSTANCE;
    if (mayUseShiftDfa()) {
      return new Matcher.LazyShiftDfaPreparedRunner(this, fallback);
    }

    return fallback;
  }

  boolean innerCapturesObserved() {
    return innerCapturesObserved;
  }

  void recordInnerCaptureAccess() {
    if (!innerCapturesObserved) {
      innerCapturesObserved = true;
    }
  }

  private ThreadCache existingThreadCache() {
    SoftReference<ThreadCache> ref = threadCache.get();
    return ref != null ? ref.get() : null;
  }

  /**
   * Returns the current thread's cache, creating it if needed. A {@link Matcher} fetches this once
   * and passes it to the cache accessors, so each lookup does not repeat the {@link ThreadLocal}
   * and {@link SoftReference} dereferences.
   */
  ThreadCache getOrCreateThreadCache() {
    ThreadCache cache = existingThreadCache();
    if (cache == null) {
      cache = new ThreadCache();
      threadCache.set(new SoftReference<>(cache));
    }
    return cache;
  }

  /** Returns the thread-local cached BitState, or null if none has been cached yet. */
  BitState borrowBitState() {
    ThreadCache cache = existingThreadCache();
    if (cache == null) {
      return null;
    }
    return borrowBitState(cache);
  }

  static BitState borrowBitState(ThreadCache cache) {
    BitState bs = cache.bitState;
    cache.bitState = null; // take ownership
    return bs;
  }

  /** Returns a BitState to the thread-local cache for reuse by future Matchers. */
  void returnBitState(BitState bs) {
    returnBitState(getOrCreateThreadCache(), bs);
  }

  static void returnBitState(ThreadCache cache, BitState bs) {
    bs.releaseInput();
    cache.bitState = bs;
  }

  Nfa borrowNfa() {
    ThreadCache cache = existingThreadCache();
    if (cache == null) {
      return null;
    }
    return borrowNfa(cache);
  }

  static Nfa borrowNfa(ThreadCache cache) {
    Nfa nfa = cache.nfa;
    cache.nfa = null;
    return nfa;
  }

  void returnNfa(Nfa nfa) {
    returnNfa(getOrCreateThreadCache(), nfa);
  }

  static void returnNfa(ThreadCache cache, Nfa nfa) {
    nfa.releaseInputContext();
    cache.nfa = nfa;
  }

  /** Maximum number of DFA states before the DFA bails out. */
  static final int MAX_DFA_STATES = 10_000;

  /**
   * Returns the thread-local cached forward DFA, creating it on first access. The DFA state cache
   * persists across Matcher instances, so repeated {@code pattern.matcher(t).find()} calls benefit
   * from warm DFA transitions.
   */
  Prog flatProg() {
    Prog p = flatProg;
    if (p == null && enginePathOptions.dfa()) {
      synchronized (this) {
        p = flatProg;
        if (p == null) {
          p = prog.flattenedCopy();
          flatProg = p;
        }
      }
    }
    return p;
  }

  Prog flatDfaProg() {
    Prog p = flatDfaProg;
    if (p == null && enginePathOptions.dfa()) {
      // Only reached without loop registers, where the DFA program is the flattened program.
      p = flatProg();
      flatDfaProg = p;
    }
    return p;
  }

  private boolean dfaStartAcceleration() {
    return enginePathOptions.startAcceleration() && dfaStartAcceleration;
  }

  /** Returns whether DFA paths implement every instruction in {@link #flatDfaProg()}. */
  boolean forwardDfaSupported() {
    return forwardDfaSupported;
  }

  private static boolean supportsForwardDfa(Prog p) {
    return p != null && !p.hasGraphemeSemantics() && p.numLoopRegs() == 0;
  }

  Dfa forwardFirstMatchDfa() {
    return forwardFirstMatchDfa(getOrCreateThreadCache());
  }

  Dfa forwardFirstMatchDfa(ThreadCache cache) {
    Dfa dfa = cache.forwardFirstMatchDfa;
    if (dfa == null) {
      dfa =
          new Dfa(
              flatDfaProg(),
              MAX_DFA_STATES,
              forwardDfaSetup(),
              false,
              dfaStartAcceleration() ? utf8StartAccelerator : null,
              dfaStartAcceleration() ? stringStartAccelerator : null,
              innerLiteralSearch);
      cache.forwardFirstMatchDfa = dfa;
    }
    return dfa;
  }

  Dfa forwardLongestMatchDfa() {
    return forwardLongestMatchDfa(getOrCreateThreadCache());
  }

  Dfa forwardLongestMatchDfa(ThreadCache cache) {
    Dfa dfa = cache.forwardLongestMatchDfa;
    if (dfa == null) {
      dfa =
          new Dfa(
              flatDfaProg(),
              MAX_DFA_STATES,
              forwardDfaSetup(),
              true,
              dfaStartAcceleration() ? utf8StartAccelerator : null,
              dfaStartAcceleration() ? stringStartAccelerator : null);
      cache.forwardLongestMatchDfa = dfa;
    }
    return dfa;
  }

  /**
   * Returns the thread-local cached reverse DFA, creating it on first access. Triggers lazy
   * compilation of the reverse program if needed.
   */
  Dfa reverseDfa() {
    return reverseDfa(getOrCreateThreadCache());
  }

  Dfa reverseDfa(ThreadCache cache) {
    Dfa dfa = cache.reverseDfa;
    if (dfa == null) {
      Prog rp = flatReverseDfaProg();
      if (rp != null) {
        dfa = new Dfa(rp, MAX_DFA_STATES, reverseDfaSetup(), true);
        cache.reverseDfa = dfa;
      }
    }
    return dfa;
  }

  /** Returns the currently cached forward first-match DFA without creating it. For tests. */
  Dfa cachedForwardFirstMatchDfa() {
    ThreadCache cache = existingThreadCache();
    return cache != null ? cache.forwardFirstMatchDfa : null;
  }

  /**
   * Returns whether this pattern satisfies the static preconditions shared by all {@link OnePass}
   * execution paths without building the automaton.
   *
   * <p>Lazy quantifiers and nullable alternations are excluded because {@link OnePass}'s
   * longest-match semantics disagree with leftmost-first quantifier and branch priority, grapheme
   * programs require the exact engine, and capture tracking is bounded by {@link
   * OnePass#MAX_CAPTURE_GROUPS}.
   */
  private boolean mayBuildOnePass() {
    return enginePathOptions.onePass()
        && !astAnalysis.hasLazy()
        && !astAnalysis.hasNullableAlt()
        && prog.numLoopRegs() == 0
        && !prog.hasGraphemeSemantics()
        && prog.numCaptures() <= OnePass.MAX_CAPTURE_GROUPS;
  }

  /**
   * Returns the lazily computed OnePass analysis results. The volatile fast path serves initialized
   * readers; the synchronized slow path prepares the analysis once under concurrent first use.
   */
  private OnePassAnalysis onePassAnalysis() {
    OnePassAnalysis analysis = onePassAnalysis;
    if (analysis == null) {
      synchronized (this) {
        analysis = onePassAnalysis;
        if (analysis == null) {
          if (!mayBuildOnePass()) {
            analysis = OnePassAnalysis.DISABLED;
          } else {
            OnePass op = OnePass.build(prog);
            // Primary matching requires the whole pattern to be non-nullable so unanchored / prefix
            // searches cannot prefer a consuming path over an empty match.
            boolean canPrimary = op != null && op.search("", false, 0) == null;
            boolean canFind = canPrimary && prog.anchorStart();
            boolean canSubmatch = op != null && numGroups() > 0;
            analysis = new OnePassAnalysis(op, canPrimary, canFind, canSubmatch);
          }
          onePassAnalysis = analysis;
        }
      }
    }
    return analysis;
  }

  /** Returns the one-pass automaton, or {@code null} if the pattern is not one-pass. */
  OnePass onePass() {
    return onePassAnalysis().onePass();
  }

  /**
   * Returns whether OnePass can be used as the primary matching engine, bypassing the DFA entirely.
   * This is true when the pattern is OnePass-eligible, non-nullable, and has no lazy quantifiers.
   * The non-nullable restriction prevents leftmost-first ambiguity bugs where a nullable
   * alternative (e.g., {@code a*} in {@code a*|c.}) would incorrectly lose to a longer alternative
   * under OnePass's longest-match semantics.
   */
  boolean canOnePassPrimary() {
    return onePassAnalysis().canPrimary();
  }

  /**
   * Returns whether OnePass can be used directly in {@code find()} for anchored patterns. This is
   * {@link #canOnePassPrimary()} restricted to patterns anchored at the start.
   */
  boolean canOnePassFind() {
    return prog.anchorStart() && onePassAnalysis().canFind();
  }

  /**
   * Returns whether {@link #canOnePassPrimary()} might be true. If OnePass has not been built, this
   * uses only properties known without building it, so that choosing a prepared runner does not
   * build OnePass; the runner checks {@link #canOnePassPrimary()} before using it.
   */
  private boolean mayOnePassPrimary() {
    OnePassAnalysis analysis = onePassAnalysis;
    if (analysis != null) {
      return analysis.canPrimary();
    }
    return mayBuildOnePass();
  }

  /**
   * Returns whether {@link #canOnePassSubmatch()} might be true without building {@link OnePass}.
   */
  private boolean mayOnePassSubmatch() {
    OnePassAnalysis analysis = onePassAnalysis;
    if (analysis != null) {
      return analysis.canSubmatch();
    }
    return mayBuildOnePass() && numGroups() > 0;
  }

  /** Returns whether the OnePass analysis has been computed. For tests. */
  boolean onePassAnalyzed() {
    return onePassAnalysis != null;
  }

  /**
   * Cheap conservative upper bound on {@code shiftDfa() != null}. Uses only properties known
   * without running {@link ShiftDfa#compile(Prog)} so that choosing a prepared runner does not
   * build {@link ShiftDfa}; {@link Matcher.LazyShiftDfaPreparedRunner} compiles {@link ShiftDfa}
   * lazily on the first {@code matches()} call.
   */
  private boolean mayUseShiftDfa() {
    ShiftDfaAnalysis analysis = shiftDfaAnalysis;
    if (analysis != null) {
      return analysis.shiftDfa() != null;
    }
    boolean literalSupersedesShiftDfa =
        canUseLiteralPreparedRunner(
                matchDescriptor.literalMatch(), prog.numCaptures(), enginePathOptions)
            && !matchDescriptor.literalFoldCase();
    return enginePathOptions.shiftDfa()
        && !literalSupersedesShiftDfa
        && prog.numCaptures() == 1
        && astAnalysis.minMatchLength() < ShiftDfa.MAX_STATES
        && !prog.hasGraphemeSemantics()
        && !prog.hasWordBoundary()
        && !prog.anchorEnd()
        && !prog.dollarAnchorEnd()
        && prog.start() != 0;
  }

  private ShiftDfaAnalysis shiftDfaAnalysis() {
    ShiftDfaAnalysis analysis = shiftDfaAnalysis;
    if (analysis == null) {
      synchronized (this) {
        analysis = shiftDfaAnalysis;
        if (analysis == null) {
          ShiftDfa compiled = mayUseShiftDfa() ? ShiftDfa.compile(prog) : null;
          analysis = compiled != null ? new ShiftDfaAnalysis(compiled) : ShiftDfaAnalysis.DISABLED;
          shiftDfaAnalysis = analysis;
        }
      }
    }
    return analysis;
  }

  ShiftDfa shiftDfa() {
    return shiftDfaAnalysis().shiftDfa();
  }

  /** Returns whether the ShiftDfa analysis has been computed. For tests. */
  boolean shiftDfaAnalyzed() {
    return shiftDfaAnalysis != null;
  }

  /**
   * Returns whether OnePass can be used for submatch extraction in the sandwich path. This is true
   * when the pattern has user capturing groups, satisfies {@link #mayBuildOnePass()}, and compiles
   * to a deterministic one-pass automaton. Whole-pattern nullability without nullable alternation
   * (e.g. {@code (a)*}) remains eligible because match bounds are already determined by the DFA.
   */
  boolean canOnePassSubmatch() {
    return onePassAnalysis().canSubmatch();
  }

  /**
   * Returns {@code true} when the DFA's leftmost-longest group(0) boundaries are guaranteed to
   * match RE2's leftmost-first semantics. The DFA uses POSIX leftmost-longest matching which can
   * disagree with Perl/RE2 leftmost-first semantics in three cases:
   *
   * <ol>
   *   <li>Lazy quantifiers: prefer shortest match, but the DFA gives longest.
   *   <li>Alternation: the DFA picks the longest branch, but RE2 picks the first matching branch.
   *   <li>Bounded repetitions ({@code a{3,4}}): nested inside quantifiers, the DFA may find a
   *       globally longer match by choosing fewer characters per iteration, while RE2 greedily
   *       maximizes each iteration.
   * </ol>
   *
   * <p>When this returns {@code false}, the DFA sandwich is skipped and the submatch engine
   * (BitState/NFA) determines the correct match boundaries.
   */
  boolean dfaGroupZeroReliable() {
    return prog.numLoopRegs() == 0;
  }

  /**
   * Returns true if this pattern can participate in reverse DFA matching (e.g. unanchored find or
   * end-anchored reverse-first rejection).
   */
  boolean canUseReverseDfa() {
    return !prog.anchorStart() && !matchDescriptor.hasFindFastPath();
  }

  /**
   * Returns whether to build OnePass in the constructor. OnePass is built eagerly when {@code
   * find()} can use it: directly for start-anchored patterns, and for capture extraction in {@code
   * group()} when the pattern has capturing groups. For other patterns only {@code matches()} and
   * {@code lookingAt()} can use it, so it is built on first use.
   */
  private boolean shouldEagerlyBuildOnePass() {
    return !matchDescriptor.hasFindFastPath()
        && ((prog.anchorStart() && mayOnePassPrimary()) || mayOnePassSubmatch());
  }

  /**
   * Returns the literal prefix for this pattern, or {@code null} if the pattern has no fixed
   * literal prefix. Used for prefix acceleration in {@link Matcher#doFind()}.
   */
  String prefix() {
    return prefix;
  }

  /** Returns whether the prefix should be matched case-insensitively. */
  boolean prefixFoldCase() {
    return prefixFoldCase;
  }

  /**
   * Returns a {@link CharClassScanInfo} of the character-class prefix, or {@code null} if the
   * pattern has no character-class prefix. Used for prefix acceleration in {@link Matcher#doFind()}
   * when no literal prefix exists.
   */
  CharClassScanInfo charClassPrefix() {
    return charClassPrefix;
  }

  String anchoredPrefix() {
    return anchoredPrefix;
  }

  byte[] anchoredPrefixUtf8() {
    return anchoredPrefixUtf8;
  }

  CharClassScanInfo anchoredCharClassPrefix() {
    return anchoredCharClassPrefix;
  }

  /** Returns the compiled UTF-8 start-position accelerator strategy, or {@code null}. */
  Utf8StartAccelerator utf8StartAccelerator() {
    return utf8StartAccelerator;
  }

  /** Returns the compiled String start-position accelerator strategy, or {@code null}. */
  StringStartAccelerator stringStartAccelerator() {
    return stringStartAccelerator;
  }

  MatchDescriptor matchDescriptor() {
    return matchDescriptor;
  }

  /** Returns case-insensitive keyword-alternation fast-path data, or {@code null}. */
  KeywordAlternation keywordAlternation() {
    return matchDescriptor.keywordAlternation();
  }

  /** Returns AST metadata for whole-input rejection. */
  MultiAnchorDescriptor.RejectPlan rejectPlan() {
    return multiAnchor.rejectPlan();
  }

  /** Returns AST metadata for start-position acceleration. */
  MultiAnchorDescriptor.StartPlan startPlan() {
    return multiAnchor.startPlan();
  }

  /** Returns whole-input rejection prefilter, or {@code null}. */
  RejectPrefilter rejectPrefilter() {
    return rejectPrefilter;
  }

  /** Applies bounded terminal rejection and records the rejecting diagnostic strategy. */
  boolean terminalPrefilterRejects(
      InputScanner scanner, int searchFrom, DiagnosticAccumulator diagnostics) {
    if (rejectPrefilter == null) {
      return false;
    }
    MatchStrategy rejection =
        rejectPrefilter.endAnchoredRejectionStrategy(scanner, searchFrom, enginePathOptions);
    if (rejection == null) {
      return false;
    }
    if (diagnostics != null) {
      diagnostics.participate(rejection, StrategyRole.REJECT_PREFILTER);
      diagnostics.boundary(rejection);
    }
    return true;
  }

  private boolean rejectsWithDiagnostics(
      RejectPrefilter filter,
      Utf8InputScanner scanner,
      int searchFrom,
      DiagnosticAccumulator diagnostics) {
    return reportRejection(
        filter.rejectionStrategy(null, scanner, searchFrom, enginePathOptions), diagnostics);
  }

  private boolean rejectsTailWithDiagnostics(
      RejectPrefilter filter,
      Utf8InputScanner scanner,
      int searchFrom,
      DiagnosticAccumulator diagnostics) {
    return reportRejection(
        filter.tailRejectionStrategy(null, scanner, searchFrom, enginePathOptions), diagnostics);
  }

  private static boolean reportRejection(
      MatchStrategy rejection, DiagnosticAccumulator diagnostics) {
    if (rejection == null) {
      return false;
    }
    diagnostics.participate(rejection, StrategyRole.REJECT_PREFILTER);
    diagnostics.boundary(rejection);
    return true;
  }

  /** Forward DFA narrowing checks the suffix after failure; avoid an eager duplicate scan. */
  RejectPrefilter findRejectPrefilter() {
    return innerLiteralSearch == null || !forwardDfaSupported ? rejectPrefilter : null;
  }

  /**
   * UTF-8 {@code find()} counterpart to {@link #findRejectPrefilter()}: also omits {@link
   * RejectPrefilter.DisjointLiterals} when UTF-8 start acceleration already covers the search.
   */
  RejectPrefilter utf8FindRejectPrefilter() {
    return utf8FindRejectPrefilter;
  }

  boolean startPrecedesFindReject() {
    return startPrecedesFindReject;
  }

  /** Returns whether find() skips the reject prefilter in favor of the start accelerator. */
  boolean startSubsumesFindReject() {
    return startSubsumesFindReject;
  }

  MultiAnchorDescriptor multiAnchor() {
    return multiAnchor;
  }

  /**
   * Returns the reverse-compiled program for backward DFA matching, compiling it on first access.
   *
   * <p>Like the other lazily built artifacts, the volatile fast path serves initialized readers and
   * the synchronized slow path builds the program once under concurrent first use.
   */
  Prog reverseProg() {
    Prog rp = reverseProg;
    if (rp == null) {
      synchronized (this) {
        rp = reverseProg;
        if (rp == null) {
          rp = Compiler.compile(ast, true);
          reverseProg = rp;
        }
      }
    }
    return rp;
  }

  Prog flatReverseProg() {
    Prog frp = flatReverseProg;
    if (frp == null) {
      synchronized (this) {
        frp = flatReverseProg;
        if (frp == null) {
          Prog rp = reverseProg();
          if (rp != null) {
            frp = rp.flattenedCopy();
            flatReverseProg = frp;
          }
        }
      }
    }
    return frp;
  }

  Prog flatReverseDfaProg() {
    Prog frp = flatReverseDfaProg;
    if (frp == null) {
      // Build once, so that reverseDfaSetup always describes the published flatReverseDfaProg.
      synchronized (this) {
        frp = flatReverseDfaProg;
        if (frp == null) {
          // Prepare once under the lock rather than retaining the tree after construction.
          Compiler.Prepared prepared = Compiler.prepare(ast);
          Prog rp = reverseProg;
          if (rp == null) {
            rp = Compiler.compile(prepared, true);
            reverseProg = rp;
          }
          if (rp != null) {
            if (rp.numLoopRegs() > 0) {
              Prog dfaRp = Compiler.compileForDfa(prepared, true);
              if (dfaRp != null) {
                frp = dfaRp.flattenedCopy();
              } else {
                frp = flatReverseProg();
              }
            } else {
              frp = flatReverseProg();
            }
            reverseDfaSetup = Dfa.buildSetup(frp);
            flatReverseDfaProg = frp;
          }
        }
      }
    }
    return frp;
  }

  Dfa.Setup forwardDfaSetup() {
    Dfa.Setup setup = forwardDfaSetup;
    if (setup == null) {
      synchronized (this) {
        setup = forwardDfaSetup;
        if (setup == null) {
          Prog flat = flatProg();
          setup = Dfa.buildSetup(flat != null ? flat : prog);
          forwardDfaSetup = setup;
        }
      }
    }
    return setup;
  }

  Dfa.Setup reverseDfaSetup() {
    flatReverseDfaProg(); // ensure flat reverse dfa prog and its setup are computed
    return reverseDfaSetup;
  }

  /**
   * Returns the full literal string for patterns that are entirely literal (no metacharacters), or
   * {@code null} if the pattern is not fully literal. For case-insensitive patterns, returns the
   * lowercase version.
   */
  String literalMatch() {
    return matchDescriptor.literalMatch();
  }

  boolean literalFoldCase() {
    return matchDescriptor.literalFoldCase();
  }

  byte[] literalMatchUtf8() {
    return literalMatchUtf8;
  }

  int[] literalMatchFailure() {
    return literalMatchFailure;
  }

  int[] literalMatchShifts() {
    return literalMatchShifts;
  }

  byte[] prefixUtf8() {
    return prefixUtf8;
  }

  /** Returns {@code true} if this pattern is a simple literal with no metacharacters. */
  boolean isLiteral() {
    return literalMatch() != null;
  }

  boolean startsWithGraphemeClusterBoundary() {
    return startsWithGraphemeClusterBoundary;
  }

  boolean hasInternalGraphemeClusterBoundary() {
    return hasInternalGraphemeClusterBoundary;
  }

  /** Returns the parsed AST. */
  Regexp ast() {
    return ast;
  }

  /**
   * Returns an unmodifiable map of named capturing groups to their 1-based group indices.
   *
   * <p>If the pattern has no named capturing groups, an empty map is returned.
   *
   * @return an unmodifiable map from group names to group numbers
   * @since 20
   */
  public Map<String, Integer> namedGroups() {
    return astAnalysis.namedGroups();
  }

  AstAnalysis astAnalysis() {
    return astAnalysis;
  }

  /**
   * Returns this compiled pattern's opaque, positive diagnostics identity.
   *
   * <p>This is the same value reported by {@link PatternDescriptor#patternId()} in diagnostics
   * events. It is assigned even when diagnostics are disabled and remains stable for this instance.
   * Reading it does not compute static analysis.
   *
   * <p>Identities are unique among patterns created by the same loaded {@code Pattern} class.
   * Separately compiling the same expression produces different identities. They are process-local,
   * not persistent identifiers; deserialization recompiles the pattern with a new identity.
   *
   * @return this pattern's diagnostics identity
   */
  public long patternId() {
    return patternId;
  }

  /**
   * Returns immutable static diagnostics for this pattern.
   *
   * <p>Capabilities describe strategies that can participate for at least one supported operation
   * and input; runtime input length, operation shape, and engine budgets can still affect
   * selection.
   */
  public PatternAnalysis analysis() {
    PatternAnalysis result = patternAnalysis;
    if (result == null) {
      synchronized (this) {
        result = patternAnalysis;
        if (result == null) {
          result = buildPatternAnalysis();
          patternAnalysis = result;
        }
      }
    }
    return result;
  }

  PatternDescriptor descriptor() {
    PatternDescriptor result = patternDescriptor;
    if (result == null) {
      synchronized (this) {
        result = patternDescriptor;
        if (result == null) {
          result = new PatternDescriptor(patternId, analysis());
          patternDescriptor = result;
        }
      }
    }
    return result;
  }

  private PatternAnalysis buildPatternAnalysis() {
    EnumSet<PatternFeature> features = EnumSet.noneOf(PatternFeature.class);
    EnumSet<PatternCapability> capabilities = EnumSet.noneOf(PatternCapability.class);
    EnumSet<PatternLimitation> limitations = EnumSet.noneOf(PatternLimitation.class);

    if (literalMatch() != null) {
      features.add(PatternFeature.LITERAL);
      capabilities.add(PatternCapability.LITERAL_MATCH);
    }
    if (literalAlternation != null) {
      capabilities.add(PatternCapability.LITERAL_MATCH);
    }
    if (prog.numCaptures() > 1) {
      features.add(PatternFeature.CAPTURES);
    }
    if (astAnalysis.hasAlt()) {
      features.add(PatternFeature.ALTERNATION);
    }
    if (astAnalysis.hasLazy()) {
      features.add(PatternFeature.LAZY_QUANTIFIER);
      limitations.add(PatternLimitation.LAZY_SEMANTICS_LIMIT_ONE_PASS);
    }
    if (astAnalysis.canMatchEmpty()) {
      features.add(PatternFeature.NULLABLE);
    }
    if (astAnalysis.hasNullableAlt()) {
      features.add(PatternFeature.NULLABLE_ALTERNATION);
      limitations.add(PatternLimitation.NULLABLE_ALTERNATION_LIMITS_ONE_PASS);
    }
    if (prog.anchorStart()) {
      features.add(PatternFeature.ANCHOR);
      features.add(PatternFeature.START_ANCHOR);
    }
    if (prog.anchorEnd()) {
      features.add(PatternFeature.ANCHOR);
      features.add(PatternFeature.END_ANCHOR);
    }
    if (prog.hasWordBoundary()) {
      features.add(PatternFeature.WORD_BOUNDARY);
    }
    if (prog.hasGraphemeSemantics()) {
      features.add(PatternFeature.GRAPHEME);
      limitations.add(PatternLimitation.GRAPHEME_REQUIRES_EXACT_ENGINE);
    }
    if ((flags & CASE_INSENSITIVE) != 0) {
      features.add(PatternFeature.CASE_INSENSITIVE);
    }
    if ((flags & UNICODE_CHARACTER_CLASS) != 0) {
      features.add(PatternFeature.UNICODE_CHARACTER_CLASS);
    }
    addAstAnalysisFeatures(features);

    if (matchDescriptor.charClassMatch() != null || matchDescriptor.singleCharClass() != null) {
      capabilities.add(PatternCapability.CHARACTER_CLASS_MATCH);
    }
    if (matchDescriptor.keywordAlternation() != null) {
      capabilities.add(PatternCapability.KEYWORD_MATCH);
    }
    if (canOnePassPrimary()) {
      capabilities.add(PatternCapability.ONE_PASS_PRIMARY);
    }
    if (canOnePassSubmatch()) {
      capabilities.add(PatternCapability.ONE_PASS_CAPTURE_EXTRACTION);
    }
    if (enginePathOptions.dfa() && !prog.hasGraphemeSemantics()) {
      capabilities.add(PatternCapability.DFA_BOUNDARY_SEARCH);
      if (prog.numLoopRegs() > 0) {
        capabilities.add(PatternCapability.DFA_REJECT_PREFILTER);
      }
    }
    int maxBitStateText = BitState.maxTextSize(prog);
    if (maxBitStateText >= 0) {
      capabilities.add(PatternCapability.BIT_STATE);
    } else {
      limitations.add(PatternLimitation.PROGRAM_TOO_LARGE_FOR_BIT_STATE);
    }
    capabilities.add(PatternCapability.NFA);

    if (prog.numLoopRegs() > 0) {
      features.add(PatternFeature.NESTED_NULLABLE_QUANTIFIER);
      features.add(PatternFeature.PROGRESS_CHECK);
      limitations.add(PatternLimitation.NULLABLE_LOOP_REQUIRES_EXACT_ENGINE);
    }
    if (features.contains(PatternFeature.CAPTURES)
        && (astAnalysis.hasAlt() || astAnalysis.hasLazy() || prog.numLoopRegs() > 0)) {
      limitations.add(PatternLimitation.CAPTURE_PRIORITY_REQUIRES_EXACT_ENGINE);
    }

    return new PatternAnalysis(
        features, capabilities, limitations, prog.size(), prog.numCaptures() - 1);
  }

  private record AstAnalysisNode(Regexp regexp, boolean insideQuantifier) {}

  private void addAstAnalysisFeatures(EnumSet<PatternFeature> features) {
    Deque<AstAnalysisNode> stack = new ArrayDeque<>();
    stack.push(new AstAnalysisNode(ast, false));
    while (!stack.isEmpty()) {
      AstAnalysisNode current = stack.pop();
      Regexp node = current.regexp();
      boolean quantifier =
          node.op == RegexpOp.STAR
              || node.op == RegexpOp.PLUS
              || node.op == RegexpOp.QUEST
              || node.op == RegexpOp.REPEAT;
      if (node.op == RegexpOp.REPEAT) {
        features.add(PatternFeature.BOUNDED_REPEAT);
      }
      switch (node.op) {
        case LITERAL, LITERAL_STRING -> features.add(PatternFeature.LITERAL);
        case BEGIN_LINE, BEGIN_TEXT -> {
          features.add(PatternFeature.ANCHOR);
          features.add(PatternFeature.START_ANCHOR);
        }
        case END_LINE, END_TEXT -> {
          features.add(PatternFeature.ANCHOR);
          features.add(PatternFeature.END_ANCHOR);
        }
        case WORD_BOUNDARY, NO_WORD_BOUNDARY -> features.add(PatternFeature.WORD_BOUNDARY);
        case GRAPHEME_CLUSTER, GRAPHEME_CLUSTER_BOUNDARY -> features.add(PatternFeature.GRAPHEME);
        default -> {}
      }
      if (node.op == RegexpOp.CAPTURE && node.cap > 0 && current.insideQuantifier()) {
        features.add(PatternFeature.CAPTURES_IN_QUANTIFIER);
      }
      if (node.subs != null) {
        for (Regexp sub : node.subs) {
          stack.push(new AstAnalysisNode(sub, current.insideQuantifier() || quantifier));
        }
      }
    }
  }

  /**
   * Returns the number of capturing groups in this pattern, not counting the implicit group 0 for
   * the full match.
   */
  int numGroups() {
    return prog.numCaptures() - 1;
  }

  // ---------------------------------------------------------------------------
  // Flag mapping
  // ---------------------------------------------------------------------------

  /** The set of all flag bits we support. */
  private static final int SUPPORTED_FLAGS =
      UNIX_LINES
          | CASE_INSENSITIVE
          | COMMENTS
          | MULTILINE
          | LITERAL
          | DOTALL
          | UNICODE_CASE
          | UNICODE_CHARACTER_CLASS;

  /** Validates that no unsupported flag bits are set. */
  private static void validateFlags(int flags) {
    int unsupported = flags & ~SUPPORTED_FLAGS;
    if (unsupported != 0) {
      throw new IllegalArgumentException(
          "Unsupported flags: 0x"
              + Integer.toHexString(unsupported)
              + ". CANON_EQ is not supported by SafeRE.");
    }
  }

  /** Returns JDK-compatible effective flags after applying implied flags. */
  private static int effectiveFlags(int flags) {
    if ((flags & UNICODE_CHARACTER_CLASS) != 0) {
      flags |= UNICODE_CASE;
    }
    return flags;
  }

  /**
   * Converts {@code java.util.regex.Pattern} flags to internal {@link ParseFlags}.
   *
   * <p>The baseline is {@link ParseFlags#LIKE_PERL}, which includes {@code ONE_LINE} (single-line
   * mode where {@code ^} and {@code $} match only at the start/end of the entire input).
   */
  static int toParseFlags(int flags) {
    // Start with LIKE_PERL as the baseline.
    int pf = ParseFlags.LIKE_PERL;

    if ((flags & CASE_INSENSITIVE) != 0) {
      pf |= ParseFlags.FOLD_CASE;
    }
    if ((flags & MULTILINE) != 0) {
      // Multiline mode: ^ and $ match at line boundaries.
      // Remove ONE_LINE so that ^ and $ are per-line.
      pf &= ~ParseFlags.ONE_LINE;
    }
    if ((flags & DOTALL) != 0) {
      pf |= ParseFlags.DOT_NL;
    }
    if ((flags & LITERAL) != 0) {
      pf |= ParseFlags.LITERAL;
    }
    if ((flags & COMMENTS) != 0) {
      pf |= ParseFlags.COMMENTS;
    }
    if ((flags & UNICODE_CASE) != 0) {
      pf |= ParseFlags.UNICODE_CASE;
    }
    if ((flags & UNICODE_CHARACTER_CLASS) != 0) {
      pf |= ParseFlags.UNICODE_GROUPS | ParseFlags.UNICODE_CHAR_CLASS;
    }
    if ((flags & UNIX_LINES) != 0) {
      pf |= ParseFlags.UNIX_LINES;
    }
    return pf;
  }

  // ---------------------------------------------------------------------------
  // Grapheme cluster boundary analysis
  // ---------------------------------------------------------------------------

  private static boolean startsWithGraphemeClusterBoundary(Regexp re) {
    Regexp first = firstMeaningfulNode(re);
    return first != null && first.op == RegexpOp.GRAPHEME_CLUSTER_BOUNDARY;
  }

  private static boolean hasInternalExplicitGraphemeBoundary(Regexp re) {
    return new GraphemeBoundaryContextWalker()
        .walk(re, GraphemeBoundaryContext.noMatch())
        .hasInternalExplicitBoundary();
  }

  private record GraphemeBoundaryContext(
      boolean canMatchEmpty,
      boolean canConsume,
      boolean startsWithExplicitBoundary,
      boolean endsWithExplicitBoundary,
      boolean hasInternalExplicitBoundary) {
    static GraphemeBoundaryContext noMatch() {
      return new GraphemeBoundaryContext(false, false, false, false, false);
    }

    static GraphemeBoundaryContext empty() {
      return new GraphemeBoundaryContext(true, false, false, false, false);
    }

    static GraphemeBoundaryContext consuming() {
      return new GraphemeBoundaryContext(false, true, false, false, false);
    }

    static GraphemeBoundaryContext explicitBoundary() {
      return new GraphemeBoundaryContext(true, false, true, true, false);
    }
  }

  private static final class GraphemeBoundaryContextWalker extends Walker<GraphemeBoundaryContext> {

    @Override
    protected GraphemeBoundaryContext shortVisit(Regexp re, GraphemeBoundaryContext parentArg) {
      return GraphemeBoundaryContext.noMatch();
    }

    @Override
    protected GraphemeBoundaryContext copy(GraphemeBoundaryContext arg) {
      return arg;
    }

    @Override
    protected GraphemeBoundaryContext postVisit(
        Regexp re,
        GraphemeBoundaryContext parentArg,
        GraphemeBoundaryContext preArg,
        List<GraphemeBoundaryContext> childArgs) {
      return switch (re.op) {
        case NO_MATCH -> GraphemeBoundaryContext.noMatch();
        case EMPTY_MATCH,
            BEGIN_LINE,
            END_LINE,
            BEGIN_TEXT,
            END_TEXT,
            WORD_BOUNDARY,
            NO_WORD_BOUNDARY,
            HAVE_MATCH ->
            GraphemeBoundaryContext.empty();
        case LITERAL, LITERAL_STRING, ANY_CHAR, ANY_BYTE, CHAR_CLASS, GRAPHEME_CLUSTER ->
            GraphemeBoundaryContext.consuming();
        case GRAPHEME_CLUSTER_BOUNDARY -> GraphemeBoundaryContext.explicitBoundary();
        case CONCAT -> concatBoundaryContext(childArgs);
        case ALTERNATE -> alternateBoundaryContext(childArgs);
        case STAR, QUEST -> optionalBoundaryContext(childArgs);
        case PLUS, NON_CAPTURE, CAPTURE -> childBoundaryContext(childArgs);
        case REPEAT -> repeatBoundaryContext(re, childArgs);
      };
    }

    private static GraphemeBoundaryContext concatBoundaryContext(
        List<GraphemeBoundaryContext> childArgs) {
      boolean canMatchEmpty = true;
      boolean canConsume = false;
      boolean startsWithExplicitBoundary = false;
      boolean canStillStartAtChild = true;
      boolean hasInternalExplicitBoundary = false;
      boolean hasConsumingPrefix = false;
      boolean[] consumingSuffix = new boolean[childArgs.size()];
      boolean hasConsumingSuffix = false;
      for (int i = childArgs.size() - 1; i >= 0; i--) {
        consumingSuffix[i] = hasConsumingSuffix;
        hasConsumingSuffix |= childArgs.get(i).canConsume();
      }
      for (int i = 0; i < childArgs.size(); i++) {
        GraphemeBoundaryContext child = childArgs.get(i);
        canMatchEmpty &= child.canMatchEmpty();
        canConsume |= child.canConsume();
        if (canStillStartAtChild && child.startsWithExplicitBoundary()) {
          startsWithExplicitBoundary = true;
        }
        canStillStartAtChild &= child.canMatchEmpty();
        hasInternalExplicitBoundary |= child.hasInternalExplicitBoundary();
        if ((child.startsWithExplicitBoundary() || child.endsWithExplicitBoundary())
            && hasConsumingPrefix
            && consumingSuffix[i]) {
          hasInternalExplicitBoundary = true;
        }
        hasConsumingPrefix |= child.canConsume();
      }

      boolean endsWithExplicitBoundary = false;
      boolean canStillEndAtChild = true;
      for (int i = childArgs.size() - 1; i >= 0; i--) {
        GraphemeBoundaryContext child = childArgs.get(i);
        if (canStillEndAtChild && child.endsWithExplicitBoundary()) {
          endsWithExplicitBoundary = true;
        }
        canStillEndAtChild &= child.canMatchEmpty();
      }
      return new GraphemeBoundaryContext(
          canMatchEmpty,
          canConsume,
          startsWithExplicitBoundary,
          endsWithExplicitBoundary,
          hasInternalExplicitBoundary);
    }

    private static GraphemeBoundaryContext alternateBoundaryContext(
        List<GraphemeBoundaryContext> childArgs) {
      boolean canMatchEmpty = childArgs.isEmpty();
      boolean canConsume = false;
      boolean startsWithExplicitBoundary = false;
      boolean endsWithExplicitBoundary = false;
      boolean hasInternalExplicitBoundary = false;
      for (GraphemeBoundaryContext child : childArgs) {
        canMatchEmpty |= child.canMatchEmpty();
        canConsume |= child.canConsume();
        startsWithExplicitBoundary |= child.startsWithExplicitBoundary();
        endsWithExplicitBoundary |= child.endsWithExplicitBoundary();
        hasInternalExplicitBoundary |= child.hasInternalExplicitBoundary();
      }
      return new GraphemeBoundaryContext(
          canMatchEmpty,
          canConsume,
          startsWithExplicitBoundary,
          endsWithExplicitBoundary,
          hasInternalExplicitBoundary);
    }

    private static GraphemeBoundaryContext optionalBoundaryContext(
        List<GraphemeBoundaryContext> childArgs) {
      GraphemeBoundaryContext child = childBoundaryContext(childArgs);
      return new GraphemeBoundaryContext(
          true,
          child.canConsume(),
          child.startsWithExplicitBoundary(),
          child.endsWithExplicitBoundary(),
          child.hasInternalExplicitBoundary());
    }

    private static GraphemeBoundaryContext repeatBoundaryContext(
        Regexp re, List<GraphemeBoundaryContext> childArgs) {
      GraphemeBoundaryContext child = childBoundaryContext(childArgs);
      boolean canMatchEmpty = re.min == 0 || child.canMatchEmpty();
      boolean canConsume = re.max != 0 && child.canConsume();
      return new GraphemeBoundaryContext(
          canMatchEmpty,
          canConsume,
          child.startsWithExplicitBoundary(),
          child.endsWithExplicitBoundary(),
          child.hasInternalExplicitBoundary());
    }

    private static GraphemeBoundaryContext childBoundaryContext(
        List<GraphemeBoundaryContext> childArgs) {
      return childArgs.isEmpty() ? GraphemeBoundaryContext.noMatch() : childArgs.getFirst();
    }
  }

  /**
   * Conservative start-position accelerator.
   *
   * <p>Every match must start at a multiline {@code ^} position, optionally with the first consumed
   * ASCII character in {@code asciiStart}. The accelerator only advances the initial search
   * position before handing off to the normal linear engine pipeline.
   */
  static final class StartAcceleration {
    final boolean requireLineStart;
    final boolean allowLineStart;
    final AsciiBitmap asciiStart;

    StartAcceleration(boolean requireLineStart, boolean allowLineStart, AsciiBitmap asciiStart) {
      this.requireLineStart = requireLineStart;
      this.allowLineStart = allowLineStart;
      this.asciiStart = asciiStart;
    }
  }

  static final class FixedOffsetLiteral {
    private final String literal;
    private final int minOffset;
    private final int maxOffset;
    private final int[] discreteOffsets;
    private final byte[] utf8;
    private final int[] failure;
    private final int[] shifts;

    FixedOffsetLiteral(String literal, int offset) {
      this(literal, offset, offset, new int[] {offset});
    }

    FixedOffsetLiteral(String literal, int minOffset, int maxOffset, int[] discreteOffsets) {
      this.literal = literal;
      this.minOffset = minOffset;
      this.maxOffset = maxOffset;
      this.discreteOffsets = discreteOffsets;
      this.utf8 = literal.getBytes(StandardCharsets.UTF_8);
      this.failure = literalFailure(utf8);
      this.shifts = literalShifts(utf8);
    }

    String literal() {
      return literal;
    }

    int offset() {
      return minOffset;
    }

    int minOffset() {
      return minOffset;
    }

    int maxOffset() {
      return maxOffset;
    }

    int[] discreteOffsets() {
      return discreteOffsets;
    }

    boolean isExactOffset() {
      return minOffset == maxOffset;
    }

    byte[] utf8() {
      return utf8;
    }

    int[] failure() {
      return failure;
    }

    int[] shifts() {
      return shifts;
    }
  }

  /** Fast-path data for {@code (?i)\b(keyword|...)\b} and its greedy whole-input form. */
  static final class KeywordAlternation {
    final String[] keywords;
    final AsciiBitmap firstAscii;
    final boolean[] firstAsciiTable;
    final int captureGroup;
    final boolean unicodeWordBoundary;
    final boolean greedyWholeInput;

    KeywordAlternation(
        String[] keywords,
        AsciiBitmap firstAscii,
        int captureGroup,
        boolean unicodeWordBoundary,
        boolean greedyWholeInput) {
      this.keywords = keywords;
      this.firstAscii = firstAscii;
      this.firstAsciiTable = firstAscii.toBooleanArray();
      this.captureGroup = captureGroup;
      this.unicodeWordBoundary = unicodeWordBoundary;
      this.greedyWholeInput = greedyWholeInput;
    }

    long find(InputScanner scanner, int startPos) {
      int matchStart = Math.max(0, startPos);
      if (greedyWholeInput) {
        for (int position = scanner.length() - 1; position >= matchStart; position--) {
          long match = matchAt(scanner, position);
          if (match >= 0) {
            return match;
          }
        }
        return -1;
      }
      int position = matchStart;
      while (position < scanner.length()) {
        long match = matchAt(scanner, position);
        if (match >= 0) {
          return match;
        }
        int ascii = scanner.asciiAt(position);
        position =
            ascii >= 0 ? position + 1 : InputScanner.position(scanner.decodeForward(position));
      }
      return -1;
    }

    long matchAt(InputScanner scanner, int position) {
      if (WorkCounterConfig.ENABLED) {
        WorkCounter.record();
      }
      int first = scanner.asciiAt(position);
      if (first < 0
          || !firstAsciiTable[Ascii.toLowerCase(first)]
          || !isWordBoundaryAt(scanner, position)) {
        return -1;
      }
      for (String keyword : keywords) {
        int end = position + keyword.length();
        if (end <= scanner.length()
            && matchesAsciiIgnoreCase(scanner, position, keyword)
            && isWordBoundaryAt(scanner, end)) {
          return ((long) position << 32) | (end & 0xFFFF_FFFFL);
        }
      }
      return -1;
    }

    private boolean isWordBoundaryAt(InputScanner scanner, int position) {
      boolean previousWord =
          position > 0
              && isBoundaryWordChar(scanner.codePointBefore(position), unicodeWordBoundary);
      boolean nextWord =
          position < scanner.length()
              && isBoundaryWordChar(scanner.codePointAt(position), unicodeWordBoundary);
      return previousWord != nextWord;
    }

    private static boolean matchesAsciiIgnoreCase(
        InputScanner scanner, int position, String keyword) {
      for (int index = 0; index < keyword.length(); index++) {
        int input = scanner.asciiAt(position + index);
        if (input < 0 || Ascii.toLowerCase(input) != keyword.charAt(index)) {
          return false;
        }
      }
      return true;
    }

    private static boolean isBoundaryWordChar(int codePoint, boolean unicodeWordBoundary) {
      return unicodeWordBoundary ? Nfa.isUnicodeWordChar(codePoint) : Nfa.isWordChar(codePoint);
    }

    static int matchStart(long match) {
      return (int) (match >>> 32);
    }

    static int matchEnd(long match) {
      return (int) match;
    }
  }

  private static KeywordAlternation extractKeywordAlternation(Regexp re, int patternFlags) {
    if ((patternFlags & UNICODE_CASE) != 0) {
      return null;
    }

    Regexp node = unwrapImplicitCapture(re);
    if (node == null || node.op != RegexpOp.CONCAT) {
      return null;
    }
    boolean greedyWholeInput = false;
    int coreOffset = 0;
    if (node.nsub() == 5
        && isGreedyAnyCharStar(node.subs.getFirst())
        && isGreedyAnyCharStar(node.subs.getLast())) {
      greedyWholeInput = true;
      coreOffset = 1;
    } else if (node.nsub() != 3) {
      return null;
    }
    Regexp before = unwrapImplicitCapture(node.subs.get(coreOffset));
    Regexp middle = unwrapImplicitCapture(node.subs.get(coreOffset + 1));
    Regexp after = unwrapImplicitCapture(node.subs.get(coreOffset + 2));
    if (before == null
        || before.op != RegexpOp.WORD_BOUNDARY
        || after == null
        || after.op != RegexpOp.WORD_BOUNDARY) {
      return null;
    }

    int captureGroup = -1;
    if (middle != null && middle.op == RegexpOp.CAPTURE && middle.cap > 0) {
      captureGroup = middle.cap;
      middle = unwrapImplicitCapture(middle.sub());
    }
    if (middle == null
        || middle.op != RegexpOp.ALTERNATE
        || middle.subs == null
        || middle.subs.isEmpty()) {
      return null;
    }
    if (hasOtherUserCaptures(middle, captureGroup)) {
      return null;
    }

    String[] keywords = new String[middle.subs.size()];
    AsciiBitmap.Builder firstAscii = new AsciiBitmap.Builder();
    for (int i = 0; i < middle.subs.size(); i++) {
      String keyword = extractAsciiCaseInsensitiveLiteral(middle.subs.get(i));
      if (keyword == null || keyword.isEmpty()) {
        return null;
      }
      keywords[i] = keyword;
      firstAscii.add(keyword.charAt(0));
    }

    boolean beforeUnicodeWordBoundary = (before.flags & ParseFlags.UNICODE_CHAR_CLASS) != 0;
    boolean afterUnicodeWordBoundary = (after.flags & ParseFlags.UNICODE_CHAR_CLASS) != 0;
    if (beforeUnicodeWordBoundary != afterUnicodeWordBoundary) {
      return null;
    }
    return new KeywordAlternation(
        keywords, firstAscii.build(), captureGroup, beforeUnicodeWordBoundary, greedyWholeInput);
  }

  private static boolean isGreedyAnyCharStar(Regexp re) {
    Regexp node = unwrapImplicitCapture(re);
    return node != null
        && node.op == RegexpOp.STAR
        && !node.nonGreedy()
        && node.sub().op == RegexpOp.ANY_CHAR;
  }

  private static boolean hasOtherUserCaptures(Regexp re, int allowedCapture) {
    Deque<Regexp> stack = new ArrayDeque<>();
    stack.push(re);
    while (!stack.isEmpty()) {
      Regexp node = stack.pop();
      if (node.op == RegexpOp.CAPTURE && node.cap > 0 && node.cap != allowedCapture) {
        return true;
      }
      if (node.subs != null) {
        for (Regexp sub : node.subs) {
          stack.push(sub);
        }
      }
    }
    return false;
  }

  private static Regexp unwrapImplicitCapture(Regexp re) {
    Regexp node = re;
    while (node != null && node.op == RegexpOp.CAPTURE && node.cap == 0) {
      node = node.sub();
    }
    return node;
  }

  private static String extractAsciiCaseInsensitiveLiteral(Regexp re) {
    Regexp node = unwrapImplicitCapture(re);
    if (node == null) {
      return null;
    }
    StringBuilder sb = new StringBuilder();
    if (!appendAsciiCaseInsensitiveLiteral(node, sb)) {
      return null;
    }
    return sb.toString();
  }

  private static boolean appendAsciiCaseInsensitiveLiteral(Regexp node, StringBuilder sb) {
    node = unwrapImplicitCapture(node);
    if (node == null) {
      return false;
    }
    return switch (node.op) {
      case CONCAT -> {
        if (node.subs == null || node.subs.isEmpty()) {
          yield false;
        }
        for (Regexp sub : node.subs) {
          if (!appendAsciiCaseInsensitiveLiteral(sub, sb)) {
            yield false;
          }
        }
        yield true;
      }
      case LITERAL -> {
        int cp = node.rune;
        if (cp < 0 || cp >= 128 || !isAsciiLiteralKeywordChar(cp)) {
          yield false;
        }
        if ((node.flags & ParseFlags.FOLD_CASE) == 0) {
          yield false;
        }
        sb.append((char) Ascii.toLowerCase(cp));
        yield true;
      }
      case LITERAL_STRING -> {
        if (node.runes == null || node.runes.length == 0) {
          yield false;
        }
        if ((node.flags & ParseFlags.FOLD_CASE) == 0) {
          yield false;
        }
        for (int cp : node.runes) {
          if (cp < 0 || cp >= 128 || !isAsciiLiteralKeywordChar(cp)) {
            yield false;
          }
          sb.append((char) Ascii.toLowerCase(cp));
        }
        yield true;
      }
      case CHAR_CLASS -> {
        int cp = asciiFoldedLiteralChar(node.charClass);
        if (cp < 0) {
          yield false;
        }
        sb.append((char) cp);
        yield true;
      }
      default -> false;
    };
  }

  private static boolean isAsciiLiteralKeywordChar(int cp) {
    return Ascii.isWordChar(cp);
  }

  private static int asciiFoldedLiteralChar(CharClass cc) {
    if (cc == null || cc.numRunes() != 2) {
      return -1;
    }
    for (int cp = 'a'; cp <= 'z'; cp++) {
      if (cc.contains(cp) && cc.contains(Ascii.toUpperCase(cp))) {
        return cp;
      }
    }
    return -1;
  }

  private static Regexp firstMeaningfulNode(Regexp re) {
    Regexp node = unwrapCaptures(re);
    if (node == null) {
      return null;
    }
    if (node.op == RegexpOp.CONCAT && node.nsub() > 0) {
      return unwrapCaptures(node.subs.get(0));
    }
    return node;
  }

  private static Regexp unwrapCaptures(Regexp re) {
    Regexp node = re;
    while (node != null && (node.op == RegexpOp.CAPTURE || node.op == RegexpOp.NON_CAPTURE)) {
      node = node.sub();
    }
    return node;
  }

  /** Holds precomputed data for the character-class-match fast path. */
  // TODO(#98): Replace int[] with Guava ImmutableIntArray to get proper value semantics.
  @SuppressWarnings("ArrayRecordComponent")
  record CharClassMatchInfo(int[] ranges, long bitmap0, long bitmap1, boolean allowEmpty) {}

  /**
   * Detects patterns that are structurally a single character class under a quantifier covering the
   * entire string — e.g., {@code [a-zA-Z]+}, {@code \d*}, {@code \w{1,}}, {@code [0-9]+}. When
   * detected, {@code matches()} can use a tight character-scanning loop with precomputed bitmaps
   * instead of the full engine cascade.
   *
   * <p>Sees through the implicit group-0 CAPTURE wrapper. Returns {@code null} if the pattern has
   * any user capture groups (the fast path only produces group 0).
   */
  private static CharClassMatchInfo extractCharClassMatch(Regexp re, boolean hasUserCaptures) {
    Regexp node = re;

    // Unwrap implicit group-0 capture.
    if (node.op == RegexpOp.CAPTURE && node.cap == 0) {
      node = node.sub();
    }

    // Must be a quantifier: PLUS (min=1), STAR (min=0), or REPEAT (min >= 0, max = -1).
    boolean allowEmpty;
    switch (node.op) {
      case PLUS -> allowEmpty = false;
      case STAR -> allowEmpty = true;
      case REPEAT -> {
        if (node.max != -1) {
          return null; // bounded repeat like {3,5} — not a "cover entire string" pattern
        }
        if (node.min > 1) {
          return null; // {2,} or higher — would need code point counting; not worth optimizing
        }
        allowEmpty = (node.min == 0);
      }
      default -> {
        return null;
      }
    }

    Regexp inner = node.sub();

    // Reject if the original pattern has user capture groups — the fast path only produces
    // group 0, so it can't provide group(1) etc.
    if (hasUserCaptures) {
      return null;
    }

    CharClass cc;
    if (inner.op == RegexpOp.CHAR_CLASS && inner.charClass != null) {
      cc = inner.charClass;
    } else if (inner.op == RegexpOp.LITERAL) {
      cc = literalCharClass(inner.rune, inner.flags);
    } else {
      return null;
    }
    if (cc.isEmpty()) {
      return null;
    }

    // Build flat ranges array and precompute ASCII bitmaps.
    int numRanges = cc.numRanges();
    int[] ranges = new int[numRanges * 2];
    long b0 = 0;
    long b1 = 0;
    for (int i = 0; i < numRanges; i++) {
      int lo = cc.lo(i);
      int hi = cc.hi(i);
      ranges[i * 2] = lo;
      ranges[i * 2 + 1] = hi;
      int start = Math.max(lo, 0);
      int end = Math.min(hi, 127);
      for (int cp = start; cp <= end; cp++) {
        if (cp < 64) {
          b0 |= 1L << cp;
        } else {
          b1 |= 1L << (cp - 64);
        }
      }
    }
    return new CharClassMatchInfo(ranges, b0, b1, allowEmpty);
  }

  /**
   * Detects patterns that are exactly one character class, such as {@code [a-z]} or {@code
   * \p{javaLetter}}. The fast path only produces group 0, so patterns with user capture groups are
   * excluded.
   */
  private static CharClassScanInfo extractSingleCharClass(Regexp re, boolean hasUserCaptures) {
    Regexp node = re;
    if (node.op == RegexpOp.CAPTURE && node.cap == 0) {
      node = node.sub();
    }
    if (node.op != RegexpOp.CHAR_CLASS || node.charClass == null || hasUserCaptures) {
      return null;
    }
    CharClass cc = node.charClass;
    if (cc.isEmpty()) {
      return null;
    }
    return CharClassScanInfo.fromCharClass(cc);
  }

  record SuffixInfo(String suffix, boolean wasDollar, boolean unixLines, boolean foldCase) {
    SuffixInfo(String suffix, boolean wasDollar) {
      this(suffix, wasDollar, false, false);
    }

    SuffixInfo(String suffix, boolean wasDollar, boolean unixLines) {
      this(suffix, wasDollar, unixLines, false);
    }
  }

  record EndAnchoredCharClassInfo(AsciiBitmap bitmap, boolean wasDollar, boolean unixLines) {
    EndAnchoredCharClassInfo(AsciiBitmap bitmap, boolean wasDollar) {
      this(bitmap, wasDollar, false);
    }
  }

  private static CharClass literalCharClass(int cp, int flags) {
    CharClassBuilder ccb = new CharClassBuilder();
    if ((flags & ParseFlags.FOLD_CASE) == 0) {
      ccb.addRange(cp, cp);
    } else if ((flags & ParseFlags.UNICODE_CASE) == 0) {
      UnicodeCaseFolding.addAsciiFoldedRange(ccb, cp, cp);
    } else {
      UnicodeCaseFolding.addUnicodeFoldedRange(ccb, cp, cp);
    }
    return ccb.build();
  }

  private record LiteralResult(String literal, boolean foldCase) {
    static final LiteralResult NONE = new LiteralResult(null, false);
  }

  /**
   * Extracts the full literal string if this pattern is entirely literal (no metacharacters, no
   * quantifiers, no alternation). Transparent groups (e.g. non-capturing groups) are unwrapped.
   *
   * <p>Returns {@link LiteralResult#NONE} if the pattern is not fully literal. For case-insensitive
   * patterns, returns the lowercase version and foldCase=true.
   */
  private static LiteralResult extractLiteralMatch(Regexp re) {
    Regexp node = re;

    // Unwrap outer CAPTURE (group 0).
    while (node != null && node.op == RegexpOp.CAPTURE) {
      node = node.sub();
    }
    if (node == null) {
      return LiteralResult.NONE;
    }

    boolean foldCase = false;
    boolean foldCaseInitialized = false;
    StringBuilder sb = new StringBuilder();

    switch (node.op) {
      case LITERAL -> {
        if (!Utils.isValidRune(node.rune)) {
          return LiteralResult.NONE;
        }
        foldCase = (node.flags & ParseFlags.FOLD_CASE) != 0;
        sb.appendCodePoint(node.rune);
      }
      case LITERAL_STRING -> {
        foldCase = (node.flags & ParseFlags.FOLD_CASE) != 0;
        if (node.runes != null) {
          for (int r : node.runes) {
            if (!Utils.isValidRune(r)) {
              return LiteralResult.NONE;
            }
            sb.appendCodePoint(r);
          }
        }
      }
      case CONCAT -> {
        for (Regexp child : node.subs) {
          // Each child must be LITERAL or LITERAL_STRING (not wrapped in CAPTURE etc.)
          Regexp c = child;
          while (c != null && (c.op == RegexpOp.CAPTURE || c.op == RegexpOp.NON_CAPTURE)) {
            c = c.sub();
          }
          if (c == null) {
            return LiteralResult.NONE;
          }
          if (c.op == RegexpOp.BEGIN_TEXT) {
            if (sb.length() > 0) {
              return LiteralResult.NONE;
            }
            continue;
          }
          boolean childFoldCase = (c.flags & ParseFlags.FOLD_CASE) != 0;
          switch (c.op) {
            case LITERAL -> {
              if (!Utils.isValidRune(c.rune)) {
                return LiteralResult.NONE;
              }
              if (Inst.simpleFold(c.rune) != c.rune) {
                if (!foldCaseInitialized) {
                  foldCase = childFoldCase;
                  foldCaseInitialized = true;
                } else if (childFoldCase != foldCase) {
                  return LiteralResult.NONE;
                }
              }
              sb.appendCodePoint(c.rune);
            }
            case LITERAL_STRING -> {
              if (c.runes == null) {
                return LiteralResult.NONE;
              }
              for (int r : c.runes) {
                if (!Utils.isValidRune(r)) {
                  return LiteralResult.NONE;
                }
                if (Inst.simpleFold(r) != r) {
                  if (!foldCaseInitialized) {
                    foldCase = childFoldCase;
                    foldCaseInitialized = true;
                  } else if (childFoldCase != foldCase) {
                    return LiteralResult.NONE;
                  }
                }
                sb.appendCodePoint(r);
              }
            }
            default -> {
              return LiteralResult.NONE;
            }
          }
        }
      }
      case EMPTY_MATCH -> {
        // Empty pattern matches empty string.
        return new LiteralResult("", false);
      }
      default -> {
        return LiteralResult.NONE;
      }
    }

    if (sb.isEmpty()) {
      return new LiteralResult("", false);
    }
    return new LiteralResult(
        foldCase ? sb.toString().toLowerCase(Locale.ROOT) : sb.toString(), foldCase);
  }

  /** Deserialization: recompile the pattern from the stored string and flags. */
  private Object readResolve() {
    return compile(pattern(), flags());
  }
}
