// This file is part of a Java port of RE2 (https://github.com/google/re2).
// Original RE2 code is Copyright (c) 2009 The RE2 Authors.
// Modifications and Java port Copyright (c) 2026 Eddie Aftandilian.
// Licensed under the BSD 3-Clause License (see LICENSE file).

package org.safere;

import java.util.Arrays;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Map;

/**
 * Lazy DFA execution engine. Builds DFA states on demand from the compiled NFA program using the
 * subset construction. Each DFA state represents a set of simultaneously active NFA states.
 *
 * <p>The DFA provides fast boolean matching and match-end detection. It cannot track submatch
 * (capture group) boundaries — that requires the NFA. The typical usage pattern is:
 *
 * <ol>
 *   <li>Use the forward DFA to quickly determine if a match exists and where it ends.
 *   <li>Use the NFA on the narrowed range to extract capture groups.
 * </ol>
 *
 * <p>This is a port of RE2's {@code dfa.cc}, adapted for Java's Unicode code point model:
 *
 * <ul>
 *   <li>Operates on Unicode code points (0–0x10FFFF), not bytes (0–255).
 *   <li>Uses code point equivalence classes (derived from CHAR_RANGE instructions) instead of a
 *       byte-level bytemap.
 *   <li>Single-threaded (no lock-free atomic transitions).
 * </ul>
 */
final class Dfa {

  /** Result of a DFA search. */
  record SearchResult(boolean matched, int pos, boolean ambiguous, boolean scanLimitReached) {
    SearchResult(boolean matched, int pos) {
      this(matched, pos, false, false);
    }

    SearchResult(boolean matched, int pos, boolean ambiguous) {
      this(matched, pos, ambiguous, false);
    }
  }

  /** Result of a multi-match DFA search. */
  // TODO(#98): Replace int[] with Guava ImmutableIntArray to get proper value semantics.
  @SuppressWarnings("ArrayRecordComponent")
  record ManyMatchResult(boolean matched, int[] matchIds) {}

  /** Flag bit: this state contains a MATCH instruction. */
  private static final int FLAG_MATCH = 1 << 14;

  /** Flag bit: last consumed character was a word character (for {@code \b}/\B}). */
  private static final int FLAG_LAST_WORD = 1 << 15;

  /**
   * Flag bit: match was triggered by a word-boundary assertion BEFORE consuming the transition
   * character. The match position should be recorded at the current position, not after the
   * character.
   */
  private static final int FLAG_MATCH_BEFORE = 1 << 16;

  /**
   * Flag bit: when {@link #FLAG_MATCH_BEFORE} is set, indicates that an after-consume match ALSO
   * exists (from character transitions reaching MATCH). The search loop should try the
   * before-consume match first (earlier position) and fall back to the after-consume match if the
   * before-consume match is rejected (e.g., by {@code needEndMatch} requiring end-of-text).
   */
  private static final int FLAG_MATCH_AFTER_DEFERRED = 1 << 17;

  /**
   * Flag bit: last consumed character was a Unicode word character (for Unicode {@code \b}/\B}).
   */
  private static final int FLAG_LAST_UNICODE_WORD = 1 << 18;

  /** Previous scan character was CR forward or LF backward, for atomic CRLF assertions. */
  private static final int FLAG_CRLF_CONTEXT = 1 << 19;

  /**
   * Flag bit, reversed programs only: a deferred assertion also reached MATCH before the transition
   * character, but a higher-priority branch consuming that character reaches MATCH too, so {@link
   * #FLAG_MATCH_BEFORE} is not set. A longest reverse search prefers the after-consume match (an
   * earlier start). In the final iteration at {@code startLimit}, though, the consumed character
   * lies left of {@code startLimit} and only supplies assertion context, so the search must record
   * the before-consume match at {@code startLimit} instead.
   */
  private static final int FLAG_MATCH_BEFORE_SHADOWED = 1 << 20;

  /** Maximum number of DFA states before bailing out to NFA. */
  private static final int DEFAULT_MAX_STATES = 10_000;

  /**
   * Input positions of progress per cached state that this DFA must have covered before the state
   * cache may be discarded again.
   *
   * <p>RE2 has the same guard and supplies the cost model: recomputing a DFA state on every input
   * byte runs at roughly 0.2 MB/s where the NFA runs at roughly 2 MB/s, so ten input positions per
   * state computation is where a DFA that is rebuilding its cache stops accelerating anything.
   *
   * <p>Measurement on {@code [A-Za-z]{10}\s+[\s\S]{0,100}Result[\s\S]{0,100}\s+[A-Za-z]{10}} puts
   * SafeRE's break-even in the same place. Over 7.4 MB of source text the DFA sustains 22 to 64
   * positions per state computation and beats the NFA by 3.0x, and over a 1 MB haystack that holds
   * it to one position per state, discarding and rebuilding is 2.0x slower than the NFA.
   */
  private static final int MIN_PROGRESS_PER_CACHED_STATE = 10;

  // ---------------------------------------------------------------------------
  // State representation
  // ---------------------------------------------------------------------------

  /**
   * A DFA state: a set of NFA instruction IDs (the "frontier" of consuming/accepting instructions)
   * plus position-dependent flags. States are cached and shared across transitions to avoid
   * recomputation.
   */
  static final class State {
    final int id;
    final int[] insts; // sorted NFA instruction IDs (CHAR_RANGE, EMPTY_WIDTH, and MATCH only)
    final int flags;
    final boolean isHighestPriorityMatch;
    final StateAccelerator accelerator;
    // Only forward unanchored starts may use start-position acceleration.
    boolean isStartState;

    /**
     * Match IDs from word-boundary expansion (for PatternSet multi-match). Null if not applicable.
     */
    final int[] wordBoundaryMatchIds;

    /** Transitions indexed by equivalence class; null entry = not yet computed. */
    final State[] next;

    State(
        int id,
        int[] insts,
        int flags,
        int[] wordBoundaryMatchIds,
        int numClasses,
        boolean isHighestPriorityMatch,
        StateAccelerator accelerator) {
      this.id = id;
      this.insts = insts;
      this.flags = flags;
      this.wordBoundaryMatchIds = wordBoundaryMatchIds;
      this.isHighestPriorityMatch = isHighestPriorityMatch;
      this.accelerator = accelerator;
      this.next = new State[numClasses];
    }

    boolean isMatch() {
      return (flags & FLAG_MATCH) != 0;
    }
  }

  /** Cache key for state deduplication. */
  private static final class StateKey {
    private int[] insts;
    private int flags;

    StateKey() {}

    StateKey(int[] insts, int flags) {
      this.insts = insts;
      this.flags = flags;
    }

    void reset(int[] insts, int flags) {
      this.insts = insts;
      this.flags = flags;
    }

    StateKey copy() {
      return new StateKey(insts, flags);
    }

    @Override
    public int hashCode() {
      return Arrays.hashCode(insts) * 31 + flags;
    }

    @Override
    public boolean equals(Object o) {
      return (o instanceof StateKey other)
          && flags == other.flags
          && Arrays.equals(insts, other.insts);
    }
  }

  // ---------------------------------------------------------------------------
  // Instance fields
  // ---------------------------------------------------------------------------

  private final Prog prog;
  private final int maxStates;
  private final boolean longest;
  private final boolean hasGraphemeSemantics;

  /** Whether consuming transitions can depend on the absolute input position. */
  private final boolean hasPositionDependentTransitions;

  private final int stateEmptyFlagsMask;
  private final int startCacheEmptyFlagsMask;
  private final int anchoredCacheBit;
  private final int reverseCacheBit;
  private final int crLfCacheBit;
  private final boolean hasCrLfContext;

  /** Sorted code point boundaries defining equivalence classes. */
  private final int[] boundaries;

  /**
   * Total transition classes, including any Unicode word split and a separate end-of-text class.
   */
  private final int numClasses;

  /** Whether each interval is split by Unicode word-character membership. */
  private final boolean splitUnicodeWordClasses;

  /**
   * Fast ASCII-to-class lookup table. For code points 0–127, {@code asciiClassMap[cp]} gives the
   * equivalence class index directly, avoiding binary search. -1 means "not populated" (should not
   * happen for valid ASCII).
   */
  private final int[] asciiClassMap;

  /** Cache for mapping code points >= 128 to their equivalence class. */
  private final int[] cacheCps = new int[256];

  private final int[] cacheClasses = new int[256];

  /** State cache: maps instruction-set + flags to canonical State instance. */
  private final Map<StateKey, State> cache = new HashMap<>();

  /** Pre-allocated mutable key to perform allocation-free cache lookups. */
  private final StateKey lookupKey = new StateKey();

  /** Sentinel dead state: no instructions, no transitions possible. */
  private final State deadState;

  /** Pre-allocated visited generation array for {@link #expand}, reused across calls. */
  private final int[] expandVisitedGen;

  private int expandGeneration;

  /**
   * Pre-allocated stack array for {@link #expand}. Sized to the program length (worst case: every
   * instruction pushed once).
   */
  private final int[] expandStack;

  /**
   * Pre-allocated frontier array for {@link #expand}. Sized to the program length (worst case:
   * every instruction is a frontier instruction).
   */
  private final int[] expandFrontier;

  /** Pre-allocated workspace for seed/successor collection in computeNext(). */
  private final int[] computeBuf;

  /**
   * Bounded direct-mapped start cache. Every hit checks the complete context key; collisions only
   * evict an optimization and never merge semantic contexts. Its allocation is independent of the
   * number or bit positions of assertion flags.
   */
  private final State[] startStateByContext = new State[256];

  private final int[] startStateContextKeys = new int[256];

  /**
   * Start states for programs whose start context is fully described by direction, anchoring and
   * the word-character class of the adjacent characters: no text anchors, no CRLF context and no
   * grapheme semantics. Indexed by {@link #fastStartIndex}; cleared with the other start caches.
   */
  private final State[] fastStartStates;

  /** Shared empty instruction array to avoid repeated zero-length allocations. */
  private static final int[] EMPTY_INSTS = new int[0];

  /** Per-search grapheme context. Set only while a search method is active. */
  private GraphemeSupport.Context graphemeContext;

  /**
   * Input positions this DFA has covered since the state cache was last emptied.
   *
   * <p>A cache generation that covers at least {@link #MIN_PROGRESS_PER_CACHED_STATE} positions per
   * state before filling the budget has paid for the cost of building those states, and may discard
   * the cache immediately when it fills. Spans covered by the caller's NFA fallback after a DFA
   * bailout and input before a search's starting position are excluded so NFA or unvisited input is
   * never mistaken for DFA cache productivity. Each search records the position it actually reached
   * on exit, including no-match, reverse, and multi-pattern searches.
   */
  private long dfaStepsSinceReset;

  /**
   * Input positions this DFA covered, plus a bounded credit for each NFA fallback, since the state
   * cache was last emptied. This waits out the exponential backoff after an unproductive generation
   * without counting unscanned gaps between searches.
   */
  private long backoffProgress;

  /** Position from which the active search (or post-bailout span) is measured. */
  private int progressAnchor;

  /** Whether a search has established {@link #progressAnchor}. */
  private boolean hasProgressAnchor;

  /**
   * Whether the most recent search on this DFA returned null because the state budget was
   * exhausted. Every null search result sets this; see {@link #lastSearchBailed()}.
   */
  private boolean lastSearchBailed;

  /**
   * Start-acceleration backoff state (see {@link AdaptiveBackoff}) at the end of the most recent
   * forward search. Written once per search, never read inside a search; see {@link
   * #startBackoff()}.
   */
  private long lastStartBackoff;

  // Per-search narrowing state. Kept out of the scalar loop's live local variables; this DFA
  // is thread-confined and no search calls another search before it returns.
  private static final int INNER_PROBE_DISABLED = 0;
  private static final int INNER_PROBE_WAITING = 1;
  private static final int INNER_PROBE_READY = 2;
  private static final int INNER_PROBE_USED = 3;

  private int innerProbeState;
  private long innerProbeResumePos;

  // Notifications removed after a probe are rearmed at the next unanchored search. A slot is
  // queued only when its negative notification is visited, so maintenance is charged to DFA work.
  private int[] pausedFailureTransitions = EMPTY_INSTS;
  private int pausedFailureTransitionCount;
  private int pendingFailureTransitionIndex = -1;

  /**
   * Whether the current cache generation has already been penalized for exhausting its state budget
   * before covering {@link #MIN_PROGRESS_PER_CACHED_STATE} positions per state, so repeated hits on
   * the same full cache do not increment {@link #unproductiveResets} more than once per generation.
   */
  private boolean currentGenerationPenalized;

  /**
   * Consecutive cache generations that filled the state budget without covering {@link
   * #MIN_PROGRESS_PER_CACHED_STATE} positions per state. Each such generation doubles the input
   * span required before the next cache reset is permitted ({@code (10 << unproductiveResets) *
   * cache.size()}), bounding total rebuild work on adversarial inputs to a geometric series while
   * allowing long-lived {@code ThreadLocal<Dfa>} instances to recover on later inputs.
   */
  private int unproductiveResets;

  private static final int MAX_RESET_BACKOFF_SHIFT = 20;

  private int[] transitions;
  private State[] offsetToState;
  private boolean[] isAcceleratedStateOffset;
  private boolean hasStateAccelerators;
  private int nextStateId;

  private final Utf8StartAccelerator utf8StartAccelerator;
  private final StringStartAccelerator stringStartAccelerator;
  private final InnerLiteralSearch innerLiteralSearch;
  private final boolean hasStartAcceleration;

  // ---------------------------------------------------------------------------
  // Construction
  // ---------------------------------------------------------------------------

  /**
   * Pre-computed immutable DFA setup: equivalence class boundaries and ASCII lookup table. These
   * are derived solely from the compiled {@link Prog} and can be shared across all DFA instances
   * for the same program (e.g., across multiple {@link org.safere.Matcher} instances).
   */
  // TODO(#98): Replace int[] with Guava ImmutableIntArray to get proper value semantics.
  @SuppressWarnings("ArrayRecordComponent")
  record Setup(
      int[] boundaries, int numClasses, int[] asciiClassMap, boolean splitUnicodeWordClasses) {}

  /**
   * Builds a reusable {@link Setup} from a compiled program. The result is immutable and can be
   * stored on a {@link org.safere.Pattern} for sharing across matchers.
   */
  static Setup buildSetup(Prog prog) {
    int[] boundaries = buildBoundaries(prog);
    boolean splitUnicodeWordClasses = false;
    for (int i = 0; i < prog.size(); i++) {
      Inst inst = prog.inst(i);
      if (inst.opCode == InstOp.OP_EMPTY_WIDTH
          && (inst.arg & (EmptyOp.UNICODE_WORD_BOUNDARY | EmptyOp.UNICODE_NON_WORD_BOUNDARY))
              != 0) {
        splitUnicodeWordClasses = true;
        break;
      }
    }
    // Unicode word membership is a separate discriminator, avoiding a transition column for
    // every Unicode word range. Each original interval needs at most two columns, and EOF
    // retains its own column. Classification must agree with computeNext's word predicate.
    int numClasses = (boundaries.length + 1) * (splitUnicodeWordClasses ? 2 : 1) + 1;
    int[] asciiClassMap = buildAsciiClassMap(boundaries);
    if (splitUnicodeWordClasses) {
      for (int cp = 0; cp < asciiClassMap.length; cp++) {
        asciiClassMap[cp] = asciiClassMap[cp] * 2 + (Nfa.isWordChar(cp) ? 1 : 0);
      }
    }
    return new Setup(boundaries, numClasses, asciiClassMap, splitUnicodeWordClasses);
  }

  Dfa(Prog prog, int maxStates, Setup setup, boolean longest) {
    this(prog, maxStates, setup, longest, null, null);
  }

  Dfa(
      Prog prog,
      int maxStates,
      Setup setup,
      boolean longest,
      Utf8StartAccelerator utf8StartAccelerator,
      StringStartAccelerator stringStartAccelerator) {
    this(prog, maxStates, setup, longest, utf8StartAccelerator, stringStartAccelerator, null);
  }

  Dfa(
      Prog prog,
      int maxStates,
      Setup setup,
      boolean longest,
      Utf8StartAccelerator utf8StartAccelerator,
      StringStartAccelerator stringStartAccelerator,
      InnerLiteralSearch innerLiteralSearch) {
    this.prog = prog;
    this.maxStates = maxStates;
    this.longest = longest;
    this.utf8StartAccelerator = utf8StartAccelerator;
    this.stringStartAccelerator = stringStartAccelerator;
    this.innerLiteralSearch = innerLiteralSearch;
    this.hasStartAcceleration = utf8StartAccelerator != null || stringStartAccelerator != null;
    this.hasGraphemeSemantics = prog.hasGraphemeSemantics();
    this.hasCrLfContext = hasStandardLineBoundary(prog);
    this.fastStartStates =
        !hasGraphemeSemantics && !prog.hasTextAnchor() && !hasCrLfContext
            ? new State[prog.hasWordBoundary() ? 64 : 4]
            : null;
    this.hasPositionDependentTransitions = hasGraphemeSemantics || prog.hasTextAnchor();
    this.stateEmptyFlagsMask =
        hasGraphemeSemantics
            ? EmptyOp.ALL_FLAGS
            : EmptyOp.ALL_FLAGS & ~EmptyOp.GRAPHEME_CLUSTER_BOUNDARY;
    this.startCacheEmptyFlagsMask =
        hasGraphemeSemantics
            ? EmptyOp.ALL_FLAGS
            : EmptyOp.ALL_FLAGS
                & ~(EmptyOp.GRAPHEME_CLUSTER_BOUNDARY | EmptyOp.EXPLICIT_GRAPHEME_CLUSTER_BOUNDARY);
    this.reverseCacheBit = (startCacheEmptyFlagsMask + 1) << 2;
    this.anchoredCacheBit = reverseCacheBit << 1;
    this.crLfCacheBit = hasCrLfContext ? anchoredCacheBit << 1 : 0;
    this.boundaries = setup.boundaries;
    this.numClasses = setup.numClasses;
    this.splitUnicodeWordClasses = setup.splitUnicodeWordClasses;
    this.asciiClassMap = setup.asciiClassMap;
    Arrays.fill(this.cacheCps, -1);
    this.expandVisitedGen = new int[prog.size()];
    this.expandStack = new int[prog.size()];
    this.expandFrontier = new int[prog.size()];
    this.computeBuf = new int[prog.size()];
    this.deadState = new State(0, EMPTY_INSTS, 0, null, numClasses, false, null);
    this.nextStateId = 1;
    this.transitions = new int[1024];
    this.offsetToState = new State[1024];
    this.isAcceleratedStateOffset = new boolean[1024];
    addStateToFlatArrays(deadState);
  }

  private void addStateToFlatArrays(State s) {
    int minTransLen = (s.id + 1) * numClasses;
    if (minTransLen > transitions.length) {
      int newLen = Math.max(transitions.length * 2, minTransLen);
      transitions = Arrays.copyOf(transitions, newLen);
      offsetToState = Arrays.copyOf(offsetToState, newLen);
      isAcceleratedStateOffset = Arrays.copyOf(isAcceleratedStateOffset, newLen);
    }
    offsetToState[s.id * numClasses] = s;
    isAcceleratedStateOffset[s.id * numClasses] = s.isStartState || s.accelerator != null;
    if (s.accelerator != null) {
      hasStateAccelerators = true;
    }
  }

  private void setTransition(int fromId, int cls, int toId) {
    int fromBase = fromId * numClasses;
    State toState = offsetToState[toId * numClasses];
    // Negative entries already leave the hot loop for match handling. On DFAs with inner
    // narrowing, also flag failure frontiers so observing failure adds no per-character test.
    boolean needsAttention =
        toState.isMatch() || (innerLiteralSearch != null && toState.isStartState);
    int storedId = toId * numClasses;
    if (needsAttention) {
      storedId = -storedId;
    }
    transitions[fromBase + cls] = storedId;
  }

  private void pauseFailureTransition(int index, int offset) {
    if (pausedFailureTransitionCount == pausedFailureTransitions.length) {
      pausedFailureTransitions =
          Arrays.copyOf(pausedFailureTransitions, Math.max(8, pausedFailureTransitionCount * 2));
    }
    pausedFailureTransitions[pausedFailureTransitionCount++] = index;
    // This positive entry cannot be queued again before it is restored.
    transitions[index] = offset;
    if (WorkCounterConfig.ENABLED) {
      WorkCounter.record();
    }
  }

  private void restoreFailureTransitions() {
    for (int i = 0; i < pausedFailureTransitionCount; i++) {
      int index = pausedFailureTransitions[i];
      transitions[index] = -transitions[index];
      if (WorkCounterConfig.ENABLED) {
        WorkCounter.record();
      }
    }
    pausedFailureTransitionCount = 0;
  }

  private void addTransition(State from, int cls, State to) {
    from.next[cls] = to;
    setTransition(from.id, cls, to.id);
  }

  /**
   * Collects all code point range boundaries from the program's CHAR_RANGE instructions. The
   * boundaries define equivalence classes: code points within the same interval between consecutive
   * boundaries have identical consuming-instruction behavior. Unicode word-boundary programs
   * additionally split these intervals by word membership in {@link #buildSetup}.
   *
   * <p>When the program contains word-boundary assertions ({@code \b} or {@code \B}), additional
   * boundaries are added at the edges of the word-character ranges ({@code [A-Za-z0-9_]}) so that
   * no equivalence class straddles the ASCII word/non-word boundary. This is necessary because the
   * DFA caches transitions per (state, class) and the word-boundary computation depends on whether
   * the current character is a word character.
   */
  private static int[] buildBoundaries(Prog prog) {
    IntArrayList bounds = new IntArrayList();
    bounds.add(0);
    bounds.add(Utils.MAX_RUNE + 1);
    boolean hasWordBoundary = false;
    boolean hasLineBoundary = false;
    for (int i = 0; i < prog.size(); i++) {
      Inst inst = prog.inst(i);
      if (inst.opCode == InstOp.OP_CHAR_RANGE) {
        addRangeBoundaries(bounds, inst.lo, inst.hi);
        if (inst.foldCase) {
          addCaseFoldBoundaries(bounds, inst.lo, inst.hi);
        }
      } else if (inst.opCode == InstOp.OP_CHAR_CLASS) {
        for (int j = 0; j < inst.ranges.length; j += 2) {
          bounds.add(inst.ranges[j]);
          if (inst.ranges[j + 1] < Utils.MAX_RUNE) {
            bounds.add(inst.ranges[j + 1] + 1);
          }
        }
      } else if (inst.opCode == InstOp.OP_EMPTY_WIDTH) {
        if ((inst.arg & (EmptyOp.WORD_BOUNDARY | EmptyOp.NON_WORD_BOUNDARY)) != 0) {
          hasWordBoundary = true;
        }
        if ((inst.arg & (EmptyOp.UNICODE_WORD_BOUNDARY | EmptyOp.UNICODE_NON_WORD_BOUNDARY)) != 0) {
          hasWordBoundary = true;
        }
        if ((inst.arg
                & (EmptyOp.BEGIN_LINE
                    | EmptyOp.END_LINE
                    | EmptyOp.UNIX_BEGIN_LINE
                    | EmptyOp.UNIX_END_LINE))
            != 0) {
          hasLineBoundary = true;
        }
      }
    }
    if (hasLineBoundary) {
      // Line terminator characters trigger BEGIN_LINE (at the position after them) and
      // END_LINE (at their position). Give each its own equivalence class so the DFA can
      // cache different transitions for line terminators vs other characters.
      bounds.add(0x0A); // '\n'
      bounds.add(0x0B); // '\n' + 1
      bounds.add(0x0D); // '\r'
      bounds.add(0x0E); // '\r' + 1
      // Additional JDK line terminators: \u0085, \u2028, \u2029
      bounds.add(0x0085); // NEXT LINE
      bounds.add(0x0086); // NEXT LINE + 1
      bounds.add(0x2028); // LINE SEPARATOR
      bounds.add(0x202A); // PARAGRAPH SEPARATOR + 1 (covers both \u2028 and \u2029)
    }
    if (hasWordBoundary) {
      // Add boundaries at the edges of word-character ranges [0-9A-Za-z_].
      bounds.add(0x30); // '0'
      bounds.add(0x3A); // '9' + 1
      bounds.add(0x41); // 'A'
      bounds.add(0x5B); // 'Z' + 1
      bounds.add(0x5F); // '_'
      bounds.add(0x60); // '_' + 1
      bounds.add(0x61); // 'a'
      bounds.add(0x7B); // 'z' + 1
    }
    return bounds.toSortedUniqueArray();
  }

  private static boolean hasStandardLineBoundary(Prog prog) {
    for (int i = 0; i < prog.size(); i++) {
      Inst inst = prog.inst(i);
      if (inst.opCode == InstOp.OP_EMPTY_WIDTH
          && (inst.arg & (EmptyOp.BEGIN_LINE | EmptyOp.END_LINE)) != 0) {
        return true;
      }
    }
    return false;
  }

  /** Adds boundaries for a [lo, hi] code point range. */
  private static void addRangeBoundaries(IntArrayList bounds, int lo, int hi) {
    bounds.add(lo);
    if (hi < Utils.MAX_RUNE) {
      bounds.add(hi + 1);
    }
  }

  /**
   * Adds boundaries for all case-fold equivalents of each code point in [lo, hi]. When a CHAR_RANGE
   * instruction has the fold-case flag, characters outside [lo, hi] that fold into the range must
   * have their own equivalence classes so the DFA doesn't conflate them with non-matching
   * characters in the same class.
   */
  private static void addCaseFoldBoundaries(IntArrayList bounds, int lo, int hi) {
    for (int cp = lo; cp <= hi; cp++) {
      int folded = Inst.simpleFold(cp);
      while (folded != cp) {
        addRangeBoundaries(bounds, folded, folded);
        folded = Inst.simpleFold(folded);
      }
    }
  }

  /**
   * Builds a 128-element lookup table mapping ASCII code points (0–127) to their equivalence class
   * indices. This avoids binary search for the most common characters.
   */
  private static int[] buildAsciiClassMap(int[] boundaries) {
    int[] map = new int[128];
    for (int cp = 0; cp < 128; cp++) {
      int idx = Arrays.binarySearch(boundaries, cp);
      map[cp] = (idx >= 0) ? idx : (-idx - 1) - 1;
    }
    return map;
  }

  /** Maps a code point (or -1 for end-of-text) to its equivalence class index. */
  private int classOf(int cp) {
    if (cp < 0) {
      return numClasses - 1;
    }
    if (cp < 128) {
      return asciiClassMap[cp];
    }
    int cacheIdx = cp & 255;
    if (cacheCps[cacheIdx] == cp) {
      return cacheClasses[cacheIdx];
    }
    int idx = Arrays.binarySearch(boundaries, cp);
    int cls = (idx >= 0) ? idx : (-idx - 1) - 1;
    if (splitUnicodeWordClasses) {
      cls = cls * 2 + (Nfa.isUnicodeWordChar(cp) ? 1 : 0);
    }
    cacheCps[cacheIdx] = cp;
    cacheClasses[cacheIdx] = cls;
    return cls;
  }

  // ---------------------------------------------------------------------------
  // Subset construction
  // ---------------------------------------------------------------------------

  /**
   * Starting from a set of instruction IDs, follows all empty transitions (ALT, NOP, CAPTURE,
   * EMPTY_WIDTH) and returns the sorted frontier of CHAR_RANGE, MATCH, and unsatisfied EMPTY_WIDTH
   * instruction IDs.
   *
   * <p>Unsatisfied EMPTY_WIDTH instructions are retained in the frontier so they can be re-checked
   * when context changes (e.g., at end-of-text, the EndText flag becomes true and {@code $} can
   * fire).
   */
  private int[] expand(int[] seeds, int seedCount, int emptyFlags) {
    int gen = ++expandGeneration;
    int[] visitedGen = expandVisitedGen;
    int[] stack = expandStack;
    int[] frontier = expandFrontier;
    int stackTop = 0;
    int frontierSize = 0;

    // Push seeds onto stack in reverse priority order.
    for (int i = seedCount - 1; i >= 0; i--) {
      stack[stackTop++] = seeds[i];
    }

    boolean flat = prog.didFlatten();

    while (stackTop > 0) {
      int id = stack[--stackTop];
      if (id == 0 || id >= prog.size() || visitedGen[id] == gen) {
        continue;
      }
      visitedGen[id] = gen;

      Inst ip = prog.inst(id);

      if (flat) {
        // Flat program list iteration
        if (!ip.last) {
          stack[stackTop++] = id + 1;
        }

        switch (ip.opCode) {
          case InstOp.OP_FAIL -> {}
          case InstOp.OP_ALT, InstOp.OP_ALT_MATCH -> {
            // AltMatch and ALT only transition to id + 1 (already pushed above)
          }
          case InstOp.OP_NOP, InstOp.OP_CAPTURE, InstOp.OP_LOOP_ENTER -> {
            stack[stackTop++] = ip.out;
          }
          case InstOp.OP_PROGRESS_CHECK -> {
            stack[stackTop++] = ip.out1;
            stack[stackTop++] = ip.out;
          }
          case InstOp.OP_EMPTY_WIDTH -> {
            if ((ip.arg & ~emptyFlags) == 0) {
              stack[stackTop++] = ip.out;
            } else {
              frontier[frontierSize++] = id;
            }
          }
          case InstOp.OP_CHAR_RANGE, InstOp.OP_CHAR_CLASS -> frontier[frontierSize++] = id;
          case InstOp.OP_MATCH -> {
            frontier[frontierSize++] = id;
            if (!longest && !prog.anchorEnd()) {
              stackTop = 0;
            }
          }
          default -> {}
        }
      } else {
        // Standard unflattened program traversal
        switch (ip.opCode) {
          case InstOp.OP_FAIL -> {}
          case InstOp.OP_ALT, InstOp.OP_ALT_MATCH -> {
            stack[stackTop++] = ip.out1;
            stack[stackTop++] = ip.out;
          }
          case InstOp.OP_NOP, InstOp.OP_CAPTURE, InstOp.OP_LOOP_ENTER -> {
            stack[stackTop++] = ip.out;
          }
          case InstOp.OP_PROGRESS_CHECK -> {
            stack[stackTop++] = ip.out1;
            stack[stackTop++] = ip.out;
          }
          case InstOp.OP_EMPTY_WIDTH -> {
            if ((ip.arg & ~emptyFlags) == 0) {
              stack[stackTop++] = ip.out;
            } else {
              frontier[frontierSize++] = id;
            }
          }
          case InstOp.OP_CHAR_RANGE, InstOp.OP_CHAR_CLASS -> frontier[frontierSize++] = id;
          case InstOp.OP_MATCH -> {
            frontier[frontierSize++] = id;
            if (!longest && !prog.anchorEnd()) {
              stackTop = 0;
            }
          }
          default -> {}
        }
      }
    }

    if (longest) {
      sortSmall(frontier, frontierSize);
    }
    return Arrays.copyOf(frontier, frontierSize);
  }

  /** Sorts DFA frontiers, keeping insertion sort only for genuinely small arrays. */
  private static void sortSmall(int[] a, int len) {
    if (len > 32) {
      Arrays.sort(a, 0, len);
      return;
    }
    for (int i = 1; i < len; i++) {
      int key = a[i];
      int j = i - 1;
      while (j >= 0 && a[j] > key) {
        a[j + 1] = a[j];
        j--;
      }
      a[j + 1] = key;
    }
  }

  /** Returns true if any instruction ID in the sorted array is a MATCH instruction. */
  private boolean hasMatch(int[] insts) {
    for (int id : insts) {
      if (prog.inst(id).opCode == InstOp.OP_MATCH) {
        return true;
      }
    }
    return false;
  }

  /** Returns a new array with all MATCH instructions removed from the input array. */
  private int[] stripMatch(int[] insts) {
    int count = 0;
    for (int id : insts) {
      if (prog.inst(id).opCode != InstOp.OP_MATCH) {
        count++;
      }
    }
    if (count == insts.length) {
      return insts;
    }
    int[] result = new int[count];
    int idx = 0;
    for (int id : insts) {
      if (prog.inst(id).opCode != InstOp.OP_MATCH) {
        result[idx++] = id;
      }
    }
    return result;
  }

  /** Performs a stable deduplication of the input array, preserving insertion order. */
  private int[] stableDedup(int[] insts, int count) {
    int uniqueCount = 0;
    int gen = ++expandGeneration;
    int[] visitedGen = expandVisitedGen;
    for (int i = 0; i < count; i++) {
      int id = insts[i];
      if (visitedGen[id] != gen) {
        visitedGen[id] = gen;
        uniqueCount++;
      }
    }
    if (uniqueCount == count) {
      int[] result = new int[count];
      System.arraycopy(insts, 0, result, 0, count);
      return result;
    }
    int[] result = new int[uniqueCount];
    gen = ++expandGeneration;
    int idx = 0;
    for (int i = 0; i < count; i++) {
      int id = insts[i];
      if (visitedGen[id] != gen) {
        visitedGen[id] = gen;
        result[idx++] = id;
      }
    }
    return result;
  }

  /** Collects all match IDs (MATCH instruction arg values) from a DFA state's NFA instructions. */
  private int[] collectMatchIds(int[] insts) {
    int count = 0;
    for (int id : insts) {
      if (prog.inst(id).opCode == InstOp.OP_MATCH) {
        count++;
      }
    }
    if (count == 0) {
      return new int[0];
    }
    int[] ids = new int[count];
    int idx = 0;
    for (int id : insts) {
      Inst ip = prog.inst(id);
      if (ip.opCode == InstOp.OP_MATCH) {
        ids[idx++] = ip.arg;
      }
    }
    return ids;
  }

  /** Gets or creates a cached state. Returns null if the state budget is exceeded. */
  private State getOrCreate(int[] insts, int flags) {
    return getOrCreate(insts, flags, null);
  }

  /**
   * Gets or creates a cached state with optional word-boundary match IDs. Returns null if the state
   * budget is exceeded.
   */
  private State getOrCreate(int[] insts, int flags, int[] wordBoundaryMatchIds) {
    if (insts.length == 0 && (flags & FLAG_MATCH) == 0) {
      return deadState;
    }
    lookupKey.reset(insts, flags);
    State s = cache.get(lookupKey);
    if (s != null) {
      return s;
    }
    if (cache.size() >= maxStates) {
      return null;
    }
    boolean isHighestPriorityMatch =
        insts.length > 0 && prog.inst(insts[0]).opCode == InstOp.OP_MATCH;
    StateAccelerator accelerator = analyzeStateAcceleration(insts, flags, isHighestPriorityMatch);
    s =
        new State(
            nextStateId++,
            insts,
            flags,
            wordBoundaryMatchIds,
            numClasses,
            isHighestPriorityMatch,
            accelerator);
    addStateToFlatArrays(s);
    cache.put(lookupKey.copy(), s);
    return s;
  }

  /** Anchors the next scan without crediting input that the DFA has not actually visited. */
  private void beginSearch(int anchorPos) {
    if (hasProgressAnchor && lastSearchBailed) {
      // The caller may have used the NFA after a bailout, but its exact work is unknown here.
      // Give each fallback one bounded retry credit, never the possibly unscanned gap to the
      // next search position (which may even belong to a different input).
      backoffProgress += 64;
      lastSearchBailed = false;
    }
    progressAnchor = anchorPos;
    hasProgressAnchor = true;
  }

  /** Credits only the span reached while the current DFA search was active. */
  private void recordSearchProgress(int pos) {
    long span = Math.abs((long) pos - progressAnchor);
    dfaStepsSinceReset += span;
    backoffProgress += span;
    progressAnchor = pos;
  }

  /** Records the visited span before returning from any DFA search. */
  private <T> T completeSearch(T result, int pos) {
    recordSearchProgress(pos);
    return result;
  }

  /** Completes a forward search, publishing its final start-acceleration backoff state. */
  private SearchResult completeForwardSearch(SearchResult result, int pos, long startBackoff) {
    lastStartBackoff = startBackoff;
    return completeSearch(result, pos);
  }

  /**
   * Creates a search entry state, retrying after a permitted cache reset when the budget is full.
   */
  private State startStateOrReset(InputScanner text, int pos, boolean anchored, boolean reverse) {
    State s = startState(text, pos, anchored, reverse);
    if (s != null) {
      return s;
    }
    if (!resetCache(pos)) {
      return null;
    }
    s = startState(text, pos, anchored, reverse);
    return s == null ? budgetExhaustedAfterReset() : s;
  }

  /**
   * Discards every cached state, freeing the whole state budget for the rest of the search.
   *
   * <p>Returns false if the current cache generation did not cover {@link
   * #MIN_PROGRESS_PER_CACHED_STATE} DFA positions per state before filling the budget and the
   * exponential backoff window ({@code (10 << unproductiveResets) * cache.size()}) has not yet
   * elapsed. The caller must then abandon the DFA for the active search and let the NFA finish it.
   *
   * <p>A reset invalidates every {@link State} the caller holds. State ids restart from zero and
   * the flat arrays indexed by {@code state.id * numClasses} are rebuilt from scratch, so any
   * {@code State} reference, state offset, or local copy of the flat arrays held across the call is
   * stale.
   */
  private boolean resetCache(int pos) {
    long delta = Math.abs((long) pos - progressAnchor);
    dfaStepsSinceReset += delta;
    backoffProgress += delta;
    progressAnchor = pos;

    long baseThreshold = (long) MIN_PROGRESS_PER_CACHED_STATE * cache.size();
    if (dfaStepsSinceReset >= baseThreshold) {
      unproductiveResets = 0;
    } else {
      int shifts =
          currentGenerationPenalized
              ? unproductiveResets
              : Math.min(unproductiveResets + 1, MAX_RESET_BACKOFF_SHIFT);
      unproductiveResets = shifts;
      if (backoffProgress < (baseThreshold << shifts)) {
        currentGenerationPenalized = true;
        lastSearchBailed = true;
        return false;
      }
    }

    dfaStepsSinceReset = 0;
    backoffProgress = 0;
    lastSearchBailed = false;
    currentGenerationPenalized = false;
    int used = Math.min(nextStateId * numClasses, transitions.length);
    Arrays.fill(transitions, 0, used, 0);
    pausedFailureTransitionCount = 0;
    pendingFailureTransitionIndex = -1;
    Arrays.fill(offsetToState, 0, used, null);
    Arrays.fill(isAcceleratedStateOffset, 0, used, false);
    // The dead state outlives the reset, so clear the transitions recorded on it by hand.
    Arrays.fill(deadState.next, null);
    // A surviving start-cache entry would hand back a state the flat arrays no longer describe.
    Arrays.fill(startStateByContext, null);
    if (fastStartStates != null) {
      Arrays.fill(fastStartStates, null);
    }
    cache.clear();
    hasStateAccelerators = false;
    nextStateId = 1;
    addStateToFlatArrays(deadState);
    return true;
  }

  /**
   * Records that a freshly reset cache still could not hold the states the search needs, and
   * returns null so the caller abandons the DFA. This only happens with budgets of a few states; it
   * is still budget exhaustion, so it must set {@link #lastSearchBailed} like a refused reset.
   */
  private State budgetExhaustedAfterReset() {
    lastSearchBailed = true;
    return null;
  }

  /**
   * Returns whether the most recent search on this DFA returned null because the state budget was
   * exhausted: the cache was full and {@link #resetCache} refused to clear it, or the freshly
   * cleared cache still could not hold the states the search needed.
   *
   * <p>Every null result from {@link #doSearch}, {@link #doSearchReverse}, and {@link
   * #doSearchMany} sets this, which is what lets callers report a null result as {@link
   * StrategyReason#DFA_BUDGET_EXCEEDED}. A new way for a search to return null for any other reason
   * must not set it, and needs its own {@link StrategyReason}.
   */
  boolean lastSearchBailed() {
    return lastSearchBailed;
  }

  /**
   * Re-creates {@code s} in a freshly reset cache. The result is a distinct object with a different
   * id, so callers must adopt it in place of {@code s}.
   */
  private State recreateAfterReset(State s) {
    State recreated = getOrCreate(s.insts, s.flags, s.wordBoundaryMatchIds);
    if (recreated != null && s.isStartState) {
      recreated.isStartState = true;
      isAcceleratedStateOffset[recreated.id * numClasses] = true;
    }
    return recreated;
  }

  /**
   * Computes the transition out of {@code s} on {@code cp}, resetting the state cache and retrying
   * once if the state budget is exhausted. The transition is not recorded on {@code s}, for callers
   * whose destination position makes it unsafe to cache.
   *
   * <p>Returns null if the DFA must give up and let the NFA finish the search. Otherwise callers
   * must replace {@code s} with the returned state and must not reuse anything else derived from
   * it; see {@link #resetCache}.
   */
  private State computeNextOrReset(State s, int cp, InputScanner text, int nextPos, int pos) {
    State ns = computeNext(s, cp, text, nextPos);
    if (ns != null) {
      return ns;
    }
    if (!resetCache(pos)) {
      return null;
    }
    State recreated = recreateAfterReset(s);
    State next = recreated == null ? null : computeNext(recreated, cp, text, nextPos);
    return next == null ? budgetExhaustedAfterReset() : next;
  }

  /**
   * As {@link #computeNextOrReset}, additionally recording the transition under {@code cls} so
   * later visits take it straight from the cache. The transition is recorded on whichever state is
   * live after a reset, not on the now-discarded {@code s}.
   */
  private State transitionOrReset(
      State s, int cls, int cp, InputScanner text, int nextPos, int pos) {
    State ns = computeNext(s, cp, text, nextPos);
    if (ns == null) {
      if (!resetCache(pos)) {
        return null;
      }
      s = recreateAfterReset(s);
      if (s == null) {
        return budgetExhaustedAfterReset();
      }
      ns = computeNext(s, cp, text, nextPos);
      if (ns == null) {
        return budgetExhaustedAfterReset();
      }
    }
    addTransition(s, cls, ns);
    return ns;
  }

  private StateAccelerator analyzeStateAcceleration(
      int[] insts, int flags, boolean isHighestPriorityMatch) {
    if (isHighestPriorityMatch || insts.length == 0 || (flags & FLAG_MATCH) != 0) {
      return null;
    }
    for (int id : insts) {
      Inst ip = prog.inst(id);
      if (ip.opCode == InstOp.OP_EMPTY_WIDTH || ip.opCode == InstOp.OP_MATCH) {
        return null;
      }
    }

    int escapeCount = 0;
    int[] escapes = new int[3];
    int[] seeds = new int[insts.length];

    for (int ch = 0; ch < 128; ch++) {
      int seedCount = 0;
      for (int id : insts) {
        Inst ip = prog.inst(id);
        if (instMatches(ip, ch)) {
          seeds[seedCount++] = ip.out;
        }
      }
      if (seedCount == 0 || !Arrays.equals(expand(seeds, seedCount, 0), insts)) {
        if (escapeCount < 3) {
          escapes[escapeCount] = ch;
        }
        escapeCount++;
        if (escapeCount > 3) {
          return null;
        }
      }
    }

    // The scanner skips directly to an ASCII escape and therefore also skips over non-ASCII code
    // points. Prove that every non-ASCII equivalence class remains in this state before enabling
    // the accelerator. The DFA boundaries make one representative per interval sufficient.
    for (int i = 0; i + 1 < boundaries.length; i++) {
      int ch = Math.max(128, boundaries[i]);
      if (ch >= boundaries[i + 1]) {
        continue;
      }
      int seedCount = 0;
      for (int id : insts) {
        Inst ip = prog.inst(id);
        if (instMatches(ip, ch)) {
          seeds[seedCount++] = ip.out;
        }
      }
      if (seedCount == 0 || !Arrays.equals(expand(seeds, seedCount, 0), insts)) {
        return null;
      }
    }

    return switch (escapeCount) {
      case 1 -> new StateAccelerator.SingleAsciiEscape(escapes[0]);
      case 2 -> new StateAccelerator.AsciiPairEscape(escapes[0], escapes[1]);
      case 3 -> new StateAccelerator.AsciiTripleEscape(escapes[0], escapes[1], escapes[2]);
      default -> null;
    };
  }

  /** Returns whether this DFA was constructed with start-position acceleration enabled. */
  boolean hasStartAcceleration() {
    return hasStartAcceleration;
  }

  /** Returns whether this DFA can accelerate start positions for the supplied input substrate. */
  boolean hasStartAcceleration(InputScanner text) {
    return startAccelerationPolicy(text, null) != null;
  }

  private AcceleratorPolicy startAccelerationPolicy(InputScanner text, State startState) {
    AcceleratorPolicy policy =
        switch (text) {
          case Utf8InputScanner unusedUtf8 ->
              utf8StartAccelerator != null ? utf8StartAccelerator.policy() : null;
          case StringInputScanner unusedString ->
              stringStartAccelerator != null ? stringStartAccelerator.policy() : null;
          case StringRegionInputScanner unusedRegion ->
              stringStartAccelerator != null ? stringStartAccelerator.policy() : null;
        };
    if (policy != null) {
      return policy;
    }
    if (startState != null && startState.accelerator != null) {
      return startState.accelerator.policy();
    }
    return null;
  }

  private static boolean instMatches(Inst ip, int ch) {
    if (ip.opCode == InstOp.OP_CHAR_RANGE || ip.opCode == InstOp.OP_ALT_MATCH) {
      return ip.matchesChar(ch);
    }
    if (ip.opCode == InstOp.OP_CHAR_CLASS) {
      return ip.matchesCharClass(ch);
    }
    return false;
  }

  /**
   * Computes the start state for the given position context.
   *
   * <p>For unanchored searches, uses {@code prog.startUnanchored()} which enters the {@code .*?}
   * prefix loop that the compiler generates. This keeps all start positions alive within the DFA
   * state without needing to restart at each position (unlike the NFA).
   */
  State startState(InputScanner text, int pos, boolean anchored) {
    return startState(text, pos, anchored, false);
  }

  private int emptyFlags(InputScanner text, int pos) {
    if (!hasGraphemeSemantics && !prog.hasWordBoundary() && !prog.hasTextAnchor()) {
      return 0;
    }
    int flags =
        Nfa.emptyFlags(
            text,
            pos,
            hasGraphemeSemantics,
            graphemeContext,
            prog.hasWordBoundary(),
            prog.hasTextAnchor());
    if (prog.reversed()) {
      int rev =
          flags
              & ~(EmptyOp.BEGIN_TEXT
                  | EmptyOp.END_TEXT
                  | EmptyOp.BEGIN_LINE
                  | EmptyOp.END_LINE
                  | EmptyOp.UNIX_BEGIN_LINE
                  | EmptyOp.UNIX_END_LINE);
      if ((flags & EmptyOp.BEGIN_TEXT) != 0) {
        rev |= EmptyOp.END_TEXT;
      }
      if ((flags & EmptyOp.END_TEXT) != 0) {
        rev |= EmptyOp.BEGIN_TEXT;
      }
      if ((flags & EmptyOp.BEGIN_LINE) != 0) {
        rev |= EmptyOp.END_LINE;
      }
      if ((flags & EmptyOp.END_LINE) != 0) {
        rev |= EmptyOp.BEGIN_LINE;
      }
      if ((flags & EmptyOp.UNIX_BEGIN_LINE) != 0) {
        rev |= EmptyOp.UNIX_END_LINE;
      }
      if ((flags & EmptyOp.UNIX_END_LINE) != 0) {
        rev |= EmptyOp.UNIX_BEGIN_LINE;
      }
      flags = rev;
    }
    return flags;
  }

  /**
   * Computes the start state with an explicit "last word" override for reverse searches.
   *
   * @param reverseContext if true, FLAG_LAST_WORD is set based on the character AT pos (the char to
   *     the right of where a reverse scan begins), rather than the character BEFORE pos
   */
  State startState(InputScanner text, int pos, boolean anchored, boolean reverseContext) {
    if (fastStartStates == null) {
      return computeStartState(text, pos, anchored, reverseContext);
    }
    int index = fastStartIndex(text, pos, anchored, reverseContext);
    State s = fastStartStates[index];
    if (s == null) {
      s = computeStartState(text, pos, anchored, reverseContext);
      fastStartStates[index] = s;
    }
    return s;
  }

  /**
   * Without text anchors, CRLF context or grapheme semantics, a start state depends only on its
   * direction and anchoring and, for {@code \b} programs, on whether the characters on either side
   * of {@code pos} are ASCII and Unicode word characters (see {@link Nfa#emptyFlags}).
   */
  private int fastStartIndex(InputScanner text, int pos, boolean anchored, boolean reverseContext) {
    int index = (anchored ? 1 : 0) | (reverseContext ? 2 : 0);
    if (fastStartStates.length == 4) {
      return index;
    }
    if (pos > 0) {
      int cp = text.codePointBefore(pos);
      boolean word = Nfa.isWordChar(cp);
      index |= (word ? 4 : 0) | ((cp < 128 ? word : Nfa.isUnicodeWordChar(cp)) ? 8 : 0);
    }
    if (pos < text.length()) {
      int cp = text.codePointAt(pos);
      boolean word = Nfa.isWordChar(cp);
      index |= (word ? 16 : 0) | ((cp < 128 ? word : Nfa.isUnicodeWordChar(cp)) ? 32 : 0);
    }
    return index;
  }

  private State computeStartState(
      InputScanner text, int pos, boolean anchored, boolean reverseContext) {
    int startInst = anchored ? prog.start() : prog.startUnanchored();
    if (startInst == 0) {
      return deadState;
    }
    int emptyFlags = emptyFlags(text, pos);

    // Determine word-character context for \b/\B support.
    boolean lastWord = false;
    boolean lastUnicodeWord = false;
    if (prog.hasWordBoundary()) {
      if (reverseContext) {
        if (pos < text.length()) {
          int cp = text.codePointAt(pos);
          lastWord = Nfa.isWordChar(cp);
          lastUnicodeWord = cp < 128 ? lastWord : Nfa.isUnicodeWordChar(cp);
        }
      } else {
        if (pos > 0) {
          int cp = text.codePointBefore(pos);
          lastWord = Nfa.isWordChar(cp);
          lastUnicodeWord = cp < 128 ? lastWord : Nfa.isUnicodeWordChar(cp);
        }
      }
    }

    boolean crLfContext =
        hasCrLfContext
            && (prog.reversed()
                ? pos < text.length() && text.asciiAt(pos) == '\n'
                : pos > 0 && text.asciiAt(pos - 1) == '\r');

    // Include the adjacent scan character: deferred line assertions distinguish CRLF from
    // standalone CR/LF even when the frontier and all empty-width flags are identical.
    int cacheKey =
        (anchored ? anchoredCacheBit : 0)
            | (reverseContext ? reverseCacheBit : 0)
            | (crLfContext ? crLfCacheBit : 0)
            | ((emptyFlags & startCacheEmptyFlagsMask) << 2)
            | (lastWord ? 2 : 0)
            | (lastUnicodeWord ? 1 : 0);
    // Mix high assertion/context bits into the index instead of indexing the full key space.
    int cacheIndex = (cacheKey * 0x9E3779B9) >>> 24;
    State cached = startStateByContext[cacheIndex];
    if (cached != null && startStateContextKeys[cacheIndex] == cacheKey) {
      return cached;
    }

    computeBuf[0] = startInst;
    int[] insts = expand(computeBuf, 1, emptyFlags);
    int flags = emptyFlags & stateEmptyFlagsMask;
    if (hasMatch(insts)) {
      flags |= FLAG_MATCH;
    }
    if (lastWord) {
      flags |= FLAG_LAST_WORD;
    }
    if (lastUnicodeWord) {
      flags |= FLAG_LAST_UNICODE_WORD;
    }
    if (crLfContext) {
      flags |= FLAG_CRLF_CONTEXT;
    }
    State s = getOrCreate(insts, flags);
    if (s != null) {
      // An anchored start can also be an in-progress unanchored frontier. Marking it as
      // idle would allow start acceleration to skip characters belonging to that match.
      if (!anchored && !reverseContext) {
        s.isStartState = true;
        isAcceleratedStateOffset[s.id * numClasses] = true;
      }
      startStateContextKeys[cacheIndex] = cacheKey;
      startStateByContext[cacheIndex] = s;
    }
    return s;
  }

  /**
   * Returns the lowest position at which text-length-dependent emptyFlags (END_TEXT or DOLLAR_END)
   * are active. Transitions whose destination is at or beyond this threshold must bypass the {@code
   * State.next[]} cache, because the cache is keyed by (state, character-class) which is
   * position-independent, but END_TEXT/DOLLAR_END depend on the absolute position relative to
   * {@code text.length()}.
   *
   * <ul>
   *   <li>END_TEXT is set at {@code pos == text.length()}.
   *   <li>DOLLAR_END is set at {@code pos == text.length()} and also before the trailing line
   *       terminator at end of text. For {@code \r\n} this can be up to 2 characters back.
   * </ul>
   *
   * <p>For most of the text, transitions are cached normally. Only the last 1–3 character
   * transitions (near end-of-text) bypass the cache. The end-of-text sentinel ({@code cp < 0}) is
   * always safe to cache because it always represents "at text end".
   */
  private int positionDependentThreshold(InputScanner text) {
    if (!hasPositionDependentTransitions) {
      // Without position-dependent assertions, trailing line endings cannot affect cached steps.
      // The reverse ASCII fast path can also include those trailing line endings.
      return text.length();
    }
    if (hasGraphemeSemantics) {
      return 0;
    }
    // BEGIN_TEXT is represented by the start state, and BEGIN_LINE is normally derived from the
    // consumed character. The only position-dependent transitions are therefore near text end:
    // END_TEXT/DOLLAR_END, plus the exception that a final line terminator must not create a
    // BEGIN_LINE assertion past the end of the input.
    // Either scoped mode may occur in an instruction, even if the stripped anchor uses LF only.
    int trailing = text.trailingLineTerminatorStart(false, text.length());
    return trailing >= 0 ? trailing : text.length();
  }

  private int trailingLineStart(InputScanner text) {
    int len = text.length();
    if (len == 0) {
      return len;
    }
    int trailing = text.trailingLineTerminatorStart(prog.dollarAnchorUnixLines(), len);
    return trailing >= 0 ? trailing : len;
  }

  private boolean transitionDependsOnPosition(int cp, int position, int threshold) {
    if (!hasPositionDependentTransitions || cp < 0) {
      return false;
    }
    // In the default line-ending mode, BEGIN_LINE after a carriage return depends on whether the
    // following character is a line feed. A transition cached for CRLF therefore cannot be reused
    // for a standalone carriage return, or vice versa.
    return position >= threshold || cp == '\r';
  }

  private boolean hasSurrogateWordContext(int cp) {
    return cp >= Character.MIN_SURROGATE && cp <= Character.MAX_SURROGATE && prog.hasWordBoundary();
  }

  /**
   * Computes the next DFA state from the current state for a given code point.
   *
   * <p>For each CHAR_RANGE instruction in the current state, checks if it matches the code point.
   * Collects the successor instructions, expands them through empty transitions, and returns the
   * resulting state.
   */
  private State computeNext(State s, int cp, InputScanner text, int nextPos) {
    // At end of text, re-expand the current instruction set with end-of-text empty flags.
    // This allows empty-width assertions like $ and \b to fire.
    if (cp < 0) {
      // Compute empty flags for end-of-text, but override word boundary using state context.
      int emptyFlags = emptyFlags(text, nextPos);
      // At end-of-text the "current" character is not a word char.
      boolean wasWord = (s.flags & FLAG_LAST_WORD) != 0;
      if (wasWord) {
        emptyFlags = (emptyFlags | EmptyOp.WORD_BOUNDARY) & ~EmptyOp.NON_WORD_BOUNDARY;
      } else {
        emptyFlags = (emptyFlags | EmptyOp.NON_WORD_BOUNDARY) & ~EmptyOp.WORD_BOUNDARY;
      }
      boolean wasUnicodeWord = (s.flags & FLAG_LAST_UNICODE_WORD) != 0;
      if (wasUnicodeWord) {
        emptyFlags =
            (emptyFlags | EmptyOp.UNICODE_WORD_BOUNDARY) & ~EmptyOp.UNICODE_NON_WORD_BOUNDARY;
      } else {
        emptyFlags =
            (emptyFlags | EmptyOp.UNICODE_NON_WORD_BOUNDARY) & ~EmptyOp.UNICODE_WORD_BOUNDARY;
      }
      // Re-expand from the successors of EMPTY_WIDTH instructions that now pass.
      int seedCount = 0;
      for (int id : s.insts) {
        Inst ip = prog.inst(id);
        if (ip.opCode == InstOp.OP_EMPTY_WIDTH && (ip.arg & ~emptyFlags) == 0) {
          computeBuf[seedCount++] = ip.out;
        }
      }
      if (seedCount == 0) {
        return deadState;
      }
      int[] nextInsts = expand(computeBuf, seedCount, emptyFlags);
      if (nextInsts.length == 0) {
        return deadState;
      }
      int flags = emptyFlags & stateEmptyFlagsMask;
      if (hasMatch(nextInsts)) {
        flags |= FLAG_MATCH | FLAG_MATCH_BEFORE;
      }
      // End-of-text is not a word char, so FLAG_LAST_WORD is not set.
      return getOrCreate(nextInsts, flags);
    }

    int pos = cp >= 0 ? nextPos - Character.charCount(cp) : text.length();
    // Step 1: Re-evaluate unsatisfied EMPTY_WIDTH instructions that are now satisfiable.
    // Two kinds of assertions fire BEFORE consuming cp and depend on context that can't
    // be predicted when the state was built:
    //
    //   (a) Word boundary (\b, \B): depends on whether cp is a word character, combined
    //       with the previous character (FLAG_LAST_WORD in the state).
    //   (b) END_LINE ($): fires when cp is a line terminator. The DFA caches transitions
    //       per (state, char-class). END_LINE at position P depends on whether text[P] is
    //       a line terminator, but two positions with the same (state, char-class) may have
    //       different characters at P. So END_LINE is deferred and re-expanded here when
    //       the current character is a line terminator.
    //
    // Both are re-expanded before consuming the character so that MATCH instructions
    // reached through these assertions are detected at the correct position.
    boolean isWord = false;
    boolean isUnicodeWord = false;
    int wordBeforeFlags = 0;
    int unicodeWordBeforeFlags = 0;
    if (prog.hasWordBoundary()) {
      isWord = Nfa.isWordChar(cp);
      boolean wasWord = (s.flags & FLAG_LAST_WORD) != 0;
      wordBeforeFlags = (isWord != wasWord) ? EmptyOp.WORD_BOUNDARY : EmptyOp.NON_WORD_BOUNDARY;
      isUnicodeWord = cp < 128 ? isWord : Nfa.isUnicodeWordChar(cp);
      boolean wasUnicodeWord = (s.flags & FLAG_LAST_UNICODE_WORD) != 0;
      unicodeWordBeforeFlags =
          (isUnicodeWord != wasUnicodeWord)
              ? EmptyOp.UNICODE_WORD_BOUNDARY
              : EmptyOp.UNICODE_NON_WORD_BOUNDARY;
      if (hasSurrogateWordContext(cp)) {
        // A cursor can start inside a pair. Consumption then sees an unpaired half, but the
        // assertions on either side of it still classify their adjacent character in the input
        // context. The following assertion is recorded in the next state. Reverse search that
        // resumes inside a pair also consumes the low half; the assertion at its right edge must
        // see the whole pair, not the half.
        // Only split-pair cursors bypass the cache; truly unpaired halves remain cacheable.
        if (prog.reversed()
            && Character.isLowSurrogate((char) cp)
            && !text.isCodePointBoundary(nextPos)) {
          boolean pairIsUnicodeWord = Nfa.isUnicodeWordChar(text.codePointBefore(nextPos + 1));
          unicodeWordBeforeFlags =
              (pairIsUnicodeWord != wasUnicodeWord)
                  ? EmptyOp.UNICODE_WORD_BOUNDARY
                  : EmptyOp.UNICODE_NON_WORD_BOUNDARY;
        }
        int adjacent = prog.reversed() ? text.codePointAt(nextPos) : text.codePointBefore(nextPos);
        isUnicodeWord = Nfa.isUnicodeWordChar(adjacent);
      }
    }
    boolean endLineHere = Nfa.isLineTerminator(cp);
    if ((s.flags & FLAG_CRLF_CONTEXT) != 0 && cp == (prog.reversed() ? '\r' : '\n')) {
      endLineHere = false;
    }

    // In reverse, END_LINE represents an original BEGIN_LINE assertion: after a CR is a
    // line start only when the character to its right (already scanned) is not LF.
    int nextCrLfFlags =
        hasCrLfContext && cp == (prog.reversed() ? '\n' : '\r') ? FLAG_CRLF_CONTEXT : 0;
    int reExpandEmptyFlags =
        (s.flags & stateEmptyFlagsMask) | wordBeforeFlags | unicodeWordBeforeFlags;
    if (endLineHere) {
      reExpandEmptyFlags |= EmptyOp.END_LINE;
    }
    if (cp == '\n') {
      reExpandEmptyFlags |= EmptyOp.UNIX_END_LINE;
    }
    int[] instsWithoutMatch = stripMatch(s.insts);

    // Collect expanded instructions and detect deferred matches in priority order.
    int[] tempExpanded = new int[prog.instructions.size()];
    int tempCount = 0;
    boolean hasMatchFromDeferred = false;
    boolean deferredMatchIsPrimary = false;
    int[] deferredMatchIds = null;
    boolean isMatchValid = false;

    for (int id : instsWithoutMatch) {
      Inst ip = prog.inst(id);
      if (ip.opCode == InstOp.OP_EMPTY_WIDTH && (ip.arg & ~reExpandEmptyFlags) == 0) {
        int[] expanded = expand(new int[] {ip.out}, 1, reExpandEmptyFlags);
        if (hasMatch(expanded)) {
          hasMatchFromDeferred = true;
          deferredMatchIds = collectMatchIds(expanded);
          deferredMatchIsPrimary = isMatchPrimary(expanded);
          // Add non-MATCH instructions from this expansion.
          for (int x : expanded) {
            if (prog.inst(x).opCode != InstOp.OP_MATCH) {
              if (tempCount == tempExpanded.length) {
                tempExpanded = Arrays.copyOf(tempExpanded, tempExpanded.length * 2);
              }
              tempExpanded[tempCount++] = x;
            }
          }
          // Check if this match is valid.
          if (!prog.anchorEnd()) {
            isMatchValid = true;
          } else {
            int textLen = text.length();
            int trailingTermStart = prog.dollarAnchorEnd() ? trailingLineStart(text) : textLen;
            if (pos == textLen || (trailingTermStart < textLen && pos == trailingTermStart)) {
              isMatchValid = true;
            }
          }
          if (!longest && isMatchValid && !prog.reversed()) {
            // Only first-match search can discard lower-priority consuming branches.
            // Longest-match search must retain them because they may extend this match.
            break;
          }
        } else {
          for (int x : expanded) {
            if (tempCount == tempExpanded.length) {
              tempExpanded = Arrays.copyOf(tempExpanded, tempExpanded.length * 2);
            }
            tempExpanded[tempCount++] = x;
          }
        }
      } else {
        if (tempCount == tempExpanded.length) {
          tempExpanded = Arrays.copyOf(tempExpanded, tempExpanded.length * 2);
        }
        tempExpanded[tempCount++] = id;
      }
    }
    int[] expandedInsts = stableDedup(tempExpanded, tempCount);

    // Step 2: Process CHAR_RANGE/CHAR_CLASS transitions against cp.
    int successorCount = 0;
    boolean hasUnanchoredLoopTransition = false;
    int unanchoredStart = prog.anchorStart() ? 0 : prog.startUnanchored();
    for (int id : expandedInsts) {
      Inst ip = prog.inst(id);
      if (ip.opCode == InstOp.OP_CHAR_RANGE && ip.matchesChar(cp)) {
        if (unanchoredStart != 0 && ip.out == unanchoredStart) {
          hasUnanchoredLoopTransition = true;
        } else {
          computeBuf[successorCount++] = ip.out;
        }
      } else if (ip.opCode == InstOp.OP_CHAR_CLASS && ip.matchesCharClass(cp)) {
        if (unanchoredStart != 0 && ip.out == unanchoredStart) {
          hasUnanchoredLoopTransition = true;
        } else {
          computeBuf[successorCount++] = ip.out;
        }
      }
    }
    if (hasUnanchoredLoopTransition && !isMatchValid) {
      computeBuf[successorCount++] = unanchoredStart;
    }

    if (successorCount == 0) {
      // No character transition matched, but if deferred assertion expansion revealed a MATCH,
      // return a match state. FLAG_MATCH_BEFORE indicates the match position should be
      // recorded at the current position (before consuming cp), not after.
      if (hasMatchFromDeferred) {
        return getOrCreate(
            EMPTY_INSTS,
            FLAG_MATCH
                | FLAG_MATCH_BEFORE
                | nextCrLfFlags
                | (isWord ? FLAG_LAST_WORD : 0)
                | (isUnicodeWord ? FLAG_LAST_UNICODE_WORD : 0),
            deferredMatchIds);
      }
      return deadState;
    }

    // Compute empty flags at nextPos (after consuming cp). Omit deferred flags:
    // word boundary (depends on the next character) and END_LINE (depends on what's at
    // nextPos, not deterministic for cache). Unsatisfied EMPTY_WIDTH instructions will
    // remain in the frontier for re-evaluation when the next character arrives.
    int emptyFlags = emptyFlags(text, nextPos);
    emptyFlags &=
        ~(EmptyOp.WORD_BOUNDARY
            | EmptyOp.NON_WORD_BOUNDARY
            | EmptyOp.UNICODE_WORD_BOUNDARY
            | EmptyOp.UNICODE_NON_WORD_BOUNDARY
            | EmptyOp.END_LINE
            | EmptyOp.UNIX_END_LINE);

    int[] nextInsts = expand(computeBuf, successorCount, emptyFlags);

    if (nextInsts.length == 0) {
      if (hasMatchFromDeferred) {
        return getOrCreate(
            EMPTY_INSTS,
            FLAG_MATCH
                | FLAG_MATCH_BEFORE
                | nextCrLfFlags
                | (isWord ? FLAG_LAST_WORD : 0)
                | (isUnicodeWord ? FLAG_LAST_UNICODE_WORD : 0),
            deferredMatchIds);
      }
      return deadState;
    }

    int flags = (emptyFlags & stateEmptyFlagsMask) | nextCrLfFlags;
    if (hasMatchFromDeferred) {
      // A deferred assertion (\b, \B, or multiline $) fired before consuming the current
      // character and reached a MATCH instruction.
      if (deferredMatchIsPrimary) {
        flags |= FLAG_MATCH | FLAG_MATCH_BEFORE;
        if (hasMatch(nextInsts)) {
          flags |= FLAG_MATCH_AFTER_DEFERRED;
        }
      } else {
        if (hasMatch(nextInsts)) {
          flags |= FLAG_MATCH | (prog.reversed() ? FLAG_MATCH_BEFORE_SHADOWED : 0);
        } else {
          flags |= FLAG_MATCH | FLAG_MATCH_BEFORE;
        }
      }
    } else if (hasMatch(nextInsts)) {
      flags |= FLAG_MATCH;
    }
    if (isWord) {
      flags |= FLAG_LAST_WORD;
    }
    if (isUnicodeWord) {
      flags |= FLAG_LAST_UNICODE_WORD;
    }
    return getOrCreate(nextInsts, flags, deferredMatchIds);
  }

  // ---------------------------------------------------------------------------
  // Search
  // ---------------------------------------------------------------------------

  /**
   * Searches for a match using the DFA, starting from position 0.
   *
   * @param prog the compiled program
   * @param text the input text
   * @param anchored whether to anchor the search at the start
   * @param longest whether to find the longest match (vs. earliest/first match)
   * @return search result, or {@code null} if the DFA exceeded its state budget (caller should fall
   *     back to NFA)
   */
  static SearchResult search(Prog prog, String text, boolean anchored, boolean longest) {
    return search(prog, new StringInputScanner(text), 0, anchored, longest, DEFAULT_MAX_STATES);
  }

  /** Search with explicit state budget, starting from position 0. */
  static SearchResult search(
      Prog prog, String text, boolean anchored, boolean longest, int maxStates) {
    return search(prog, new StringInputScanner(text), 0, anchored, longest, maxStates);
  }

  /**
   * Search with explicit start position and state budget.
   *
   * @param prog the compiled program
   * @param text the input text
   * @param startPos the char index in {@code text} at which to begin searching
   * @param anchored whether to anchor the search at {@code startPos}
   * @param longest whether to find the longest match (vs. earliest/first match)
   * @param maxStates maximum DFA state budget
   * @return search result, or {@code null} if the DFA exceeded its state budget
   */
  static SearchResult search(
      Prog prog, String text, int startPos, boolean anchored, boolean longest, int maxStates) {
    return search(prog, new StringInputScanner(text), startPos, anchored, longest, maxStates);
  }

  static SearchResult search(Prog prog, InputScanner text, boolean anchored, boolean longest) {
    return search(prog, text, 0, anchored, longest, DEFAULT_MAX_STATES);
  }

  static SearchResult search(
      Prog prog, InputScanner text, boolean anchored, boolean longest, int maxStates) {
    return search(prog, text, 0, anchored, longest, maxStates);
  }

  static SearchResult search(
      Prog prog,
      InputScanner text,
      int startPos,
      boolean anchored,
      boolean longest,
      int maxStates) {
    Dfa dfa = new Dfa(prog, maxStates, buildSetup(prog), longest);
    return dfa.doSearch(text, startPos, anchored, longest);
  }

  /**
   * Main DFA search loop, starting from position 0.
   *
   * @see #doSearch(String, int, boolean, boolean)
   */
  SearchResult doSearch(String text, boolean anchored, boolean longest) {
    return doSearch(new StringInputScanner(text), 0, anchored, longest);
  }

  SearchResult doSearch(String text, int startPos, boolean anchored, boolean longest) {
    return doSearch(new StringInputScanner(text), startPos, anchored, longest);
  }

  SearchResult doSearch(InputScanner text, boolean anchored, boolean longest) {
    return doSearch(text, 0, anchored, longest);
  }

  /**
   * Searches from a position that the caller may already have selected with this DFA's start
   * accelerator.
   *
   * <p>A preselected position must still be matched normally because it is only a candidate. The
   * flag suppresses the redundant accelerator call at exactly {@code startPos}; acceleration
   * remains available after the DFA consumes input and returns to its start state.
   */
  SearchResult doSearch(
      InputScanner text,
      int startPos,
      boolean anchored,
      boolean longest,
      boolean startPositionPreselected) {
    return doSearchInternal(
        text, startPos, anchored, longest, startPositionPreselected, AdaptiveBackoff.NEUTRAL);
  }

  /**
   * Like {@link #doSearch(InputScanner, int, boolean, boolean, boolean)}, but starts from the
   * start-acceleration backoff state {@code startBackoff} left by an earlier search of the same
   * input. The updated state is available from {@link #startBackoff()} when this returns.
   */
  SearchResult doSearch(
      InputScanner text,
      int startPos,
      boolean anchored,
      boolean longest,
      boolean startPositionPreselected,
      long startBackoff) {
    return doSearchInternal(
        text, startPos, anchored, longest, startPositionPreselected, startBackoff);
  }

  /**
   * Returns the start-acceleration backoff state at the end of the most recent forward search.
   *
   * <p>Searches that cannot use start acceleration return their initial state unchanged.
   */
  long startBackoff() {
    return lastStartBackoff;
  }

  /**
   * Fast-forwards the start position of unanchored search matching when returning to the start
   * state.
   */
  private int fastForward(
      InputScanner text,
      int pos,
      int posDepThreshold,
      State startState,
      Utf8StartAccelerator.SearchCursor utf8Cursor,
      boolean allowInnerProbe) {
    int candidate = findStartCandidate(text, pos, posDepThreshold, startState, utf8Cursor);
    if (candidate < 0 || !allowInnerProbe) {
      return candidate;
    }
    if (innerProbeState == INNER_PROBE_WAITING) {
      innerProbeResumePos += Math.max(0, candidate - pos);
      return candidate;
    }
    if (innerProbeState != INNER_PROBE_READY) {
      return candidate;
    }
    innerProbeState = INNER_PROBE_USED;
    int narrowed = innerLiteralSearch.searchStart(text, candidate);
    if (narrowed <= candidate) {
      return narrowed;
    }
    // Preserve the ordinary accelerator's terminal context boundary. The DFA evaluates
    // position-dependent transitions from there rather than skipping over that boundary.
    if (hasPositionDependentTransitions && narrowed >= posDepThreshold - 1) {
      return Math.max(candidate, posDepThreshold - 1);
    }
    return findStartCandidate(text, narrowed, posDepThreshold, startState, utf8Cursor);
  }

  private void updateInnerProbeState(int pos) {
    if (innerProbeState == INNER_PROBE_WAITING && pos >= innerProbeResumePos) {
      innerProbeState = INNER_PROBE_READY;
      innerProbeResumePos = 0;
    }
  }

  private int findStartCandidate(
      InputScanner text,
      int pos,
      int posDepThreshold,
      State startState,
      Utf8StartAccelerator.SearchCursor utf8Cursor) {
    if (text instanceof Utf8InputScanner utf8Scanner && utf8StartAccelerator != null) {
      int idx =
          utf8Cursor != null
              ? utf8Cursor.findCandidate(utf8Scanner, pos)
              : Utf8StartAccelerator.findNextCandidate(utf8StartAccelerator, utf8Scanner, pos);
      return idx >= 0 ? Math.min(idx, posDepThreshold - 1) : -1;
    }
    if (text instanceof StringInputScanner stringScanner && stringStartAccelerator != null) {
      return StringStartAccelerator.findNextCandidate(
          stringStartAccelerator, stringScanner.text(), pos, prog.lineStartUnixLines());
    }
    if (text instanceof StringRegionInputScanner region && stringStartAccelerator != null) {
      return StringStartAccelerator.findNextCandidate(
          stringStartAccelerator, region, pos, prog.lineStartUnixLines());
    }
    return fastForwardStartState(text, pos, posDepThreshold, startState);
  }

  private int fastForwardStartState(
      InputScanner text, int pos, int posDepThreshold, State startState) {
    if (startState != null && startState.accelerator != null) {
      int limit =
          hasPositionDependentTransitions
              ? Math.min(text.length(), posDepThreshold - 1)
              : text.length();
      int idx = StateAccelerator.findNextEscape(startState.accelerator, text, pos, limit);
      if (idx >= 0) {
        return idx;
      }
      if (hasPositionDependentTransitions && limit < text.length()) {
        return limit;
      }
      return -1;
    }
    return pos;
  }

  /**
   * Main DFA search loop.
   *
   * <p>Iterates over each code point in the text starting from {@code startPos}, following
   * transitions. When a match state is reached, records the position. In earliest-match mode,
   * returns immediately. In longest-match mode, continues to find the longest match.
   *
   * @param text the full input text
   * @param startPos the char index in {@code text} at which to begin searching
   * @param anchored whether to anchor the search at {@code startPos}
   * @param longest whether to find the longest match
   * @return search result with positions relative to {@code text}, or {@code null} if the DFA
   *     exceeded its state budget
   */
  SearchResult doSearch(InputScanner text, int startPos, boolean anchored, boolean longest) {
    return doSearchInternal(text, startPos, anchored, longest, false, AdaptiveBackoff.NEUTRAL);
  }

  private SearchResult doSearchInternal(
      InputScanner text,
      int startPos,
      boolean anchored,
      boolean longest,
      boolean startPositionPreselected,
      long startBackoff) {
    graphemeContext = GraphemeSupport.Context.create(text, hasGraphemeSemantics);
    beginSearch(startPos);
    int pos = startPos;
    int textLen = text.length();
    // If the compiled program requires end-of-text matching (stripped $ or \z), enforce it.
    boolean needEndMatch = prog.anchorEnd();
    boolean dollarEnd = prog.dollarAnchorEnd();
    // $ allows matching before a trailing line terminator at end of text (JDK default $
    // behavior).
    // Compute the start position of the trailing line terminator for dollarAnchorEnd matching.
    int trailingTermStart = dollarEnd ? trailingLineStart(text) : textLen;

    // Position-dependent flag threshold: emptyFlags at positions >= this threshold contain
    // text-length-dependent flags (END_TEXT at textLen, DOLLAR_END near the end when text ends
    // with a line terminator). Transitions computed at such positions must NOT be cached
    // because the same (state, character-class) pair at a different position (in the same or
    // a different text) would produce a different result. See the class-level comment on
    // DFA caching invariants.
    int posDepThreshold = positionDependentThreshold(text);

    State s = startStateOrReset(text, startPos, anchored, false);
    if (s == null) {
      return completeForwardSearch(null, pos, startBackoff);
    }

    boolean matched = false;
    int matchEnd = -1;
    // Check if start state is already a match (e.g., empty pattern or .*? prefix).
    if (s.isMatch()) {
      if (isRequiredEndMatch(startPos, needEndMatch, textLen, trailingTermStart)) {
        matched = true;
        matchEnd = startPos;
        if (!longest && canStopAtFirstMatch(s, text, startPos, needEndMatch)) {
          return completeForwardSearch(new SearchResult(true, startPos), pos, startBackoff);
        }
      }
    }

    if (s == deadState) {
      return completeForwardSearch(new SearchResult(matched, matchEnd), pos, startBackoff);
    }

    AcceleratorPolicy activePolicy = startAccelerationPolicy(text, s);
    boolean canAccelerate = activePolicy != null && !anchored;
    Utf8StartAccelerator.SearchCursor utf8Cursor =
        canAccelerate && text instanceof Utf8InputScanner
            ? Utf8StartAccelerator.searchCursor(utf8StartAccelerator)
            : null;
    AcceleratorPolicy tuning = canAccelerate ? activePolicy : AcceleratorPolicy.DEFAULT;
    int minSkip = tuning.minProfitableSkip();
    int lossLimit = tuning.strikeBudget() * minSkip;
    int initialQuarantineWindow = tuning.initialQuarantineWindow();
    int maxQuarantineWindow = tuning.maxQuarantineWindow();

    // Compare each scan's saved DFA work with that accelerator's minimum profitable skip.
    // Candidate spacing includes work already done by the DFA, especially during quarantine;
    // crediting that work would restore an accelerator that is still unprofitable. Only actual
    // skips in excess of the estimated call cost can repay the deficit and reset quarantine.
    // One strike's allowance is one call's cost: a break-even call cannot erase another call's
    // loss. The deficit stays bounded by the allowance, regardless of the size of the input.
    // The caller may carry the backoff state across searches of the same input (see
    // AdaptiveBackoff), so a sequence of find() calls pays the loss limit once rather than once per
    // search. It is read here once and written back once when the search completes.
    long backoff = startBackoff;
    // The first position at which the loops below may call the accelerator, or MAX_VALUE when
    // they never may. Folding canAccelerate in keeps the per-step test to one comparison.
    int accelerationResumePos =
        canAccelerate ? AdaptiveBackoff.resumePos(backoff) : Integer.MAX_VALUE;
    // A preselected start position is never re-scanned; -1 when there is none.
    int preselectedPos = startPositionPreselected ? startPos : -1;
    // A successful first candidate pays no suffix scan or backward probe. Returning to the
    // unanchored start state after consuming input proves that every earlier candidate failed.
    // A small native-work budget avoids probing for isolated short failures. Only ordinary
    // prefix-scan skips move its threshold; input consumed by native matching pays the budget.
    // Probe at most once per search, independently of ordinary prefix-scan quarantine. A failed
    // bounded backward probe falls back to this same DFA pass; it is never retried at each start.
    innerProbeState =
        canAccelerate && innerLiteralSearch != null && !longest
            ? INNER_PROBE_WAITING
            : INNER_PROBE_DISABLED;
    innerProbeResumePos = (long) startPos + InnerLiteralSearch.MIN_FAILED_INPUT_UNITS;
    pendingFailureTransitionIndex = -1;
    if (innerProbeState == INNER_PROBE_WAITING && pausedFailureTransitionCount != 0) {
      restoreFailureTransitions();
    }

    int[] transitions = this.transitions;
    State[] offsetToState = this.offsetToState;
    boolean[] isAcceleratedStateOffset = this.isAcceleratedStateOffset;
    int[] asciiClassMap = this.asciiClassMap;
    // Fast path: loop through ASCII characters (characters < 128)
    while (pos < textLen) {
      updateInnerProbeState(pos);
      if (s.isStartState
          && ((pos >= accelerationResumePos && pos != preselectedPos && textLen - pos >= minSkip)
              || (!matched && innerProbeState == INNER_PROBE_READY))) {
        int nextPos = fastForward(text, pos, posDepThreshold, s, utf8Cursor, !matched);
        if (WorkCounterConfig.ENABLED) {
          WorkCounter.recordStartScan(nextPos < 0 ? textLen - pos : nextPos - pos);
        }
        if (nextPos == -1) {
          pos = textLen;
          return completeForwardSearch(new SearchResult(matched, matchEnd), pos, backoff);
        }
        backoff =
            AdaptiveBackoff.recordSkip(
                backoff,
                nextPos - pos,
                nextPos,
                textLen,
                minSkip,
                lossLimit,
                initialQuarantineWindow,
                maxQuarantineWindow);
        accelerationResumePos = AdaptiveBackoff.resumePos(backoff);
        if (nextPos > pos) {
          pos = nextPos;
          if (pos >= textLen) {
            break;
          }
          s = startStateOrReset(text, pos, anchored, false);
          if (s == null) {
            return completeForwardSearch(null, pos, backoff);
          }
          // Creating a start state, or resetting the cache, can grow or replace the contents of
          // the flat arrays, just like computeNext below.
          transitions = this.transitions;
          offsetToState = this.offsetToState;
          isAcceleratedStateOffset = this.isAcceleratedStateOffset;
          if (s.isMatch()) {
            if (isRequiredEndMatch(pos, needEndMatch, textLen, trailingTermStart)) {
              matched = true;
              matchEnd = pos;
              if (!longest && canStopAtFirstMatch(s, text, pos, needEndMatch)) {
                return completeForwardSearch(new SearchResult(true, pos), pos, backoff);
              }
            }
          }
          if (s == deadState) {
            return completeForwardSearch(new SearchResult(matched, matchEnd), pos, backoff);
          }
        }
      }
      if (s.accelerator != null && (!s.isStartState || anchored) && (textLen - pos >= 16)) {
        int nextPos = StateAccelerator.findNextEscape(s.accelerator, text, pos, textLen);
        if (nextPos == -1) {
          pos = textLen;
          break;
        }
        if (nextPos > pos) {
          pos = nextPos;
          if (pos >= textLen) {
            break;
          }
        }
      }
      boolean breakOnAcceleratedState =
          innerProbeState == INNER_PROBE_READY
              || pos >= accelerationResumePos
              || hasStateAccelerators;
      boolean hitAcceleratedState = false;
      int limit =
          hasPositionDependentTransitions ? Math.min(textLen, posDepThreshold - 1) : textLen;
      if (innerProbeState == INNER_PROBE_WAITING) {
        // Reuse the scan limit to pay the budget without polling a long threshold in the loop.
        limit = (int) Math.min(limit, innerProbeResumePos);
      }
      int sId = s.id * numClasses;
      if (breakOnAcceleratedState) {
        while (pos < limit) {
          int ch = text.asciiAt(pos);
          if (ch < 0 || transitionDependsOnPosition(ch, pos + 1, posDepThreshold)) {
            break;
          }
          if (WorkCounterConfig.ENABLED) {
            WorkCounter.recordForwardDfaStep();
          }
          int cls = asciiClassMap[ch];
          int nsId = transitions[sId + cls];
          if (nsId == 0) {
            break;
          }
          if (nsId < 0) {
            nsId = -nsId;
            State ns = offsetToState[nsId];
            if (ns.isMatch() && !needEndMatch) {
              boolean useBefore =
                  (ns.flags & (FLAG_MATCH_BEFORE | FLAG_MATCH_AFTER_DEFERRED)) == FLAG_MATCH_BEFORE;
              int endPos = useBefore ? pos : pos + 1;
              if (!longest && ns.isHighestPriorityMatch) {
                return completeForwardSearch(new SearchResult(true, endPos), pos, backoff);
              }
              matched = true;
              matchEnd = endPos;
            }
            if (ns.isStartState
                && (innerProbeState == INNER_PROBE_READY || innerProbeState == INNER_PROBE_USED)) {
              if (innerProbeState == INNER_PROBE_USED) {
                pendingFailureTransitionIndex = sId + cls;
              }
              sId = nsId;
              pos++;
              hitAcceleratedState = true;
              break;
            }
          }
          if (nsId == sId && isAcceleratedStateOffset[sId]) {
            sId = nsId;
            pos++;
            hitAcceleratedState = true;
            break;
          }
          sId = nsId;
          pos++;
        }
      } else {
        while (pos < limit) {
          int ch = text.asciiAt(pos);
          if (ch < 0 || transitionDependsOnPosition(ch, pos + 1, posDepThreshold)) {
            break;
          }
          if (WorkCounterConfig.ENABLED) {
            WorkCounter.recordForwardDfaStep();
          }
          int cls = asciiClassMap[ch];
          int nsId = transitions[sId + cls];
          if (nsId == 0) {
            break;
          }
          if (nsId < 0) {
            nsId = -nsId;
            State ns = offsetToState[nsId];
            if (ns.isMatch() && !needEndMatch) {
              boolean useBefore =
                  (ns.flags & (FLAG_MATCH_BEFORE | FLAG_MATCH_AFTER_DEFERRED)) == FLAG_MATCH_BEFORE;
              int endPos = useBefore ? pos : pos + 1;
              if (!longest && ns.isHighestPriorityMatch) {
                return completeForwardSearch(new SearchResult(true, endPos), pos, backoff);
              }
              matched = true;
              matchEnd = endPos;
            }
          }
          sId = nsId;
          pos++;
        }
      }
      s = offsetToState[sId];
      if (pendingFailureTransitionIndex >= 0) {
        // Keep all transition-table writes outside the cached scalar loop.
        pauseFailureTransition(pendingFailureTransitionIndex, sId);
        pendingFailureTransitionIndex = -1;
      }

      if (pos >= textLen) {
        break;
      }
      if (hitAcceleratedState) {
        continue;
      }
      if (hasPositionDependentTransitions && pos + 1 >= posDepThreshold) {
        break; // fall back to general loop for position-dependent flags
      }

      int ch = text.asciiAt(pos);
      if (ch < 0 || transitionDependsOnPosition(ch, pos + 1, posDepThreshold)) {
        break; // fall back to general loop
      }
      int cls = asciiClassMap[ch];
      State ns = s.next[cls];
      if (ns == null) {
        int effectiveNextPos = pos + 1;
        ns = transitionOrReset(s, cls, ch, text, effectiveNextPos, pos);
        if (ns == null) {
          return completeForwardSearch(null, pos, backoff); // budget exceeded
        }
        // computeNext can grow the flat arrays and a cache reset replaces their contents. Either
        // way s is no longer usable, but the loop reloads sId from ns on the next iteration.
        transitions = this.transitions;
        offsetToState = this.offsetToState;
        isAcceleratedStateOffset = this.isAcceleratedStateOffset;
      }
      s = ns;
      if (s == deadState) {
        break;
      }
      if (s.isMatch()) {
        boolean useBefore =
            (s.flags & (FLAG_MATCH_BEFORE | FLAG_MATCH_AFTER_DEFERRED)) == FLAG_MATCH_BEFORE;
        int endPos = useBefore ? pos : pos + 1;
        if (isRequiredEndMatch(endPos, needEndMatch, textLen, trailingTermStart)) {
          matched = true;
          matchEnd = endPos;
          if (!longest && canStopAtFirstMatch(s, text, endPos, needEndMatch)) {
            return completeForwardSearch(new SearchResult(true, matchEnd), pos, backoff);
          }
        }
      }
      pos++;
    }

    // General loop handles non-ASCII, position-dependent checks, and trailing end-of-text
    // sentinel
    generalLoop:
    while (pos <= textLen) {
      updateInnerProbeState(pos);
      if (s.isStartState
          && ((pos >= accelerationResumePos && pos != preselectedPos && textLen - pos >= minSkip)
              || (!matched && innerProbeState == INNER_PROBE_READY))) {
        int nextPos = fastForward(text, pos, posDepThreshold, s, utf8Cursor, !matched);
        if (WorkCounterConfig.ENABLED) {
          WorkCounter.recordStartScan(nextPos < 0 ? textLen - pos : nextPos - pos);
        }
        if (nextPos == -1) {
          pos = textLen;
          return completeForwardSearch(new SearchResult(matched, matchEnd), pos, backoff);
        }
        backoff =
            AdaptiveBackoff.recordSkip(
                backoff,
                nextPos - pos,
                nextPos,
                textLen,
                minSkip,
                lossLimit,
                initialQuarantineWindow,
                maxQuarantineWindow);
        accelerationResumePos = AdaptiveBackoff.resumePos(backoff);
        if (nextPos > pos) {
          pos = nextPos;
          if (pos > textLen) {
            break generalLoop;
          }
          s = startStateOrReset(text, pos, anchored, false);
          if (s == null) {
            return completeForwardSearch(null, pos, backoff);
          }
          if (s.isMatch()) {
            if (isRequiredEndMatch(pos, needEndMatch, textLen, trailingTermStart)) {
              matched = true;
              matchEnd = pos;
              if (!longest && canStopAtFirstMatch(s, text, pos, needEndMatch)) {
                return completeForwardSearch(new SearchResult(true, pos), pos, backoff);
              }
            }
          }
          if (s == deadState) {
            return completeForwardSearch(new SearchResult(matched, matchEnd), pos, backoff);
          }
        }
      }
      // Step the DFA until it may call the start accelerator again. Making that test the exit of
      // this inner loop keeps the accelerator path out of the hot per-character loop.
      int stepLimit =
          innerProbeState == INNER_PROBE_WAITING
              ? (int) Math.min(Integer.MAX_VALUE, innerProbeResumePos)
              : Integer.MAX_VALUE;
      do {
        if (s.accelerator != null && (textLen - pos >= 16) && (!s.isStartState || anchored)) {
          int nextPos = StateAccelerator.findNextEscape(s.accelerator, text, pos, textLen);
          if (nextPos == -1) {
            pos = textLen;
          } else if (nextPos > pos) {
            pos = nextPos;
            if (pos > textLen) {
              break generalLoop;
            }
          }
        }
        if (WorkCounterConfig.ENABLED) {
          WorkCounter.record();
          WorkCounter.recordForwardDfaStep();
        }
        int cp;
        int nextPos;
        int cls;
        if (pos < textLen) {
          int singleUnitCodePoint = text.singleUnitCodePointAt(pos);
          if (singleUnitCodePoint >= 0) {
            cp = singleUnitCodePoint;
            nextPos = pos + 1;
            cls =
                singleUnitCodePoint < asciiClassMap.length
                    ? asciiClassMap[singleUnitCodePoint]
                    : classOf(singleUnitCodePoint);
          } else {
            long decoded = text.decodeForward(pos);
            cp = InputScanner.codePoint(decoded);
            nextPos = InputScanner.position(decoded);
            cls = classOf(cp);
          }
        } else {
          cp = -1;
          nextPos = textLen + 1;
          cls = numClasses - 1;
        }

        // Compute the next state, using the transition cache when safe.
        // Transitions where the destination position has text-length-dependent emptyFlags
        // (END_TEXT, DOLLAR_END) must bypass the cache to preserve the invariant that
        // cached transitions are position-independent. The end-of-text sentinel (cp < 0)
        // is always safe to cache because it always means "at text end".
        int effectiveNextPos = Math.min(nextPos, textLen);
        State ns;
        if ((hasSurrogateWordContext(cp) && !text.isCodePointBoundary(pos))
            || transitionDependsOnPosition(cp, effectiveNextPos, posDepThreshold)) {
          ns = computeNextOrReset(s, cp, text, effectiveNextPos, pos);
          if (ns == null) {
            return completeForwardSearch(null, pos, backoff); // budget exceeded
          }
        } else {
          ns = s.next[cls];
          if (ns == null) {
            ns = transitionOrReset(s, cls, cp, text, effectiveNextPos, pos);
            if (ns == null) {
              return completeForwardSearch(null, pos, backoff); // budget exceeded
            }
          }
        }

        s = ns;

        if (s == deadState) {
          break generalLoop;
        }

        if (s.isMatch()) {
          // FLAG_MATCH_BEFORE indicates a deferred assertion (\b, multiline $) fired before
          // consuming the current character and reached MATCH. Try the before-consume position
          // first (it's at an earlier position, preserving leftmost-first semantics).
          if ((s.flags & (FLAG_MATCH_BEFORE | FLAG_MATCH_AFTER_DEFERRED)) == FLAG_MATCH_BEFORE) {
            int endPos = pos;
            if (isRequiredEndMatch(endPos, needEndMatch, textLen, trailingTermStart)) {
              matched = true;
              matchEnd = endPos;
              if (!longest && canStopAtFirstMatch(s, text, endPos, needEndMatch)) {
                return completeForwardSearch(new SearchResult(true, matchEnd), pos, backoff);
              }
            }
          }
          // Try the after-consume position: either no before-consume match exists, or it was
          // rejected (e.g., needEndMatch but pos != textLen) and an after-consume match also
          // exists (FLAG_MATCH_AFTER_DEFERRED).
          if ((s.flags & (FLAG_MATCH_BEFORE | FLAG_MATCH_AFTER_DEFERRED)) != FLAG_MATCH_BEFORE) {
            int endPos = Math.min(nextPos, textLen);
            if (isRequiredEndMatch(endPos, needEndMatch, textLen, trailingTermStart)) {
              matched = true;
              matchEnd = endPos;
              if (!longest && canStopAtFirstMatch(s, text, endPos, needEndMatch)) {
                return completeForwardSearch(new SearchResult(true, matchEnd), pos, backoff);
              }
            }
          }
        }

        if (pos >= textLen) {
          break generalLoop;
        }
        pos = nextPos;
      } while (pos < stepLimit
          && (!s.isStartState
              || (pos < accelerationResumePos && innerProbeState != INNER_PROBE_READY)));
    }

    return completeForwardSearch(new SearchResult(matched, matchEnd), pos, backoff);
  }

  // ---------------------------------------------------------------------------
  // Reverse search
  // ---------------------------------------------------------------------------

  /**
   * Reverse DFA search: scans backward through text from {@code endPos} to find match start. Used
   * with a reversed program to find where the leftmost match begins after the forward DFA has
   * determined where it ends.
   *
   * <p>This enables a critical optimization: instead of running the expensive NFA/BitState engine
   * on the entire remaining text, we can narrow the search to just {@code [matchStart, matchEnd]}.
   *
   * @param text the full input text
   * @param endPos the position to start scanning backward from (exclusive upper bound of the match)
   * @param startLimit the earliest position to scan back to (inclusive), typically 0 or the
   *     prefix-acceleration start
   * @param anchored if true, the reverse match must start at {@code endPos} (meaning the forward
   *     match ends exactly there)
   * @param longest if true, find the longest reverse match (earliest start position)
   * @return search result where {@code pos} is the match start position, or {@code null} if the DFA
   *     exceeded its state budget
   */
  SearchResult doSearchReverse(
      String text, int endPos, int startLimit, boolean anchored, boolean longest) {
    return doSearchReverse(new StringInputScanner(text), endPos, startLimit, anchored, longest);
  }

  SearchResult doSearchReverse(
      InputScanner text, int endPos, int startLimit, boolean anchored, boolean longest) {
    return doSearchReverse(text, endPos, startLimit, anchored, longest, Integer.MAX_VALUE);
  }

  /**
   * Reverse search with a speculative input-unit limit. A live frontier at the cutoff is
   * inconclusive, even if it contains a match: an earlier start may exist outside the window. The
   * cutoff never substitutes for {@code startLimit} in assertion context. Decoding may finish one
   * code point across the cutoff, and assertions retain their normal adjacent context.
   */
  SearchResult doSearchReverse(
      InputScanner text,
      int endPos,
      int startLimit,
      boolean anchored,
      boolean longest,
      int maxInputUnits) {
    int scanLimit = Math.max(startLimit, endPos - maxInputUnits);
    graphemeContext = GraphemeSupport.Context.create(text, hasGraphemeSemantics);
    beginSearch(endPos);
    int pos = endPos;
    // The reversed program's "start of text" corresponds to endPos (the right edge of the match
    // region), and its "end of text" corresponds to startLimit (the left edge). We scan from
    // endPos backward to startLimit, feeding characters in reverse order.
    boolean needEndMatch = prog.anchorEnd();

    // Position-dependent threshold: same invariant as doSearch — bypass the transition cache
    // for positions where text-length-dependent emptyFlags (END_TEXT, DOLLAR_END) are active.
    int posDepThreshold = positionDependentThreshold(text);

    // Compute empty flags at the reverse start position (= endPos in the original text).
    State s = startStateOrReset(text, endPos, anchored, true);
    if (s == null) {
      return completeSearch(null, pos);
    }

    boolean matched = false;
    int matchStart = -1;
    boolean ambiguous = false;

    // Check if start state is already a match (e.g., empty pattern).
    if (s.isMatch()) {
      if (!needEndMatch || endPos == startLimit) {
        matched = true;
        matchStart = endPos;
        if (!longest && !needEndMatch) {
          return completeSearch(new SearchResult(true, matchStart), pos);
        }
      }
    }

    if (s == deadState) {
      return completeSearch(new SearchResult(matched, matchStart), pos);
    }

    int[] transitions = this.transitions;
    State[] offsetToState = this.offsetToState;
    int[] asciiClassMap = this.asciiClassMap;
    // Fast path: scan backward through ASCII characters
    while (pos > scanLimit) {
      if (pos <= posDepThreshold) {
        int limit = scanLimit;
        int sId = s.id * numClasses;
        while (pos > limit) {
          // Probe work includes cached transitions; keep ordinary-search counter behavior stable.
          if (WorkCounterConfig.ENABLED && maxInputUnits != Integer.MAX_VALUE) {
            WorkCounter.record();
          }
          int ch = text.asciiAt(pos - 1);
          if (ch < 0 || transitionDependsOnPosition(ch, pos - 1, posDepThreshold)) {
            break;
          }
          int cls = asciiClassMap[ch];
          int nsId = transitions[sId + cls];
          if (nsId == 0) {
            break;
          }
          if (nsId < 0) {
            nsId = -nsId;
            State ns = offsetToState[nsId];
            if (ns.isMatch()) {
              int flags = ns.flags;
              if ((flags & FLAG_MATCH_BEFORE) != 0) {
                if (pos >= startLimit && (!needEndMatch || pos == startLimit)) {
                  boolean alreadyMatched = matched;
                  matched = true;
                  matchStart = longest && alreadyMatched ? Math.min(matchStart, pos) : pos;
                  ambiguous |= (flags & FLAG_MATCH_AFTER_DEFERRED) != 0;
                  if (!longest && !needEndMatch) {
                    return completeSearch(new SearchResult(true, matchStart, ambiguous), pos);
                  }
                }
              }
              boolean hasOnlyBeforeMatch =
                  (flags & (FLAG_MATCH_BEFORE | FLAG_MATCH_AFTER_DEFERRED)) == FLAG_MATCH_BEFORE;
              int prevPos = pos - 1;
              if (!hasOnlyBeforeMatch) {
                if (prevPos >= startLimit && (!needEndMatch || prevPos == startLimit)) {
                  boolean alreadyMatched = matched;
                  matched = true;
                  matchStart = longest && alreadyMatched ? Math.min(matchStart, prevPos) : prevPos;
                  ambiguous |= (flags & FLAG_MATCH_AFTER_DEFERRED) != 0;
                  if (!longest && !needEndMatch) {
                    return completeSearch(new SearchResult(true, matchStart, ambiguous), pos);
                  }
                }
              }
            }
          }
          sId = nsId;
          pos--;
        }
        s = offsetToState[sId];
      }

      if (pos <= scanLimit) {
        break;
      }
      if (hasPositionDependentTransitions && pos - 1 >= posDepThreshold) {
        break; // fall back to general loop for position-dependent context
      }

      if (WorkCounterConfig.ENABLED && maxInputUnits != Integer.MAX_VALUE) {
        WorkCounter.record();
      }
      int ch = text.asciiAt(pos - 1);
      if (ch < 0 || transitionDependsOnPosition(ch, pos - 1, posDepThreshold)) {
        break; // fall back
      }
      int cls = asciiClassMap[ch];
      State ns = s.next[cls];
      if (ns == null) {
        int effectivePrevPos = pos - 1;
        ns = transitionOrReset(s, cls, ch, text, effectivePrevPos, pos);
        if (ns == null) {
          return completeSearch(null, pos); // budget exceeded
        }
        transitions = this.transitions;
        offsetToState = this.offsetToState;
      }
      s = ns;
      if (s == deadState) {
        break;
      }
      if (s.isMatch()) {
        if ((s.flags & FLAG_MATCH_BEFORE) != 0) {
          if (pos >= startLimit && (!needEndMatch || pos == startLimit)) {
            boolean alreadyMatched = matched;
            matched = true;
            matchStart = longest && alreadyMatched ? Math.min(matchStart, pos) : pos;
            ambiguous |= (s.flags & FLAG_MATCH_AFTER_DEFERRED) != 0;
            if (!longest && !needEndMatch) {
              return completeSearch(new SearchResult(true, matchStart, ambiguous), pos);
            }
          }
        }
        boolean hasOnlyBeforeMatch =
            (s.flags & (FLAG_MATCH_BEFORE | FLAG_MATCH_AFTER_DEFERRED)) == FLAG_MATCH_BEFORE;
        int prevPos = pos - 1;
        if (!hasOnlyBeforeMatch) {
          if (prevPos >= startLimit && (!needEndMatch || prevPos == startLimit)) {
            boolean alreadyMatched = matched;
            matched = true;
            matchStart = longest && alreadyMatched ? Math.min(matchStart, prevPos) : prevPos;
            ambiguous |= (s.flags & FLAG_MATCH_AFTER_DEFERRED) != 0;
            if (!longest && !needEndMatch) {
              return completeSearch(new SearchResult(true, matchStart, ambiguous), pos);
            }
          }
        }
      }
      pos--;
    }

    if (s == deadState) {
      return completeSearch(new SearchResult(matched, matchStart, ambiguous), pos);
    }

    // General reverse loop
    while (pos >= startLimit) {
      if (pos <= scanLimit && pos > startLimit) {
        return completeSearch(new SearchResult(matched, matchStart, ambiguous, true), pos);
      }
      if (WorkCounterConfig.ENABLED) {
        WorkCounter.record();
      }
      int cp;
      int prevPos;
      int cls;
      if (pos > 0) {
        // Read the code point just before pos (scanning backward).
        int singleUnitCodePoint = text.singleUnitCodePointBefore(pos);
        if (singleUnitCodePoint >= 0) {
          cp = singleUnitCodePoint;
          prevPos = pos - 1;
          cls =
              singleUnitCodePoint < asciiClassMap.length
                  ? asciiClassMap[singleUnitCodePoint]
                  : classOf(singleUnitCodePoint);
        } else {
          long decoded = text.decodeBackward(pos);
          cp = InputScanner.codePoint(decoded);
          prevPos = InputScanner.position(decoded);
          if (pos > startLimit && prevPos < startLimit) {
            // Starting inside an encoded character leaves a lone UTF-16 low surrogate or UTF-8
            // continuation bytes. Forward decoding consumes each remaining unit separately, so
            // reverse decoding must do the same. At pos == startLimit, preserve the preceding
            // code point instead: it supplies context for leading assertions.
            prevPos = pos - 1;
            cp = text.codePointAt(prevPos);
          }
          cls = classOf(cp);
        }
      } else {
        // Reached the start limit — present end-of-text to the reversed DFA.
        cp = -1;
        prevPos = startLimit - 1;
        cls = numClasses - 1;
      }

      // Bypass cache for position-dependent transitions (same invariant as doSearch).
      int effectivePrevPos = Math.max(prevPos, startLimit);
      State ns;
      if ((hasSurrogateWordContext(cp)
              && !(text.isCodePointBoundary(pos) && text.isCodePointBoundary(effectivePrevPos)))
          || transitionDependsOnPosition(cp, effectivePrevPos, posDepThreshold)) {
        ns = computeNextOrReset(s, cp, text, effectivePrevPos, pos);
        if (ns == null) {
          return completeSearch(null, pos); // budget exceeded
        }
      } else {
        ns = s.next[cls];
        if (ns == null) {
          ns = transitionOrReset(s, cls, cp, text, effectivePrevPos, pos);
          if (ns == null) {
            return completeSearch(null, pos); // budget exceeded
          }
        }
      }
      s = ns;

      if (s == deadState) {
        break;
      }

      if (s.isMatch()) {
        if ((s.flags & FLAG_MATCH_BEFORE) != 0) {
          if (pos >= startLimit && (!needEndMatch || pos == startLimit)) {
            boolean alreadyMatched = matched;
            matched = true;
            matchStart = longest && alreadyMatched ? Math.min(matchStart, pos) : pos;
            ambiguous |= (s.flags & FLAG_MATCH_AFTER_DEFERRED) != 0;
            if (!longest && !needEndMatch) {
              return completeSearch(new SearchResult(true, matchStart, ambiguous), pos);
            }
          }
        }
        boolean hasOnlyBeforeMatch =
            (s.flags & (FLAG_MATCH_BEFORE | FLAG_MATCH_AFTER_DEFERRED)) == FLAG_MATCH_BEFORE;
        if (!hasOnlyBeforeMatch) {
          if (prevPos >= startLimit && (!needEndMatch || prevPos == startLimit)) {
            boolean alreadyMatched = matched;
            matched = true;
            matchStart = longest && alreadyMatched ? Math.min(matchStart, prevPos) : prevPos;
            ambiguous |= (s.flags & FLAG_MATCH_AFTER_DEFERRED) != 0;
            if (!longest && !needEndMatch) {
              return completeSearch(new SearchResult(true, matchStart, ambiguous), pos);
            }
          } else if (pos == startLimit && (s.flags & FLAG_MATCH_BEFORE_SHADOWED) != 0) {
            // The after-consume match starts left of startLimit, but the deferred match still
            // starts at startLimit, with the preceding character as its assertion context.
            boolean alreadyMatched = matched;
            matched = true;
            matchStart = longest && alreadyMatched ? Math.min(matchStart, pos) : pos;
            if (!longest && !needEndMatch) {
              return completeSearch(new SearchResult(true, matchStart, ambiguous), pos);
            }
          }
        }
      }

      if (pos <= startLimit) {
        break;
      }
      pos = prevPos;
    }
    return completeSearch(new SearchResult(matched, matchStart, ambiguous), pos);
  }

  // ---------------------------------------------------------------------------
  // Multi-match search (for PatternSet)
  // ---------------------------------------------------------------------------

  /**
   * Searches for all matching patterns in a multi-pattern program.
   *
   * <p>Unlike {@link #search}, this method does not stop at the first match. It processes the
   * entire text and collects the match IDs (from {@link Inst#arg}) of all MATCH instructions
   * reached. This is used by {@link PatternSet} to determine which patterns matched.
   *
   * @param prog the compiled multi-pattern program (built with HAVE_MATCH markers)
   * @param text the input text
   * @param anchored whether to anchor the search at the start
   * @return multi-match result, or {@code null} if the DFA exceeded its state budget
   */
  static ManyMatchResult searchMany(Prog prog, String text, boolean anchored) {
    return searchMany(prog, text, anchored, DEFAULT_MAX_STATES);
  }

  /** Multi-match search with explicit state budget. */
  static ManyMatchResult searchMany(Prog prog, String text, boolean anchored, int maxStates) {
    Dfa dfa = new Dfa(prog, maxStates, buildSetup(prog), true);
    return dfa.doSearchMany(text, anchored);
  }

  /**
   * Multi-match DFA search loop. Processes the entire text and collects all match IDs from match
   * states reached along the way.
   */
  ManyMatchResult doSearchMany(String text, boolean anchored) {
    return doSearchMany(new StringInputScanner(text), anchored);
  }

  ManyMatchResult doSearchMany(InputScanner text, boolean anchored) {
    graphemeContext = GraphemeSupport.Context.create(text, hasGraphemeSemantics);
    beginSearch(0);
    int pos = 0;
    int textLen = text.length();
    boolean needEndMatch = prog.anchorEnd();
    boolean dollarEnd = prog.dollarAnchorEnd();
    int trailingTermStart = dollarEnd ? trailingLineStart(text) : textLen;

    // Position-dependent threshold: same invariant as doSearch.
    int posDepThreshold = positionDependentThreshold(text);

    State s = startStateOrReset(text, 0, anchored, false);
    if (s == null) {
      return completeSearch(null, pos);
    }

    // Use a bitset to track which match IDs have been seen.
    BitSet seen = new BitSet();

    // Check if start state is already a match.
    if (s.isMatch()) {
      if (!needEndMatch
          || textLen == 0
          || (trailingTermStart < textLen && trailingTermStart == 0)) {
        for (int id : collectMatchIds(s.insts)) {
          seen.set(id);
        }
      }
    }

    if (s != deadState) {
      int[] transitions = this.transitions;
      State[] offsetToState = this.offsetToState;
      int[] asciiClassMap = this.asciiClassMap;
      // Fast path: scan forward through ASCII characters
      int sId = s.id * numClasses;
      while (pos < textLen) {
        if (hasPositionDependentTransitions && pos + 1 >= posDepThreshold) {
          break; // fall back to general loop for position-dependent context
        }
        int ch = text.asciiAt(pos);
        if (ch < 0 || transitionDependsOnPosition(ch, pos + 1, posDepThreshold)) {
          break; // fall back
        }
        int cls = asciiClassMap[ch];
        int nsId = transitions[sId + cls];
        if (nsId == 0) {
          s = offsetToState[sId];
          int effectiveNextPos = pos + 1;
          State ns = computeNext(s, ch, text, effectiveNextPos);
          if (ns == null) {
            // This loop is the only one that carries a state offset across iterations, and a
            // reset renumbers every state, so re-derive sId from the re-created state.
            if (!resetCache(pos)) {
              return completeSearch(null, pos); // budget exceeded
            }
            s = recreateAfterReset(s);
            if (s == null) {
              budgetExhaustedAfterReset();
              return completeSearch(null, pos); // budget exceeded
            }
            sId = s.id * numClasses;
            ns = computeNext(s, ch, text, effectiveNextPos);
            if (ns == null) {
              budgetExhaustedAfterReset();
              return completeSearch(null, pos); // budget exceeded
            }
          }
          addTransition(s, cls, ns);
          transitions = this.transitions;
          offsetToState = this.offsetToState;
          nsId = transitions[sId + cls];
        }
        if (nsId == 0) { // deadState
          break;
        }
        int realNsId;
        if (nsId < 0) {
          realNsId = -nsId;
          State ns = offsetToState[realNsId];
          int flags = ns.flags;
          int endPos =
              ((flags & (FLAG_MATCH_BEFORE | FLAG_MATCH_AFTER_DEFERRED)) == FLAG_MATCH_BEFORE)
                  ? pos
                  : pos + 1;
          if (!needEndMatch
              || endPos == textLen
              || (trailingTermStart < textLen && endPos == trailingTermStart)) {
            // Collect match IDs from the state's instructions.
            for (int id : collectMatchIds(ns.insts)) {
              seen.set(id);
            }
            if (ns.wordBoundaryMatchIds != null) {
              for (int id : ns.wordBoundaryMatchIds) {
                seen.set(id);
              }
            }
          }
        } else {
          realNsId = nsId;
        }
        sId = realNsId;
        pos++;
      }
      s = offsetToState[sId];

      // General loop
      while (pos <= textLen) {
        int cp;
        int nextPos;
        int cls;
        if (pos < textLen) {
          int singleUnitCodePoint = text.singleUnitCodePointAt(pos);
          if (singleUnitCodePoint >= 0) {
            cp = singleUnitCodePoint;
            nextPos = pos + 1;
            cls =
                singleUnitCodePoint < asciiClassMap.length
                    ? asciiClassMap[singleUnitCodePoint]
                    : classOf(singleUnitCodePoint);
          } else {
            long decoded = text.decodeForward(pos);
            cp = InputScanner.codePoint(decoded);
            nextPos = InputScanner.position(decoded);
            cls = classOf(cp);
          }
        } else {
          cp = -1;
          nextPos = textLen + 1;
          cls = numClasses - 1;
        }

        // Bypass cache for position-dependent transitions (same invariant as doSearch).
        int effectiveNextPos = Math.min(nextPos, textLen);
        State ns;
        if ((hasSurrogateWordContext(cp) && !text.isCodePointBoundary(pos))
            || transitionDependsOnPosition(cp, effectiveNextPos, posDepThreshold)) {
          ns = computeNextOrReset(s, cp, text, effectiveNextPos, pos);
          if (ns == null) {
            return completeSearch(null, pos); // budget exceeded
          }
        } else {
          ns = s.next[cls];
          if (ns == null) {
            ns = transitionOrReset(s, cls, cp, text, effectiveNextPos, pos);
            if (ns == null) {
              return completeSearch(null, pos); // budget exceeded
            }
          }
        }
        s = ns;

        if (s == deadState) {
          break;
        }

        if (s.isMatch()) {
          int endPos =
              ((s.flags & (FLAG_MATCH_BEFORE | FLAG_MATCH_AFTER_DEFERRED)) == FLAG_MATCH_BEFORE)
                  ? pos
                  : Math.min(nextPos, textLen);
          if (!needEndMatch
              || endPos == textLen
              || (trailingTermStart < textLen && endPos == trailingTermStart)) {
            // Collect match IDs from the state's instructions.
            for (int id : collectMatchIds(s.insts)) {
              seen.set(id);
            }
            // Also collect match IDs from word-boundary expansion (if any).
            if (s.wordBoundaryMatchIds != null) {
              for (int id : s.wordBoundaryMatchIds) {
                seen.set(id);
              }
            }
          }
        }

        if (pos >= textLen) {
          break;
        }
        pos = nextPos;
      }
    }

    boolean matched = !seen.isEmpty();
    int[] matchIds = seen.stream().toArray();
    return completeSearch(new ManyMatchResult(matched, matchIds), pos);
  }

  private boolean isMatchPrimary(int[] expanded) {
    int firstMatch = -1;
    int firstActive = -1;
    for (int i = 0; i < expanded.length; i++) {
      int op = prog.inst(expanded[i]).opCode;
      if (op == InstOp.OP_MATCH) {
        if (firstMatch == -1) {
          firstMatch = i;
        }
      } else if (op == InstOp.OP_CHAR_RANGE || op == InstOp.OP_CHAR_CLASS) {
        if (firstActive == -1) {
          firstActive = i;
        }
      }
    }
    if (firstMatch == -1) {
      return false;
    }
    if (firstActive == -1) {
      return true;
    }
    return firstMatch < firstActive;
  }

  private boolean canStopAtFirstMatch(State s, InputScanner text, int pos, boolean needEndMatch) {
    if (!needEndMatch) {
      return s.isHighestPriorityMatch;
    }
    int cp = codePointAt(text, pos);
    for (int id : s.insts) {
      Inst inst = prog.inst(id);
      switch (inst.opCode) {
        case InstOp.OP_MATCH -> {
          return true;
        }
        case InstOp.OP_CHAR_RANGE -> {
          if (cp >= 0 && inst.matchesChar(cp)) {
            return false;
          }
        }
        case InstOp.OP_CHAR_CLASS -> {
          if (cp >= 0 && inst.matchesCharClass(cp)) {
            return false;
          }
        }
        default -> {}
      }
    }
    return false;
  }

  private static int codePointAt(InputScanner text, int pos) {
    if (pos >= text.length()) {
      return -1;
    }
    return text.codePointAt(pos);
  }

  private static boolean isRequiredEndMatch(
      int pos, boolean needEndMatch, int textLen, int trailingTermStart) {
    return !needEndMatch
        || pos == textLen
        || (trailingTermStart < textLen && pos == trailingTermStart);
  }

  private Dfa() {
    throw new AssertionError("non-instantiable");
  }
}
