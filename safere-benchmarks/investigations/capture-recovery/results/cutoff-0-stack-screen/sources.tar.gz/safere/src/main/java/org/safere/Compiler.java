// This file is part of a Java port of RE2 (https://github.com/google/re2).
// Original RE2 code is Copyright (c) 2009 The RE2 Authors.
// Portions derived from RE2/J (https://github.com/google/re2j),
// Copyright (c) 2009 The Go Authors.
// Modifications and Java port Copyright (c) 2026 Eddie Aftandilian.
// Licensed under the BSD 3-Clause License (see LICENSE file).

package org.safere;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/**
 * Compiles a {@link Regexp} AST into a {@link Prog} (bytecode program) via Thompson NFA
 * construction. Each node in the AST is compiled into a {@link Frag} (instruction fragment) and
 * fragments are combined using standard NFA construction rules.
 *
 * <p>This is a port of RE2's {@code compile.cc}, adapted for Java's Unicode code point model
 * (instead of UTF-8 byte ranges).
 *
 * <p>Usage:
 *
 * <pre>
 *   Regexp re = Parser.parse("a(b|c)*d", flags);
 *   Prog prog = Compiler.compile(re);
 * </pre>
 */
final class Compiler extends Walker<Compiler.Frag> {

  /** Maximum number of instructions allowed by default. */
  private static final int DEFAULT_MAX_INST = 1_000_000;

  private final Prog prog;
  private boolean failed;
  private boolean reversed;
  private boolean forDfa;

  private final int maxInst;
  private int nextLoopReg;

  private Compiler() {
    this(DEFAULT_MAX_INST);
  }

  private Compiler(int maxInst) {
    this.prog = new Prog();
    this.maxInst = maxInst;
    // Instruction 0 is always the fail instruction (sentinel for PatchList).
    int fail = prog.allocInst();
    prog.mutableInst(fail).initFail();
  }

  /**
   * Compiles the given regexp into a program.
   *
   * @param re the regexp to compile
   * @return the compiled program, or null if compilation fails
   */
  static Prog compile(Regexp re) {
    return compile(prepare(re), false, false);
  }

  /**
   * Compiles the given regexp into a program.
   *
   * @param re the regexp to compile
   * @param reversed if true, compile for backward matching
   * @return the compiled program, or null if compilation fails
   */
  static Prog compile(Regexp re, boolean reversed) {
    return compile(prepare(re), reversed, false);
  }

  static Prog compileForDfa(Regexp re) {
    return compile(prepare(re), false, true);
  }

  static Prog compileForDfa(Regexp re, boolean reversed) {
    return compile(prepare(re), reversed, true);
  }

  /**
   * Direction-independent preparation shared by capture-aware and DFA compilers.
   *
   * <p>The prepared tree is encapsulated and read-only during compilation. Instruction arrays,
   * patch lists, and loop registers belong to each individual compilation. Pattern construction
   * releases this preparation after building the programs needed at construction time.
   */
  static final class Prepared {
    private final Regexp root;
    private final Regexp simplifiedSource;
    private final int numCaptures;
    private final boolean anchorStart;
    private final boolean anchorEnd;
    private final boolean dollarEnd;
    private final boolean dollarUnixLines;

    private Prepared(
        Regexp root,
        Regexp simplifiedSource,
        int numCaptures,
        boolean anchorStart,
        boolean anchorEnd,
        boolean dollarEnd,
        boolean dollarUnixLines) {
      this.root = root;
      this.simplifiedSource = simplifiedSource;
      this.numCaptures = numCaptures;
      this.anchorStart = anchorStart;
      this.anchorEnd = anchorEnd;
      this.dollarEnd = dollarEnd;
      this.dollarUnixLines = dollarUnixLines;
    }

    /** Returns {@code Simplifier.simplify(source)}, before anchor stripping. */
    Regexp simplifiedSource() {
      return simplifiedSource;
    }
  }

  /** Simplifies a source AST once, preserving capture writes in every repeat copy. */
  static Prepared prepare(Regexp re) {
    int numCaptures = maxCapture(re) + 1;
    // Repeat copies share source capture identities. Later accepted copies must still write
    // their captures; retaining an earlier value is the engine's omission/rollback behavior.
    Regexp sre = Simplifier.simplify(re);
    if (sre == null) {
      return null;
    }

    // Detect anchoring, stripping the anchor nodes.
    boolean isAnchorStart = isAnchorStart(sre);
    Regexp stripped = stripAnchorStart(sre);
    boolean isAnchorEnd = isAnchorEnd(stripped);
    boolean isDollarEnd = isAnchorEnd && isDollarAnchorEnd(stripped);
    boolean dollarUnixLines = isDollarEnd && isUnixDollarAnchorEnd(stripped);
    stripped = stripAnchorEnd(stripped);
    return new Prepared(
        stripped, sre, numCaptures, isAnchorStart, isAnchorEnd, isDollarEnd, dollarUnixLines);
  }

  static Prog compile(Prepared prepared, boolean reversed) {
    return compile(prepared, reversed, false);
  }

  static Prog compileForDfa(Prepared prepared, boolean reversed) {
    return compile(prepared, reversed, true);
  }

  private static Prog compile(Prepared prepared, boolean reversed, boolean forDfa) {
    if (prepared == null) {
      return null;
    }
    Compiler c = new Compiler();
    c.reversed = reversed;
    c.forDfa = forDfa;

    // Walk the AST to produce fragments.
    Frag all = c.walkExponential(prepared.root, Frag.NO_MATCH, 2 * c.maxInst);
    if (c.failed) {
      return null;
    }

    // Append Match(0).
    c.reversed = false;
    all = c.cat(all, c.match(0));
    if (c.failed) {
      return null;
    }

    c.prog.setReversed(reversed);
    if (reversed) {
      c.prog.setAnchorStart(prepared.anchorEnd);
      c.prog.setAnchorEnd(prepared.anchorStart);
    } else {
      c.prog.setAnchorStart(prepared.anchorStart);
      c.prog.setAnchorEnd(prepared.anchorEnd);
      c.prog.setDollarAnchorEnd(prepared.dollarEnd);
      c.prog.setDollarAnchorUnixLines(prepared.dollarUnixLines);
    }

    c.prog.setStart(all.begin);

    if (!c.prog.anchorStart()) {
      // Prepend .*? loop for unanchored matching.
      all = c.cat(c.dotStar(), all);
    }
    c.prog.setStartUnanchored(all.begin);

    // Freeze the instruction list into a flat array for fast indexed access.
    c.prog.freeze();

    c.prog.setNumCaptures(prepared.numCaptures);
    c.prog.setNumLoopRegs(c.nextLoopReg);

    return c.prog;
  }

  private static int maxCapture(Regexp re) {
    int max = 0;
    ArrayDeque<Regexp> stack = new ArrayDeque<>();
    stack.push(re);
    while (!stack.isEmpty()) {
      Regexp node = stack.pop();
      if (node.op == RegexpOp.CAPTURE && node.cap > max) {
        max = node.cap;
      }
      if (node.subs != null) {
        for (Regexp sub : node.subs) {
          stack.push(sub);
        }
      }
    }
    return max;
  }

  // ---------------------------------------------------------------------------
  // Anchor detection — approximate, like RE2's IsAnchorStart/IsAnchorEnd
  // ---------------------------------------------------------------------------

  static boolean isAnchorStart(Regexp re) {
    return isAnchorStartImpl(re, 0);
  }

  private static boolean isAnchorStartImpl(Regexp re, int depth) {
    if (re == null || depth >= 4) {
      return false;
    }
    return switch (re.op) {
      case BEGIN_TEXT -> true;
      case CONCAT -> re.nsub() > 0 && isAnchorStartImpl(re.subs.getFirst(), depth + 1);
      case NON_CAPTURE, CAPTURE -> isAnchorStartImpl(re.sub(), depth + 1);
      default -> false;
    };
  }

  static Regexp stripAnchorStart(Regexp re) {
    return stripAnchorStartImpl(re, 0);
  }

  private static Regexp stripAnchorStartImpl(Regexp re, int depth) {
    if (re == null || depth >= 4) {
      return re;
    }
    return switch (re.op) {
      case BEGIN_TEXT -> Regexp.emptyMatch(re.flags);
      case CONCAT -> {
        if (re.nsub() > 0 && isAnchorStartImpl(re.subs.getFirst(), depth + 1)) {
          List<Regexp> newSubs = new ArrayList<>(re.subs);
          newSubs.set(0, stripAnchorStartImpl(re.subs.getFirst(), depth + 1));
          yield Regexp.concat(newSubs, re.flags);
        }
        yield re;
      }
      case NON_CAPTURE -> {
        if (isAnchorStartImpl(re.sub(), depth + 1)) {
          yield Regexp.nonCapture(stripAnchorStartImpl(re.sub(), depth + 1), re.flags);
        }
        yield re;
      }
      case CAPTURE -> {
        if (isAnchorStartImpl(re.sub(), depth + 1)) {
          yield Regexp.capture(
              stripAnchorStartImpl(re.sub(), depth + 1), re.flags, re.cap, re.name);
        }
        yield re;
      }
      default -> re;
    };
  }

  static boolean isAnchorEnd(Regexp re) {
    return isAnchorEndImpl(re, 0);
  }

  /**
   * Returns true if the trailing end anchor is {@code $} (WAS_DOLLAR), meaning the match may end
   * before a trailing newline. Must only be called when {@link #isAnchorEnd} is true.
   */
  static boolean isDollarAnchorEnd(Regexp re) {
    return isDollarAnchorEndImpl(re, 0);
  }

  private static boolean isUnixDollarAnchorEnd(Regexp re) {
    // Follow exactly the bounded path used by end-anchor detection and stripping.
    for (int depth = 0; re != null && depth < 4; depth++) {
      switch (re.op) {
        case END_TEXT -> {
          return (re.flags & ParseFlags.UNIX_LINES) != 0;
        }
        case CONCAT -> re = re.nsub() == 0 ? null : re.subs.getLast();
        case NON_CAPTURE, CAPTURE -> re = re.sub();
        default -> {
          return false;
        }
      }
    }
    return false;
  }

  private static boolean isDollarAnchorEndImpl(Regexp re, int depth) {
    if (re == null || depth >= 4) {
      return false;
    }
    return switch (re.op) {
      case END_TEXT -> (re.flags & ParseFlags.WAS_DOLLAR) != 0;
      case CONCAT -> re.nsub() > 0 && isDollarAnchorEndImpl(re.subs.get(re.nsub() - 1), depth + 1);
      case NON_CAPTURE, CAPTURE -> isDollarAnchorEndImpl(re.sub(), depth + 1);
      default -> false;
    };
  }

  private static boolean isAnchorEndImpl(Regexp re, int depth) {
    if (re == null || depth >= 4) {
      return false;
    }
    return switch (re.op) {
      case END_TEXT -> true;
      case CONCAT -> re.nsub() > 0 && isAnchorEndImpl(re.subs.get(re.nsub() - 1), depth + 1);
      case NON_CAPTURE, CAPTURE -> isAnchorEndImpl(re.sub(), depth + 1);
      default -> false;
    };
  }

  static Regexp stripAnchorEnd(Regexp re) {
    return stripAnchorEndImpl(re, 0);
  }

  private static Regexp stripAnchorEndImpl(Regexp re, int depth) {
    if (re == null || depth >= 4) {
      return re;
    }
    return switch (re.op) {
      case END_TEXT -> Regexp.emptyMatch(re.flags);
      case CONCAT -> {
        if (re.nsub() > 0 && isAnchorEndImpl(re.subs.get(re.nsub() - 1), depth + 1)) {
          List<Regexp> newSubs = new ArrayList<>(re.subs);
          int last = re.nsub() - 1;
          newSubs.set(last, stripAnchorEndImpl(re.subs.get(last), depth + 1));
          yield Regexp.concat(newSubs, re.flags);
        }
        yield re;
      }
      case NON_CAPTURE -> {
        if (isAnchorEndImpl(re.sub(), depth + 1)) {
          yield Regexp.nonCapture(stripAnchorEndImpl(re.sub(), depth + 1), re.flags);
        }
        yield re;
      }
      case CAPTURE -> {
        if (isAnchorEndImpl(re.sub(), depth + 1)) {
          yield Regexp.capture(stripAnchorEndImpl(re.sub(), depth + 1), re.flags, re.cap, re.name);
        }
        yield re;
      }
      default -> re;
    };
  }

  // ---------------------------------------------------------------------------
  // PatchList — linked list threaded through unused instruction out fields
  // ---------------------------------------------------------------------------

  /**
   * A patch list is a linked list of instruction output fields that need to be filled in
   * ("patched") to point to the next instruction. The list is threaded through the unused out/out1
   * fields of the instructions themselves.
   *
   * <p>A patch list is packed into a primitive {@code long}: upper 32 bits are {@code head}, lower
   * 32 bits are {@code tail}.
   */
  private static final class PatchList {

    static final long EMPTY = 0L;

    static long mk(int encoded) {
      return ((long) encoded << 32) | (encoded & 0xFFFFFFFFL);
    }

    static int head(long l) {
      return (int) (l >>> 32);
    }

    static int tail(long l) {
      return (int) l;
    }

    static void patch(Prog prog, long l, int target) {
      int current = head(l);
      while (current != 0) {
        Inst ip = prog.mutableInst(current >> 1);
        if ((current & 1) != 0) {
          current = ip.out1;
          ip.out1 = target;
        } else {
          current = ip.out;
          ip.out = target;
        }
      }
    }

    static long append(Prog prog, long l1, long l2) {
      int h1 = head(l1);
      if (h1 == 0) {
        return l2;
      }
      int h2 = head(l2);
      if (h2 == 0) {
        return l1;
      }
      int t1 = tail(l1);
      Inst ip = prog.mutableInst(t1 >> 1);
      if ((t1 & 1) != 0) {
        ip.out1 = h2;
      } else {
        ip.out = h2;
      }
      int t2 = tail(l2);
      return ((long) h1 << 32) | (t2 & 0xFFFFFFFFL);
    }
  }

  // ---------------------------------------------------------------------------
  // Frag — compiled program fragment
  // ---------------------------------------------------------------------------

  /**
   * A compiled program fragment with a beginning instruction, a patch list of unfilled outputs, and
   * a nullable flag.
   */
  record Frag(int begin, long end, boolean nullable) {
    static final Frag NO_MATCH = new Frag(0, PatchList.EMPTY, false);
  }

  private static boolean isNoMatch(Frag f) {
    return f.begin == 0;
  }

  // ---------------------------------------------------------------------------
  // Fragment combinators
  // ---------------------------------------------------------------------------

  private int allocInst() {
    if (failed || prog.size() >= maxInst) {
      failed = true;
      return -1;
    }
    return prog.allocInst();
  }

  private Frag cat(Frag a, Frag b) {
    if (isNoMatch(a) || isNoMatch(b)) {
      return Frag.NO_MATCH;
    }

    // Elide no-op.
    Inst begin = prog.mutableInst(a.begin);
    if (begin.op == InstOp.NOP && PatchList.head(a.end) == (a.begin << 1) && begin.out == 0) {
      PatchList.patch(prog, a.end, b.begin);
      return b;
    }

    if (reversed) {
      PatchList.patch(prog, b.end, a.begin);
      return new Frag(b.begin, a.end, b.nullable && a.nullable);
    }

    PatchList.patch(prog, a.end, b.begin);
    return new Frag(a.begin, b.end, a.nullable && b.nullable);
  }

  private Frag alt(Frag a, Frag b) {
    if (isNoMatch(a)) {
      return b;
    }
    if (isNoMatch(b)) {
      return a;
    }

    int id = allocInst();
    if (id < 0) {
      return Frag.NO_MATCH;
    }

    prog.mutableInst(id).initAlt(a.begin, b.begin);
    return new Frag(id, PatchList.append(prog, a.end, b.end), a.nullable || b.nullable);
  }

  private Frag plus(Frag a, boolean nongreedy) {
    // When the body is nullable (can match zero characters), insert a PROGRESS_CHECK at the
    // loop entry to implement the JDK "zero-width match breaks repetition" rule.
    //
    // Fresh entry resets the loop register; the body end loops back to PROGRESS_CHECK directly.
    // An enclosing repetition can re-enter this loop at the same position where it last exited,
    // which must not be mistaken for a zero-width iteration of this loop.
    // On progress, PROGRESS_CHECK acts like ALT(body, exit) with greediness preference.
    // On zero-width, PROGRESS_CHECK forces exit only (terminates the loop).
    if (a.nullable && !forDfa) {
      int pcId = allocInst();
      if (pcId < 0) {
        return Frag.NO_MATCH;
      }
      int entryId = allocInst();
      if (entryId < 0) {
        return Frag.NO_MATCH;
      }
      int loopReg = nextLoopReg++;
      prog.mutableInst(entryId).initLoopEnter(loopReg, pcId);
      prog.mutableInst(pcId).initProgressCheck(loopReg, a.begin, 0, nongreedy);
      long pl = PatchList.mk((pcId << 1) | 1); // patch out1 (exit)

      // Patch the body end to loop back to pcId.
      PatchList.patch(prog, a.end, pcId);
      return new Frag(entryId, pl, true);
    }

    int id = allocInst();
    if (id < 0) {
      return Frag.NO_MATCH;
    }
    long pl;
    if (nongreedy) {
      prog.mutableInst(id).initAlt(0, a.begin);
      pl = PatchList.mk(id << 1);
    } else {
      prog.mutableInst(id).initAlt(a.begin, 0);
      pl = PatchList.mk((id << 1) | 1);
    }
    PatchList.patch(prog, a.end, id);
    return new Frag(a.begin, pl, a.nullable);
  }

  private Frag star(Frag a, boolean nongreedy) {
    if (a.nullable) {
      return quest(plus(a, nongreedy), nongreedy);
    }

    int id = allocInst();
    if (id < 0) {
      return Frag.NO_MATCH;
    }
    long pl;
    if (nongreedy) {
      prog.mutableInst(id).initAlt(0, a.begin);
      pl = PatchList.mk(id << 1);
    } else {
      prog.mutableInst(id).initAlt(a.begin, 0);
      pl = PatchList.mk((id << 1) | 1);
    }
    PatchList.patch(prog, a.end, id);
    return new Frag(id, pl, true);
  }

  private Frag quest(Frag a, boolean nongreedy) {
    if (isNoMatch(a)) {
      return nop();
    }
    int id = allocInst();
    if (id < 0) {
      return Frag.NO_MATCH;
    }
    long pl;
    if (nongreedy) {
      prog.mutableInst(id).initAlt(0, a.begin);
      pl = PatchList.mk(id << 1);
    } else {
      prog.mutableInst(id).initAlt(a.begin, 0);
      pl = PatchList.mk((id << 1) | 1);
    }
    return new Frag(id, PatchList.append(prog, pl, a.end), true);
  }

  /** Compiles the copies of a nullable finite repetition as one minimum-respecting invocation. */
  private Frag finiteRepeat(List<Frag> copies, int minimum, boolean nongreedy) {
    int maximum = copies.size();
    if (forDfa) {
      // Unguarded copies preserve full-match existence, but not ordered paths or captures.
      // matches() can fix group zero to the whole region and defer guarded capture extraction;
      // prefix/search matching uses these copies only as a rejection filter.
      Frag suffix = quest(copies.get(maximum - 1), nongreedy);
      for (int i = maximum - 2; i >= minimum; i--) {
        suffix = quest(cat(copies.get(i), suffix), nongreedy);
      }
      for (int i = minimum - 1; i >= 0; i--) {
        suffix = cat(copies.get(i), suffix);
      }
      return suffix;
    }

    int first = Math.max(0, minimum - 1);
    int loopReg = nextLoopReg++;
    long exits = copies.get(maximum - 1).end;
    int firstCheck = 0;
    for (int i = first; i < maximum; i++) {
      int check = allocInst();
      if (check < 0) {
        return Frag.NO_MATCH;
      }
      prog.mutableInst(check).initProgressCheck(loopReg, copies.get(i).begin, 0, nongreedy);
      exits = PatchList.append(prog, exits, PatchList.mk((check << 1) | 1));
      if (i == first) {
        firstCheck = check;
      } else {
        PatchList.patch(prog, copies.get(i - 1).end, check);
      }
    }
    int entry = allocInst();
    if (entry < 0) {
      return Frag.NO_MATCH;
    }
    prog.mutableInst(entry).initLoopEnter(loopReg, firstCheck);
    Frag suffix = new Frag(entry, exits, true);
    if (minimum == 0) {
      return quest(suffix, nongreedy);
    }
    for (int i = first - 1; i >= 0; i--) {
      suffix = cat(copies.get(i), suffix);
    }
    return suffix;
  }

  private Frag charRange(int lo, int hi, boolean foldCase) {
    int id = allocInst();
    if (id < 0) {
      return Frag.NO_MATCH;
    }
    prog.mutableInst(id).initCharRange(lo, hi, foldCase, 0);
    return new Frag(id, PatchList.mk(id << 1), false);
  }

  private Frag graphemeCluster() {
    int id = allocInst();
    if (id < 0) {
      return Frag.NO_MATCH;
    }
    prog.mutableInst(id).initGraphemeCluster(0);
    return new Frag(id, PatchList.mk(id << 1), false);
  }

  private Frag nop() {
    int id = allocInst();
    if (id < 0) {
      return Frag.NO_MATCH;
    }
    prog.mutableInst(id).initNop(0);
    return new Frag(id, PatchList.mk(id << 1), true);
  }

  private Frag match(int matchId) {
    int id = allocInst();
    if (id < 0) {
      return Frag.NO_MATCH;
    }
    prog.mutableInst(id).initMatch(matchId);
    return new Frag(id, PatchList.EMPTY, false);
  }

  private Frag emptyWidth(int emptyFlags) {
    int id = allocInst();
    if (id < 0) {
      return Frag.NO_MATCH;
    }
    prog.mutableInst(id).initEmptyWidth(emptyFlags, 0);
    return new Frag(id, PatchList.mk(id << 1), true);
  }

  private Frag capture(Frag a, int cap) {
    if (isNoMatch(a)) {
      return Frag.NO_MATCH;
    }
    // Need two instructions: one for capture-start, one for capture-end.
    int id = allocInst();
    if (id < 0) {
      return Frag.NO_MATCH;
    }
    int id2 = allocInst();
    if (id2 < 0) {
      return Frag.NO_MATCH;
    }
    prog.mutableInst(id).initCapture(2 * cap, a.begin);
    prog.mutableInst(id2).initCapture(2 * cap + 1, 0);
    PatchList.patch(prog, a.end, id2);
    return new Frag(id, PatchList.mk(id2 << 1), a.nullable);
  }

  private Frag literal(int rune, int flags) {
    boolean foldCase = (flags & ParseFlags.FOLD_CASE) != 0;
    if (foldCase && (flags & ParseFlags.UNICODE_CASE) == 0) {
      if (isAsciiLetter(rune)) {
        // Parser keeps these as folded literals so literal/prefix accelerators can see them.
        // Lower to an explicit ASCII class here to avoid Unicode simple-fold matching.
        return asciiFoldedLiteral(rune);
      }
      foldCase = false;
    }
    // In our code-point model, a literal is just a single CHAR_RANGE.
    return charRange(rune, rune, foldCase);
  }

  private Frag asciiFoldedLiteral(int rune) {
    int lower = Ascii.toLowerCase(rune);
    int upper = Ascii.toUpperCase(rune);
    int id = allocInst();
    if (id < 0) {
      return Frag.NO_MATCH;
    }
    prog.mutableInst(id).initCharClass(0, new int[] {upper, upper, lower, lower});
    return new Frag(id, PatchList.mk(id << 1), false);
  }

  private Frag literalString(int[] runes, int flags) {
    if (runes == null || runes.length == 0) {
      return nop();
    }
    if (runes.length == 1) {
      return literal(runes[0], flags);
    }
    Frag first = literal(runes[0], flags);
    if (isNoMatch(first)) {
      return Frag.NO_MATCH;
    }
    Frag current = first;
    for (int i = 1; i < runes.length; i++) {
      Frag next = literal(runes[i], flags);
      if (isNoMatch(next)) {
        return Frag.NO_MATCH;
      }
      current = cat(current, next);
    }
    return current;
  }

  private static boolean isAsciiLetter(int rune) {
    return Ascii.isAlpha(rune);
  }

  /** Compiles an "any code point" fragment. */
  private Frag anyCodePoint() {
    return charRange(0, Utils.MAX_RUNE, false);
  }

  /**
   * Creates a {@code .*?} fragment for unanchored matching. The DotStar loops over any code point
   * (non-greedy).
   */
  private Frag dotStar() {
    return star(anyCodePoint(), true);
  }

  // ---------------------------------------------------------------------------
  // Walker overrides
  // ---------------------------------------------------------------------------

  @Override
  protected int repeatVisits(Regexp re) {
    return re.max;
  }

  @Override
  protected Frag preVisit(Regexp re, Frag parentArg, boolean[] stop) {
    if (failed) {
      stop[0] = true;
    }
    return Frag.NO_MATCH;
  }

  @Override
  protected Frag postVisit(Regexp re, Frag parentArg, Frag preArg, List<Frag> childArgs) {
    if (failed) {
      return Frag.NO_MATCH;
    }

    return switch (re.op) {
      case REPEAT -> finiteRepeat(childArgs, re.min, re.nonGreedy());

      case NO_MATCH -> Frag.NO_MATCH;

      case EMPTY_MATCH -> nop();

      case HAVE_MATCH -> match(re.matchId);

      case CONCAT -> {
        Frag f = childArgs.get(0);
        for (int i = 1; i < childArgs.size(); i++) {
          f = cat(f, childArgs.get(i));
        }
        yield f;
      }

      case ALTERNATE -> {
        Frag f = childArgs.get(0);
        for (int i = 1; i < childArgs.size(); i++) {
          f = alt(f, childArgs.get(i));
        }
        yield f;
      }

      case NON_CAPTURE -> childArgs.get(0);

      case STAR -> star(childArgs.get(0), re.nonGreedy());

      case PLUS -> plus(childArgs.get(0), re.nonGreedy());

      case QUEST -> quest(childArgs.get(0), re.nonGreedy());

      case LITERAL -> literal(re.rune, re.flags);

      case LITERAL_STRING -> literalString(re.runes, re.flags);

      case ANY_CHAR -> anyCodePoint();

      case GRAPHEME_CLUSTER -> graphemeCluster();

      case CHAR_CLASS -> compileCharClass(re);

      case CAPTURE -> {
        if (re.cap < 0) {
          yield childArgs.get(0);
        }
        yield capture(childArgs.get(0), re.cap);
      }

      case BEGIN_LINE ->
          emptyWidth(
              (re.flags & ParseFlags.UNIX_LINES) != 0
                  ? (reversed ? EmptyOp.UNIX_END_LINE : EmptyOp.UNIX_BEGIN_LINE)
                  : (reversed ? EmptyOp.END_LINE : EmptyOp.BEGIN_LINE));

      case END_LINE ->
          emptyWidth(
              (re.flags & ParseFlags.UNIX_LINES) != 0
                  ? (reversed ? EmptyOp.UNIX_BEGIN_LINE : EmptyOp.UNIX_END_LINE)
                  : (reversed ? EmptyOp.BEGIN_LINE : EmptyOp.END_LINE));

      case BEGIN_TEXT -> emptyWidth(reversed ? EmptyOp.END_TEXT : EmptyOp.BEGIN_TEXT);

      case END_TEXT -> {
        if ((re.flags & ParseFlags.WAS_DOLLAR) != 0) {
          // Keep the assertion's line mode and position semantics in either scan direction.
          yield emptyWidth(
              (re.flags & ParseFlags.UNIX_LINES) != 0
                  ? EmptyOp.UNIX_DOLLAR_END
                  : EmptyOp.DOLLAR_END);
        }
        yield emptyWidth(reversed ? EmptyOp.BEGIN_TEXT : EmptyOp.END_TEXT);
      }

      case WORD_BOUNDARY -> {
        if ((re.flags & ParseFlags.UNICODE_CHAR_CLASS) != 0) {
          yield emptyWidth(EmptyOp.UNICODE_WORD_BOUNDARY);
        }
        yield emptyWidth(EmptyOp.WORD_BOUNDARY);
      }

      case NO_WORD_BOUNDARY -> {
        if ((re.flags & ParseFlags.UNICODE_CHAR_CLASS) != 0) {
          yield emptyWidth(EmptyOp.UNICODE_NON_WORD_BOUNDARY);
        }
        yield emptyWidth(EmptyOp.NON_WORD_BOUNDARY);
      }

      case GRAPHEME_CLUSTER_BOUNDARY -> emptyWidth(EmptyOp.EXPLICIT_GRAPHEME_CLUSTER_BOUNDARY);

      default -> {
        failed = true;
        yield Frag.NO_MATCH;
      }
    };
  }

  @Override
  protected Frag shortVisit(Regexp re, Frag parentArg) {
    failed = true;
    return Frag.NO_MATCH;
  }

  // ---------------------------------------------------------------------------
  // Character class compilation
  // ---------------------------------------------------------------------------

  private Frag compileCharClass(Regexp re) {
    CharClass cc = re.charClass;
    if (cc == null || cc.isEmpty()) {
      return Frag.NO_MATCH;
    }

    int numRanges = cc.numRanges();

    // Single range: use a simple CHAR_RANGE instruction (no ALT overhead).
    if (numRanges == 1) {
      return charRange(cc.lo(0), cc.hi(0), false);
    }

    // Multi-range: emit a single CHAR_CLASS instruction with all ranges and an ASCII bitmap.
    int[] ranges = new int[numRanges * 2];
    for (int i = 0; i < numRanges; i++) {
      ranges[i * 2] = cc.lo(i);
      ranges[i * 2 + 1] = cc.hi(i);
    }
    int id = allocInst();
    if (id < 0) {
      return Frag.NO_MATCH;
    }
    prog.mutableInst(id).initCharClass(0, ranges);
    return new Frag(id, PatchList.mk(id << 1), false);
  }
}
