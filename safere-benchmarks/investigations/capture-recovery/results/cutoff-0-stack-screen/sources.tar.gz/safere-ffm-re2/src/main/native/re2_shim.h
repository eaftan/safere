// Copyright (c) 2025 Eddie Aftandilian. Licensed under the MIT License.
// See LICENSE file in the project root for details.

// Thin C wrapper around C++ RE2 for use with Java FFM.
// All functions use C linkage so FFM can call them without C++ name mangling.

#ifndef RE2_SHIM_H_
#define RE2_SHIM_H_

#include <stddef.h>
#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// Opaque handle to a compiled RE2 pattern.
typedef struct re2_pattern re2_pattern_t;

// Compile a UTF-8 pattern. Returns an opaque handle.
// The caller must call re2_free() when done.
re2_pattern_t* re2_compile(const char* pattern, int pattern_len);

// Compile with case-insensitive matching.
re2_pattern_t* re2_compile_case_insensitive(const char* pattern,
                                            int pattern_len);

// Free a compiled pattern.
void re2_free(re2_pattern_t* p);

// Returns true if the pattern compiled successfully.
bool re2_ok(const re2_pattern_t* p);

// Returns the error message (empty string if ok). The returned pointer is valid
// until re2_free() is called.
const char* re2_error(const re2_pattern_t* p);

// Returns the number of capturing groups in the pattern.
int re2_num_capturing_groups(const re2_pattern_t* p);

// Match within an opaque region, whose boundaries are anchor boundaries.
// region_start, region_end and startpos are absolute UTF-8 byte offsets.
// anchor is 0 (unanchored), 1 (start), or 2 (both). Capture offsets are absolute
// in text, laid out as [start0, end0, start1, end1, ...], with -1 for absent
// groups. nmatches excludes group 0; matches_out needs 2*(nmatches+1) ints.
// A single RE2::Match produces the boolean result and requested captures.
bool re2_match(const re2_pattern_t* p, const char* text, int text_len,
               int region_start, int region_end, int startpos, int anchor,
               int32_t* matches_out, int nmatches);

// Finds all matches in the text. Writes start/end offsets sequentially into
// matches_out (length = 2 * max_matches).
// Returns the total number of matches found.
int re2_find_all(const re2_pattern_t* p, const char* text, int text_len,
                 int32_t* matches_out, int max_matches);

// Replace the first occurrence of the pattern in text with rewrite.
// Writes the result into out_buf (up to out_cap bytes) and sets *out_len
// to the actual result length. Returns 1 if a replacement was made,
// 0 if no match, or -1 if out_buf was too small (in which case *out_len
// contains the required size).
int re2_replace_first(const re2_pattern_t* p,
                      const char* text, int text_len,
                      const char* rewrite, int rewrite_len,
                      char* out_buf, int out_cap, int* out_len);

// Replace all occurrences of the pattern in text with rewrite.
// Writes the result into out_buf (up to out_cap bytes) and sets *out_len
// to the actual result length. Returns the number of replacements made,
// or -1 if out_buf was too small (in which case *out_len contains the
// required size).
int re2_replace_all(const re2_pattern_t* p,
                    const char* text, int text_len,
                    const char* rewrite, int rewrite_len,
                    char* out_buf, int out_cap, int* out_len);

// Perform a literal replacement given match group byte pairs from re2_find_all.
void re2_replace_literal(const uint8_t* __restrict__ input, int input_len,
                         const int* __restrict__ groups, int groups_count,
                         const uint8_t* __restrict__ replacement, int replacement_len,
                         uint8_t* __restrict__ output);

#ifdef __cplusplus
}
#endif

#endif  // RE2_SHIM_H_
