// Copyright (c) 2025 Eddie Aftandilian. Licensed under the MIT License.
// See LICENSE file in the project root for details.

#include "re2_shim.h"
#include <cstring>
#include <string>
#include <vector>

#include "absl/container/fixed_array.h"
#include "re2/re2.h"

struct re2_pattern {
  RE2* re2;
  std::string error_msg;
};

extern "C" {

re2_pattern_t* re2_compile(const char* pattern, int pattern_len) {
  auto* p = new re2_pattern();
  RE2::Options opts;
  opts.set_log_errors(false);
  p->re2 = new RE2(absl::string_view(pattern, pattern_len), opts);
  if (!p->re2->ok()) {
    p->error_msg = p->re2->error();
  }
  return p;
}

re2_pattern_t* re2_compile_case_insensitive(const char* pattern,
                                            int pattern_len) {
  auto* p = new re2_pattern();
  RE2::Options opts;
  opts.set_log_errors(false);
  opts.set_case_sensitive(false);
  p->re2 = new RE2(absl::string_view(pattern, pattern_len), opts);
  if (!p->re2->ok()) {
    p->error_msg = p->re2->error();
  }
  return p;
}

void re2_free(re2_pattern_t* p) {
  if (p) {
    delete p->re2;
    delete p;
  }
}

bool re2_ok(const re2_pattern_t* p) {
  return p && p->re2->ok();
}

const char* re2_error(const re2_pattern_t* p) {
  if (!p) return "null pattern";
  return p->error_msg.c_str();
}

int re2_num_capturing_groups(const re2_pattern_t* p) {
  if (!p || !p->re2->ok()) return -1;
  return p->re2->NumberOfCapturingGroups();
}

bool re2_match(const re2_pattern_t* p, const char* text, int text_len,
               int region_start, int region_end, int startpos, int anchor,
               int32_t* matches_out, int nmatches) {
  if (!p || !p->re2->ok() || region_start < 0 || region_end < region_start ||
      region_end > text_len || startpos < region_start || startpos > region_end ||
      anchor < 0 || anchor > 2 || nmatches < 0) {
    return false;
  }
  // Use a non-null backing address even for empty input, so participating empty
  // captures remain distinguishable from groups that did not participate.
  const char* base = text ? text : "";
  absl::string_view region(base + region_start, region_end - region_start);
  int nsub = nmatches + 1;
  absl::FixedArray<absl::string_view, 10> submatch(nsub);
  bool found = p->re2->Match(region, startpos - region_start, region.size(),
                            static_cast<RE2::Anchor>(anchor), submatch.data(), nsub);
  if (!found) return false;

  for (int i = 0; i < nsub; i++) {
    if (submatch[i].data() == nullptr) {
      matches_out[2 * i] = -1;
      matches_out[2 * i + 1] = -1;
    } else {
      matches_out[2 * i] = static_cast<int32_t>(submatch[i].data() - base);
      matches_out[2 * i + 1] =
          static_cast<int32_t>(submatch[i].data() - base + submatch[i].size());
    }
  }
  return true;
}

int re2_find_all(const re2_pattern_t* p, const char* text, int text_len,
                 int32_t* matches_out, int max_matches) {
  if (!p || !p->re2->ok()) return 0;

  absl::string_view input(text, text_len);
  int count = 0;
  int start_pos = 0;
  absl::string_view match;

  while (count < max_matches) {
    if (!p->re2->Match(input, start_pos, text_len, RE2::UNANCHORED, &match,
                       1)) {
      break;
    }
    int32_t start = static_cast<int32_t>(match.data() - text);
    int32_t end = static_cast<int32_t>(match.data() - text + match.size());
    matches_out[2 * count] = start;
    matches_out[2 * count + 1] = end;
    count++;

    if (start == end) {
      if (start_pos >= text_len) {
        break;
      }
      unsigned char c = static_cast<unsigned char>(text[start_pos]);
      if (c < 0x80) {
        start_pos += 1;
      } else if (c < 0xE0) {
        start_pos += 2;
      } else if (c < 0xF0) {
        start_pos += 3;
      } else {
        start_pos += 4;
      }
    } else {
      start_pos = end;
    }
  }
  return count;
}

int re2_replace_first(const re2_pattern_t* p,
                      const char* text, int text_len,
                      const char* rewrite, int rewrite_len,
                      char* out_buf, int out_cap, int* out_len) {
  if (!p || !p->re2->ok()) return -1;

  std::string str(text, text_len);
  bool replaced = RE2::Replace(&str, *p->re2,
                               absl::string_view(rewrite, rewrite_len));

  *out_len = static_cast<int>(str.size());
  if (static_cast<int>(str.size()) > out_cap) {
    return -1;  // buffer too small
  }
  std::memcpy(out_buf, str.data(), str.size());
  return replaced ? 1 : 0;
}

int re2_replace_all(const re2_pattern_t* p,
                    const char* text, int text_len,
                    const char* rewrite, int rewrite_len,
                    char* out_buf, int out_cap, int* out_len) {
  if (!p || !p->re2->ok()) return -1;

  std::string str(text, text_len);
  int count = RE2::GlobalReplace(&str, *p->re2,
                                  absl::string_view(rewrite, rewrite_len));

  *out_len = static_cast<int>(str.size());
  if (static_cast<int>(str.size()) > out_cap) {
    return -1;  // buffer too small
  }
  std::memcpy(out_buf, str.data(), str.size());
  return count;
}

void re2_replace_literal(const uint8_t* __restrict__ input, int input_len,
                         const int* __restrict__ groups, int groups_count,
                         const uint8_t* __restrict__ replacement, int replacement_len,
                         uint8_t* __restrict__ output) {
  int last_end = 0;
  uint8_t* out_ptr = output;
  for (int i = 0; i < groups_count; i++) {
    int match_start = groups[2 * i];
    int match_end = groups[2 * i + 1];
    int slice_len = match_start - last_end;
    if (slice_len > 0) {
      std::memcpy(out_ptr, input + last_end, slice_len);
      out_ptr += slice_len;
    }
    if (replacement_len > 0) {
      std::memcpy(out_ptr, replacement, replacement_len);
      out_ptr += replacement_len;
    }
    last_end = match_end;
  }
  int tail_len = input_len - last_end;
  if (tail_len > 0) {
    std::memcpy(out_ptr, input + last_end, tail_len);
  }
}

}  // extern "C"
