// This file is part of a Java port of RE2 (https://github.com/google/re2).
// Original RE2 code is Copyright (c) 2009 The RE2 Authors.
// Modifications and Java port Copyright (c) 2026 Eddie Aftandilian.
// Licensed under the BSD 3-Clause License (see LICENSE file).

package org.safere.benchmark;

import java.util.EnumSet;
import java.util.List;
import java.util.Random;
import org.openjdk.jmh.infra.Blackhole;

/** Generic operation semantics and result consumption for cross-engine regex workloads. */
enum BenchmarkOperation {
  MATCHES(EngineCapability.MATCHES),
  FIND(EngineCapability.FIND),
  LOOKING_AT(EngineCapability.LOOKING_AT),
  FIND_ALL_COUNT(EngineCapability.FIND),
  MATCHES_CORPUS(EngineCapability.MATCHES),
  MATCHES_GROUP_LENGTH_SUM(EngineCapability.MATCHES, EngineCapability.GROUP_TEXT),
  FIND_ALL_LENGTH_SUM(EngineCapability.FIND, EngineCapability.GROUP_TEXT),
  FIND_ALL_GROUP_LENGTH_SUM(EngineCapability.FIND, EngineCapability.GROUP_TEXT),
  CAPTURE_GROUPS(EngineCapability.MATCHES, EngineCapability.GROUP_TEXT),
  REPLACE_FIRST(EngineCapability.REPLACE),
  REPLACE_ALL(EngineCapability.REPLACE),
  REPLACE_ALL_LENGTH_SUM(EngineCapability.REPLACE),
  MANUAL_REPLACE_ALL(EngineCapability.APPEND_REPLACEMENT),
  SPLIT_LENGTH_SUM(EngineCapability.SPLIT),
  COMPILE(EngineCapability.COMPILE),
  COMPILE_AND_FIND(EngineCapability.COMPILE, EngineCapability.FIND),
  COMPILE_AND_MATCHES(EngineCapability.COMPILE, EngineCapability.MATCHES),
  FIND_ROTATING_UTF16(EngineCapability.FIND),
  COMPILE_AND_FIND_ROTATING_UTF16(EngineCapability.COMPILE, EngineCapability.FIND),
  MATCHER_RESET_FIND(EngineCapability.FIND, EngineCapability.MATCHER_RESET),
  MATCHER_REGION_FIND(EngineCapability.FIND, EngineCapability.REGIONS),
  MATCHER_REGION_MATCHES(EngineCapability.MATCHES, EngineCapability.REGIONS),
  MATCHER_REGION_TOKENIZE(EngineCapability.LOOKING_AT, EngineCapability.REGIONS),
  FIND_SAMPLED_GROUP(
      EngineCapability.FIND, EngineCapability.GROUP_PARTICIPATION, EngineCapability.MATCHER_RESET),
  FIND_GROUP_PRESENT(EngineCapability.FIND, EngineCapability.GROUP_PARTICIPATION),
  FIND_GROUP(EngineCapability.FIND, EngineCapability.GROUP_TEXT);

  private final EnumSet<EngineCapability> requiredCapabilities;

  BenchmarkOperation(EngineCapability... requiredCapabilities) {
    this.requiredCapabilities = EnumSet.noneOf(EngineCapability.class);
    for (EngineCapability capability : requiredCapabilities) {
      this.requiredCapabilities.add(capability);
    }
  }

  static BenchmarkOperation fromDeclarative(DeclarativeBenchmarkPlan.Operation operation) {
    return switch (operation) {
      case MATCHES -> MATCHES;
      case FIND -> FIND;
      case LOOKING_AT -> LOOKING_AT;
      case FIND_ALL_COUNT -> FIND_ALL_COUNT;
      case MATCHES_CORPUS -> MATCHES_CORPUS;
      case MATCHES_GROUP_LENGTH_SUM -> MATCHES_GROUP_LENGTH_SUM;
      case FIND_ALL_LENGTH_SUM -> FIND_ALL_LENGTH_SUM;
      case FIND_ALL_GROUP_LENGTH_SUM -> FIND_ALL_GROUP_LENGTH_SUM;
      case CAPTURE_GROUPS -> CAPTURE_GROUPS;
      case REPLACE_FIRST -> REPLACE_FIRST;
      case REPLACE_ALL -> REPLACE_ALL;
      case REPLACE_ALL_LENGTH_SUM -> REPLACE_ALL_LENGTH_SUM;
      case MANUAL_REPLACE_ALL -> MANUAL_REPLACE_ALL;
      case SPLIT_LENGTH_SUM -> SPLIT_LENGTH_SUM;
      case COMPILE -> COMPILE;
      case COMPILE_AND_FIND -> COMPILE_AND_FIND;
      case COMPILE_AND_MATCHES -> COMPILE_AND_MATCHES;
      case FIND_ROTATING_UTF16 -> FIND_ROTATING_UTF16;
      case COMPILE_AND_FIND_ROTATING_UTF16 -> COMPILE_AND_FIND_ROTATING_UTF16;
      case MATCHER_RESET_FIND -> MATCHER_RESET_FIND;
      case MATCHER_REGION_FIND -> MATCHER_REGION_FIND;
      case MATCHER_REGION_MATCHES -> MATCHER_REGION_MATCHES;
      case MATCHER_REGION_TOKENIZE -> MATCHER_REGION_TOKENIZE;
      case FIND_SAMPLED_GROUP -> FIND_SAMPLED_GROUP;
      case FIND_GROUP_PRESENT -> FIND_GROUP_PRESENT;
      case FIND_GROUP -> FIND_GROUP;
      default ->
          throw new IllegalArgumentException(
              "Operation is not implemented by the cross-engine runner: " + operation);
    };
  }

  boolean isSupportedBy(RegexEngineVariant variant) {
    return variant.capabilities().containsAll(requiredCapabilities);
  }

  BenchmarkTask bind(
      RegexEngineVariant variant,
      List<String> patternSources,
      List<RegexEngineVariant.CompiledRegex> patterns,
      List<RegexEngineVariant.RegexInput> inputs,
      int[] groups,
      RegexEngineVariant.PreparedReplacement replacement,
      int limit,
      DeclarativeBenchmarkPlan.MatcherLifecycle lifecycle,
      String flagSet,
      int seed,
      int count,
      String mode) {
    if (this == COMPILE) {
      return blackhole ->
          blackhole.consume(variant.compileForBenchmark(patternSources.getFirst(), flagSet));
    }
    if (this == FIND_ROTATING_UTF16 || this == COMPILE_AND_FIND_ROTATING_UTF16) {
      return rotatingUtf16Task(
          variant,
          patternSources.getFirst(),
          patterns,
          seed,
          count,
          this == COMPILE_AND_FIND_ROTATING_UTF16);
    }
    RegexEngineVariant.CompiledRegex pattern = patterns.getFirst();
    RegexEngineVariant.RegexInput input = inputs.getFirst();
    return switch (this) {
      case MATCHES -> blackhole -> blackhole.consume(pattern.matches(input));
      case FIND ->
          lifecycle.matcher() == DeclarativeBenchmarkPlan.MatcherReuse.NONE
              ? blackhole -> blackhole.consume(pattern.find(input))
              : blackhole -> blackhole.consume(pattern.matcher(input).find());
      case LOOKING_AT -> blackhole -> blackhole.consume(pattern.matcher(input).lookingAt());
      case FIND_ALL_COUNT -> blackhole -> blackhole.consume(findAllCount(pattern.matcher(input)));
      case MATCHES_CORPUS -> blackhole -> blackhole.consume(matchesCorpus(pattern, inputs));
      case MATCHES_GROUP_LENGTH_SUM ->
          blackhole -> blackhole.consume(matchesGroupLengthSum(pattern, inputs, groups));
      case FIND_ALL_LENGTH_SUM ->
          blackhole -> blackhole.consume(findAllLengthSum(pattern.matcher(input)));
      case FIND_ALL_GROUP_LENGTH_SUM ->
          blackhole -> blackhole.consume(findAllGroupLengthSum(pattern.matcher(input), groups));
      case CAPTURE_GROUPS ->
          blackhole -> blackhole.consume(captureGroups(pattern.matcher(input), groups));
      case REPLACE_FIRST ->
          blackhole -> pattern.replaceFirst(input, replacement).consume(blackhole);
      case REPLACE_ALL -> blackhole -> pattern.replaceAll(input, replacement).consume(blackhole);
      case REPLACE_ALL_LENGTH_SUM ->
          blackhole -> blackhole.consume(replaceAllLengthSum(patterns, input, replacement));
      case MANUAL_REPLACE_ALL ->
          blackhole -> pattern.manualReplaceAll(input, replacement).consume(blackhole);
      case SPLIT_LENGTH_SUM ->
          blackhole -> blackhole.consume(splitLengthSum(pattern.split(input, limit)));
      case COMPILE_AND_FIND ->
          blackhole -> {
            try (RegexEngineVariant.CompiledRegex compiled =
                variant.compile(patternSources.getFirst())) {
              blackhole.consume(compiled.find(input));
            }
          };
      case COMPILE_AND_MATCHES ->
          blackhole -> {
            try (RegexEngineVariant.CompiledRegex compiled =
                variant.compile(patternSources.getFirst())) {
              blackhole.consume(compiled.matches(input));
            }
          };
      case MATCHER_RESET_FIND -> {
        RegexEngineVariant.MatchCursor retainedMatcher =
            lifecycle.matcher() == DeclarativeBenchmarkPlan.MatcherReuse.RETAINED
                ? pattern.matcher(input)
                : null;
        yield blackhole -> {
          RegexEngineVariant.MatchCursor matcher =
              retainedMatcher != null ? retainedMatcher : pattern.matcher(input);
          matcher.reset();
          blackhole.consume(findAllCount(matcher));
        };
      }
      case MATCHER_REGION_FIND -> {
        RegexEngineVariant.MatchCursor retainedMatcher =
            lifecycle.matcher() == DeclarativeBenchmarkPlan.MatcherReuse.RETAINED
                ? pattern.matcher(input)
                : null;
        DeclarativeBenchmarkPlan.LifecycleStep region = region(lifecycle);
        yield blackhole -> {
          RegexEngineVariant.MatchCursor matcher =
              retainedMatcher != null ? retainedMatcher : pattern.matcher(input);
          matcher.region(region.start(), region.end());
          blackhole.consume(matcher.find());
        };
      }
      case MATCHER_REGION_MATCHES -> {
        RegexEngineVariant.MatchCursor retainedMatcher =
            lifecycle.matcher() == DeclarativeBenchmarkPlan.MatcherReuse.RETAINED
                ? pattern.matcher(input)
                : null;
        DeclarativeBenchmarkPlan.LifecycleStep region = region(lifecycle);
        yield blackhole -> {
          RegexEngineVariant.MatchCursor matcher =
              retainedMatcher != null ? retainedMatcher : pattern.matcher(input);
          matcher.region(region.start(), region.end());
          blackhole.consume(matcher.matches());
        };
      }
      case MATCHER_REGION_TOKENIZE -> {
        RegexEngineVariant.MatchCursor retainedMatcher =
            lifecycle.matcher() == DeclarativeBenchmarkPlan.MatcherReuse.RETAINED
                ? pattern.matcher(input)
                : null;
        yield blackhole ->
            blackhole.consume(
                tokenize(
                    retainedMatcher != null ? retainedMatcher : pattern.matcher(input),
                    input.nativeLength(),
                    mode));
      }
      case FIND_SAMPLED_GROUP -> {
        boolean capture = mode.equals("capture");
        primeCaptureDemand(pattern, inputs, groups[0], capture);
        RegexEngineVariant.MatchCursor retained =
            lifecycle.matcher() == DeclarativeBenchmarkPlan.MatcherReuse.RETAINED
                ? pattern.matcher(input)
                : null;
        int[] invocation = {0};
        yield blackhole -> {
          RegexEngineVariant.MatchCursor matcher =
              retained == null ? pattern.matcher(input) : retained;
          if (retained != null) {
            matcher.reset();
          }
          boolean readGroup = capture && invocation[0] == 0;
          invocation[0] = (invocation[0] + 1) % count;
          blackhole.consume(findSampledGroup(matcher, groups[0], readGroup));
        };
      }
      case FIND_GROUP_PRESENT ->
          blackhole -> blackhole.consume(findGroupPresent(pattern.matcher(input), groups[0]));
      case FIND_GROUP ->
          blackhole -> blackhole.consume(findGroup(pattern.matcher(input), groups[0]));
      case COMPILE -> throw new AssertionError();
      case FIND_ROTATING_UTF16, COMPILE_AND_FIND_ROTATING_UTF16 -> throw new AssertionError();
    };
  }

  Object execute(
      RegexEngineVariant variant,
      List<String> patternSources,
      List<RegexEngineVariant.CompiledRegex> patterns,
      List<RegexEngineVariant.RegexInput> inputs,
      int[] groups,
      RegexEngineVariant.PreparedReplacement replacement,
      int limit,
      DeclarativeBenchmarkPlan.MatcherLifecycle lifecycle,
      String flagSet,
      int seed,
      int count,
      String mode) {
    if (this == COMPILE) {
      return true;
    }
    if (this == FIND_ROTATING_UTF16 || this == COMPILE_AND_FIND_ROTATING_UTF16) {
      String input = rotatingUtf16Inputs(seed, count)[0];
      if (this == FIND_ROTATING_UTF16) {
        return patterns.getFirst().find(new RegexEngineVariant.StringRegexInput(input));
      }
      try (RegexEngineVariant.CompiledRegex compiled = variant.compile(patternSources.getFirst())) {
        return compiled.find(new RegexEngineVariant.StringRegexInput(input));
      }
    }
    RegexEngineVariant.CompiledRegex pattern = patterns.getFirst();
    RegexEngineVariant.RegexInput input = inputs.getFirst();
    return switch (this) {
      case MATCHES -> pattern.matches(input);
      case FIND ->
          lifecycle.matcher() == DeclarativeBenchmarkPlan.MatcherReuse.NONE
              ? pattern.find(input)
              : pattern.matcher(input).find();
      case LOOKING_AT -> pattern.matcher(input).lookingAt();
      case FIND_ALL_COUNT -> findAllCount(pattern.matcher(input));
      case MATCHES_CORPUS -> matchesCorpus(pattern, inputs);
      case MATCHES_GROUP_LENGTH_SUM -> matchesGroupLengthSum(pattern, inputs, groups);
      case FIND_ALL_LENGTH_SUM -> findAllLengthSum(pattern.matcher(input));
      case FIND_ALL_GROUP_LENGTH_SUM -> findAllGroupLengthSum(pattern.matcher(input), groups);
      case CAPTURE_GROUPS -> captureGroups(pattern.matcher(input), groups);
      case REPLACE_FIRST -> pattern.replaceFirst(input, replacement).validationValue();
      case REPLACE_ALL -> pattern.replaceAll(input, replacement).validationValue();
      case REPLACE_ALL_LENGTH_SUM -> replaceAllLengthSum(patterns, input, replacement);
      case MANUAL_REPLACE_ALL -> pattern.manualReplaceAll(input, replacement).validationValue();
      case SPLIT_LENGTH_SUM -> splitLengthSum(pattern.split(input, limit));
      case COMPILE_AND_FIND -> {
        try (RegexEngineVariant.CompiledRegex compiled =
            variant.compile(patternSources.getFirst())) {
          yield compiled.find(input);
        }
      }
      case COMPILE_AND_MATCHES -> {
        try (RegexEngineVariant.CompiledRegex compiled =
            variant.compile(patternSources.getFirst())) {
          yield compiled.matches(input);
        }
      }
      case MATCHER_RESET_FIND -> {
        RegexEngineVariant.MatchCursor matcher = pattern.matcher(input);
        matcher.reset();
        yield findAllCount(matcher);
      }
      case MATCHER_REGION_FIND -> {
        RegexEngineVariant.MatchCursor matcher = pattern.matcher(input);
        DeclarativeBenchmarkPlan.LifecycleStep region = region(lifecycle);
        matcher.region(region.start(), region.end());
        yield matcher.find();
      }
      case MATCHER_REGION_MATCHES -> {
        RegexEngineVariant.MatchCursor matcher = pattern.matcher(input);
        DeclarativeBenchmarkPlan.LifecycleStep region = region(lifecycle);
        matcher.region(region.start(), region.end());
        yield matcher.matches();
      }
      case MATCHER_REGION_TOKENIZE -> tokenize(pattern.matcher(input), input.nativeLength(), mode);
      case FIND_SAMPLED_GROUP -> {
        primeCaptureDemand(pattern, inputs, groups[0], mode.equals("capture"));
        yield findSampledGroup(pattern.matcher(input), groups[0], mode.equals("capture"));
      }
      case FIND_GROUP_PRESENT -> findGroupPresent(pattern.matcher(input), groups[0]);
      case FIND_GROUP -> findGroup(pattern.matcher(input), groups[0]);
      case COMPILE -> throw new AssertionError();
      case FIND_ROTATING_UTF16, COMPILE_AND_FIND_ROTATING_UTF16 -> throw new AssertionError();
    };
  }

  private static int tokenize(RegexEngineVariant.MatchCursor matcher, int length, String mode) {
    mode = mode == null ? "" : mode;
    boolean independent = mode.startsWith("independent");
    if (independent) {
      matcher.reset();
    }
    int count = 0;
    for (int pos = 0; pos < length; ) {
      if (!independent) {
        matcher.region(pos, length);
      }
      boolean found = mode.isEmpty() ? matcher.lookingAt() : matcher.find();
      if (!found) {
        throw new IllegalStateException("Tokenizer failed at " + pos);
      }
      int end = matcher.end(0);
      if (mode.endsWith("Bounds")) {
        if (matcher.start(0) != pos) {
          throw new IllegalStateException("Tokenizer skipped input");
        }
      } else if (mode.endsWith("Capture")) {
        if (matcher.start(1) != pos || matcher.end(1) <= pos || matcher.end(1) > end) {
          throw new IllegalStateException("Tokenizer capture mismatch");
        }
      }
      if (end <= pos) {
        throw new IllegalStateException("Tokenizer did not advance at " + pos);
      }
      pos = end;
      count++;
    }
    return count;
  }

  private static BenchmarkTask rotatingUtf16Task(
      RegexEngineVariant variant,
      String patternSource,
      List<RegexEngineVariant.CompiledRegex> patterns,
      int seed,
      int count,
      boolean compileEachInvocation) {
    String[] inputs = rotatingUtf16Inputs(seed, count);
    int[] index = {0};
    if (!compileEachInvocation) {
      RegexEngineVariant.CompiledRegex pattern = patterns.getFirst();
      return blackhole -> {
        String input = inputs[index[0]];
        index[0] = (index[0] + 1) % inputs.length;
        blackhole.consume(pattern.find(new RegexEngineVariant.StringRegexInput(input)));
      };
    }
    return blackhole -> {
      String input = inputs[index[0]];
      index[0] = (index[0] + 1) % inputs.length;
      try (RegexEngineVariant.CompiledRegex compiled = variant.compile(patternSource)) {
        blackhole.consume(compiled.find(new RegexEngineVariant.StringRegexInput(input)));
      }
    };
  }

  private static String[] rotatingUtf16Inputs(int seed, int count) {
    Random random = new Random(seed);
    String[] inputs = new String[count];
    for (int i = 0; i < count; i++) {
      inputs[i] = new String(new char[] {(char) random.nextInt()});
    }
    return inputs;
  }

  private static DeclarativeBenchmarkPlan.LifecycleStep region(
      DeclarativeBenchmarkPlan.MatcherLifecycle lifecycle) {
    return lifecycle.steps().stream()
        .filter(step -> step.kind() == DeclarativeBenchmarkPlan.LifecycleStepKind.REGION)
        .findFirst()
        .orElseThrow(
            () -> new IllegalArgumentException("Matcher region operation requires region"));
  }

  private static int findAllCount(RegexEngineVariant.MatchCursor matcher) {
    int count = 0;
    while (matcher.find()) {
      count++;
    }
    return count;
  }

  private static int matchesCorpus(
      RegexEngineVariant.CompiledRegex pattern, List<RegexEngineVariant.RegexInput> inputs) {
    int count = 0;
    for (RegexEngineVariant.RegexInput input : inputs) {
      if (pattern.matches(input)) {
        count++;
      }
    }
    return count;
  }

  private static int matchesGroupLengthSum(
      RegexEngineVariant.CompiledRegex pattern,
      List<RegexEngineVariant.RegexInput> inputs,
      int[] groups) {
    int sum = 0;
    for (RegexEngineVariant.RegexInput input : inputs) {
      RegexEngineVariant.MatchCursor matcher = pattern.matcher(input);
      if (matcher.matches()) {
        sum += groupLengthSum(matcher, groups);
      }
    }
    return sum;
  }

  private static int findAllLengthSum(RegexEngineVariant.MatchCursor matcher) {
    int sum = 0;
    while (matcher.find()) {
      sum += matcher.group(0).length();
    }
    return sum;
  }

  private static int findAllGroupLengthSum(RegexEngineVariant.MatchCursor matcher, int[] groups) {
    int sum = 0;
    while (matcher.find()) {
      sum += groupLengthSum(matcher, groups);
    }
    return sum;
  }

  private static int groupLengthSum(RegexEngineVariant.MatchCursor matcher, int[] groups) {
    int sum = 0;
    for (int group : groups) {
      String value = matcher.group(group);
      if (value != null) {
        sum += value.length();
      }
    }
    return sum;
  }

  private static String captureGroups(RegexEngineVariant.MatchCursor matcher, int[] groups) {
    if (!matcher.matches()) {
      return "";
    }
    if (groups.length == 1) {
      return matcher.group(groups[0]);
    }
    if (groups.length == 3) {
      return matcher.group(groups[0]) + matcher.group(groups[1]) + matcher.group(groups[2]);
    }
    StringBuilder result = new StringBuilder();
    for (int group : groups) {
      result.append(matcher.group(group));
    }
    return result.toString();
  }

  private static int replaceAllLengthSum(
      List<RegexEngineVariant.CompiledRegex> patterns,
      RegexEngineVariant.RegexInput input,
      RegexEngineVariant.PreparedReplacement replacement) {
    int sum = 0;
    for (RegexEngineVariant.CompiledRegex pattern : patterns) {
      sum += pattern.replaceAll(input, replacement).nativeLength();
    }
    return sum;
  }

  private static int splitLengthSum(String[] parts) {
    int sum = parts.length;
    for (String part : parts) {
      sum += part.length();
    }
    return sum;
  }

  private static void primeCaptureDemand(
      RegexEngineVariant.CompiledRegex pattern,
      List<RegexEngineVariant.RegexInput> inputs,
      int group,
      boolean capture) {
    if (capture && inputs.size() > 1) {
      RegexEngineVariant.MatchCursor primer = pattern.matcher(inputs.get(1));
      if (!primer.matches() || !primer.groupParticipated(group)) {
        throw new IllegalArgumentException("Capture primer must match and participate");
      }
    }
  }

  private static boolean findSampledGroup(
      RegexEngineVariant.MatchCursor matcher, int group, boolean readGroup) {
    return matcher.find() && (!readGroup || matcher.groupParticipated(group));
  }

  private static boolean findGroupPresent(RegexEngineVariant.MatchCursor matcher, int group) {
    return matcher.find() && matcher.groupParticipated(group);
  }

  private static String findGroup(RegexEngineVariant.MatchCursor matcher, int group) {
    if (!matcher.find()) {
      return null;
    }
    return matcher.group(group);
  }

  @FunctionalInterface
  interface BenchmarkTask {
    void run(Blackhole blackhole);
  }
}
